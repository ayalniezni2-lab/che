"""Learning routes: units, grading (+ diagnosis, SRS, Mistake Notebook), verbs, words, culture."""
import copy
import random
import time
from datetime import datetime

from . import audio as audio_mod, explain, knowledge, srs
from .api import route, ApiError, C, P, A, STATE
from .conjugator import Engine, split_inf
from .diagnosis import Diagnoser
from .grading import Grader
from .spanish import fold, normalize, tokens


# ---------------------------------------------------------------- shared services
def services():
    """Engine / grader / diagnoser, rebuilt whenever the content is reloaded."""
    c = C()
    svc = STATE.get("svc")
    if not svc or svc["sig"] != id(c.verbs):
        engine = Engine(c.verbs, c.irregular)
        grader = Grader(c, engine)
        svc = {"sig": id(c.verbs), "engine": engine, "grader": grader,
               "diagnoser": Diagnoser(c, engine, grader)}
        STATE["svc"] = svc
    return svc


def E():
    return services()["engine"]


_TAUGHT = {}


def learner_taught():
    """knowledge.taught() for the current learner, recomputed only when the progress changed."""
    from .drills import learner_level
    p = P().data
    level = learner_level()
    units = tuple(sorted((k, bool(v.get("started")), bool(v.get("completed") or v.get("skipped")))
                         for k, v in p["units"].items()))
    sig = (id(C()), p.get("updated"), len(p["srs"]), units, level, (p.get("course") or {}).get("stage"),
           (p.get("placement") or {}).get("level"))
    if _TAUGHT.get("sig") != sig:
        _TAUGHT.update(sig=sig, value=knowledge.taught(p, C(), level, G()))
    return _TAUGHT["value"]


def G():
    return services()["grader"]


def D():
    return services()["diagnoser"]


def vulgar_ok():
    return bool(P().data["settings"].get("vulgar"))


# ---------------------------------------------------------------- serving exercises
def full_sentence(ex):
    """The complete Spanish sentence for audio / display after answering."""
    es = ex.get("es") or ""
    if "___" in es:
        return ex.get("say") or es.replace("___", ex.get("answer", ""))
    if ex.get("type") in ("es2en", "listen_mc", "listen_type"):
        return es or ex.get("answer", "")
    if ex.get("type") in ("en2es", "order", "conj", "type", "reply"):
        return ex.get("say") or ex.get("answer", "")
    return es


def srs_key(ex):
    if ex.get("key"):
        return ex["key"]
    return "ex:%s" % ex.get("id", "?")


def serve_exercise(ex):
    ex = G().present(copy.deepcopy(ex))
    ex["key"] = srs_key(ex)
    full = full_sentence(ex)
    ex["audio"] = A().ref(full, ex.get("voice"))
    if ex.get("type") == "reply" and ex.get("es"):     # the message being answered
        ex["audio_msg"] = A().ref(ex["es"], ex.get("voice"))
    if "___" in (ex.get("es") or ""):          # before answering: the same voice, with a pause for the blank
        ex["audio_q"] = A().ref(audio_mod.gap_text(ex["es"]), ex.get("voice") or audio_mod.pick_voice(full))
    try:                                        # words in it that no lesson has taught this learner yet
        ex["word_hints"] = knowledge.hints(C(), G(), ex, learner_taught())
    except Exception:
        ex["word_hints"] = []
    if ex.get("type") in ("mc", "listen_mc", "dialogue_q") and ex.get("options"):
        opts = list(ex["options"])
        random.shuffle(opts)
        ex["options"] = opts
    if ex.get("type") == "order":
        words = ex.get("words") or tokens_keep_case(ex["answer"])
        chips = list(words) + list(ex.get("distractors", []))
        random.shuffle(chips)
        ex["chips"] = chips
    if ex.get("type") == "match":
        right = [p[1] for p in ex["pairs"]]
        random.shuffle(right)
        ex["right"] = right
        ex["pair_audio"] = {p[0]: A().ref(p[0]) for p in ex["pairs"]}
    return ex


def tokens_keep_case(sentence):
    import re
    return re.findall(r"[0-9A-Za-zÁÉÍÓÚÜÑáéíóúüñ]+", sentence)       # "la parada del 60": numbers are words too


def with_audio(items):
    out = []
    for it in items or []:
        it = dict(it)
        it["audio"] = A().ref(it.get("es"), it.get("voice"))
        out.append(it)
    return out


def serve_dialogue(d):
    d = copy.deepcopy(d)
    speakers = d.get("speakers", {})
    for line in d.get("lines", []):
        sp = speakers.get(line.get("who"), {})
        line["name"] = sp.get("name", line.get("who", ""))
        line["audio"] = A().ref(line.get("say") or line.get("es"), sp.get("voice"))   # "say": spoken version of chat-speak
    d["questions"] = [serve_exercise(q) for q in d.get("questions", [])]
    return d


@route("GET", "unit/*")
def get_unit(query, body, uid):
    C().reload_if_changed()
    unit = C().units.get(uid)
    if not unit:
        raise ApiError("No such unit: %s" % uid, 404)
    if unit.get("reg") == "vulgar" and not vulgar_ok():
        raise ApiError("This unit is about swear words. Switch on “Include vulgar words” in Settings to open it.", 403)
    st = P().data["units"].setdefault(uid, {})
    if not st.get("started"):
        st["started"] = datetime.now().isoformat(timespec="seconds")
        P().save()
    u = copy.deepcopy(unit)
    for block in u.get("teach", []):
        kind = block.get("t")
        if kind == "examples":
            block["items"] = with_audio(block.get("items"))
        elif kind == "verbtable":
            block["table"] = D().table(block["verb"], block.get("tense", "pres"))
        elif kind == "dialogue":
            d = C().dialogues.get(block.get("ref"))
            block["dialogue"] = serve_dialogue(d) if d else None
        elif kind == "vocab":
            items = [C().vocab[i] for i in block.get("ids", []) if i in C().vocab]
            block["items"] = [serve_vocab(i) for i in items]
        elif kind == "pairs":
            pairs = (C().meta.get("accent_pairs") or {}).get(block.get("set", "pairs"), [])
            wanted = block.get("only")
            block["items"] = [dict(p, a_audio=A().ref(p["a"]), b_audio=A().ref(p["b"]))
                              for p in pairs if not wanted or p["a"] in wanted]
    own = [x for x in u.get("exercises", []) if vulgar_ok() or x.get("reg") != "vulgar" or unit.get("reg") == "vulgar"]
    if query.get("retry"):
        own = retry_set(u, own)
    exercises = [serve_exercise(x) for x in own]
    from .drills import unit_drills
    exercises += [serve_exercise(x) for x in unit_drills(u)]
    u["exercises"] = exercises
    from . import course
    nxt = course.next_after(uid, P().data)
    u["next"] = nxt["id"] if nxt else None
    u["next_chapter"] = nxt
    ch = course.chapter(uid)
    if ch:
        cs = course.course()
        stage = cs["stages"][cs["index"][uid][0]]
        u["chapter"] = {"stage": stage["id"], "stage_n": cs["index"][uid][0] + 1, "stage_title": stage["title"],
                        "pos": ch["pos"] + 1, "count": len(stage["chapters"]), "kind": ch["kind"],
                        "kind_label": course.KINDS.get(ch["kind"])}
    u["status"] = st
    return u


def retry_set(u, own):
    """"Try again" on a lesson: the questions missed last time come back; the ones answered right are swapped for
    fresh ones on the same material — type the lesson's "one more example" sentence as you hear it, or a word from
    the lesson's word lists — so a retry cannot be passed by remembering the answers.  New order every time."""
    from . import drills
    cards = P().data["srs"]
    words = [C().vocab[i] for b in u.get("teach", []) if b.get("t") == "vocab" for i in b.get("ids", [])
             if i in C().vocab and (vulgar_ok() or C().vocab[i].get("reg") != "vulgar")]
    random.shuffle(words)
    out = []
    for x in own:
        card = cards.get("ex:" + x["id"])
        if not card or not card.get("reps"):           # missed (or never answered): ask it again
            out.append(x)
            continue
        extra = x.get("extra") or {}
        if extra.get("es") and not x.get("no_audio") and random.random() < 0.6:
            out.append({"id": x["id"] + ":again", "key": "ex:" + x["id"], "type": "listen_type",
                        "prompt": "Listen and type what you hear.", "es": extra["es"], "en": extra.get("en", ""),
                        "answer": extra["es"], "topic": x.get("topic") or u.get("topic"), "level": u.get("level"),
                        "generated": True, "why": "The sentence was: **%s** (%s)" % (extra["es"], extra.get("en", ""))})
        elif words:
            it = words.pop()
            out.append(drills.make_vocab(it, random.choice(["en2es", "es2en"] + (["listen"] if not it.get("no_audio")
                                                                               else []))))
        else:
            out.append(x)
    random.shuffle(out)
    return out


@route("POST", "unit/complete")
def complete_unit(query, body):
    uid = body.get("unit")
    if uid not in C().units:
        raise ApiError("No such unit", 404)
    score = float(body.get("score") or 0)
    p = P()
    with p.lock:
        from . import course
        course.ensure_saved(p.data)
        st = p.data["units"].setdefault(uid, {})
        st["attempts"] = st.get("attempts", 0) + 1
        st["best"] = max(st.get("best") or 0, round(score, 3))
        st["last"] = datetime.now().isoformat(timespec="seconds")
        if score >= 0.7:
            st["completed"] = st.get("completed") or st["last"]
        p.log_session()
        p.save()
    return {"status": st, "passed": score >= 0.7}


# ---------------------------------------------------------------- grading
def _pair_note(ex):
    """For accent-pair choices: spell out what each look-alike means."""
    notes = []
    idx = G().pair_index
    for opt in ex.get("options", []):
        for p in idx.get(fold(opt), []):
            line = "**%s** = %s · **%s** = %s" % (p["a"], p["a_en"], p["b"], p["b_en"])
            if line not in notes:
                notes.append(line)
    verb = ex.get("verb")
    if ex.get("routed") and verb:
        ans = ex.get("answer", "")
        info = C().verbs.get(verb["inf"]) or {}
        for form, tense, person in E().all_forms(verb["inf"]):
            if fold(form) == fold(ans) and form != ans and person != "ellos":
                line = "**%s** = %s (%s) · **%s** = %s (%s)" % (
                    ans, explain.describe(verb["tense"], verb.get("person")),
                    explain.gloss(explain.verb_en(info), verb["tense"], verb.get("person")),
                    form, explain.describe(tense, person), explain.gloss(explain.verb_en(info), tense, person))
                if line not in notes:
                    notes.append(line)
    return notes[:3]


@route("POST", "grade")
def grade(query, body):
    ex = body.get("ex") or {}
    answer = body.get("answer")
    stored = C().exercises.get(ex.get("id"))
    if stored:                                   # content is authoritative for the answer + teaching
        base = stored[0]
        for k in ("answer", "accept", "why", "extra", "verb", "focus", "es", "en", "pairs", "topic", "level"):
            if k in base:
                ex[k] = base[k]
    etype = ex.get("type")
    seconds = float(body.get("seconds") or 0)
    mine = (P().data.get("accepted") or {}).get(ex.get("id") or "")
    if mine and etype not in ("match", "mc", "listen_mc", "dialogue_q"):
        ex["accept"] = list(ex.get("accept", [])) + list(mine)      # answers the learner marked "I was right"

    if etype == "match":
        # the app sends {wrong: [...]}; anything else (an empty "I don't know") means nothing was matched
        wrong_pairs = (answer or {}).get("wrong", []) if isinstance(answer, dict) else [p[0] for p in ex.get("pairs", [])]
        ok = not wrong_pairs
        res = {"verdict": "correct" if ok else "wrong", "correct": ok, "typed": "", "notes": [],
               "expected": " · ".join("%s = %s" % (a, b) for a, b in ex.get("pairs", [])),
               "accent_note": None}
        diag = {"messages": ["You mixed up: " + ", ".join("**%s**" % w for w in wrong_pairs) + "."] if wrong_pairs else [],
                "kinds": ["match"] if wrong_pairs else [], "table": None, "verb": None}
    else:
        res = G().grade(ex, answer if isinstance(answer, str) else "")
        diag = {"messages": [], "kinds": [], "table": None, "verb": None}
        if not res["correct"]:
            try:
                diag = D().diagnose(ex, res["typed"], res["expected"])
            except Exception:                    # an explanation that fails must never lose the answer itself
                import traceback
                traceback.print_exc()

    sentence = full_sentence(ex)
    out = {
        "verdict": res["verdict"], "correct": res["correct"], "typed": res["typed"],
        "expected": res["expected"], "accent_note": res["accent_note"], "notes": res["notes"],
        "diagnosis": diag["messages"], "kinds": diag["kinds"], "table": diag["table"],
        "why": ex.get("why"), "extra": None, "sentence": sentence, "sentence_en": ex.get("en"),
        "audio": A().ref(sentence, ex.get("voice")) or A().ref(res["expected"]),
        "pair_notes": _pair_note(ex) if etype in ("mc",) else [],
    }
    if ex.get("extra"):
        out["extra"] = dict(ex["extra"], audio=A().ref(ex["extra"].get("es")))
    if not res["correct"] and not out["table"] and ex.get("verb"):
        out["table"] = D().table(ex["verb"]["inf"], ex["verb"].get("tense", "pres"), hit=ex["verb"].get("person"))

    if not body.get("dry"):
        out["answer_id"] = record(ex, res, diag, seconds, body.get("ctx") or {})
    return out


def record(ex, res, diag, seconds, ctx):
    """Progress bookkeeping for one answer: history, SRS card, Mistake Notebook.  Returns an id the feedback
    card can send back with "I was right" (grade/override), which undoes the penalty of a wrong grade."""
    p = P()
    key = srs_key(ex)
    topic = ex.get("topic") or "general"
    reading_q = ex.get("type") == "dialogue_q"     # questions about a reading: only for its chapter, never alone
    with p.lock:
        notebook = p.data["mistakes"]
        entry = next((m for m in notebook if m["key"] == key), None)
        answer_id = "a%d" % int(time.time() * 1000)
        STATE["last_answer"] = {
            "id": answer_id, "key": key, "ex_id": ex.get("id"), "typed": res["typed"], "topic": topic,
            "correct": res["correct"], "tense": (ex.get("verb") or {}).get("tense") if not ctx.get("placement") else None,
            "card": copy.deepcopy(p.data["srs"].get(key)), "had_card": key in p.data["srs"],
            "entry": copy.deepcopy(entry), "had_entry": entry is not None, "seen_new": p.data["seen_new"].get(key)}
        p.log_answer(res["correct"], seconds, topic)
        if reading_q:
            p.save()
            return answer_id
        card = p.data["srs"].get(key)
        if card is None:
            card = srs.new_card()
            card.update({"topic": topic, "level": ex.get("level"), "kind": key.split(":", 1)[0]})
            p.data["srs"][key] = card
            p.data["seen_new"][key] = srs.today()
        srs.review(card, res["verdict"], fast=0 < seconds < 6)
        tense = (ex.get("verb") or {}).get("tense")
        if tense and not ctx.get("placement"):
            knowledge.record(p.data, tense, res["correct"])      # the per-tense pace (one tense at a time)
        if res["verdict"] == "wrong":
            now = datetime.now().isoformat(timespec="seconds")
            if entry is None:
                entry = {"id": "m%d" % int(time.time() * 1000), "key": key, "first": now, "count": 0}
                notebook.append(entry)
            entry.update({
                "last": now, "count": entry.get("count", 0) + 1, "streak": 0, "ok_day": None, "resolved": False,
                "topic": topic, "level": ex.get("level"), "unit": ctx.get("unit"),
                "type": ex.get("original_type") or ex.get("type"),
                "prompt": ex.get("prompt"), "es": ex.get("es"), "en": ex.get("en"),
                "typed": res["typed"], "expected": res["expected"],
                "diagnosis": diag["messages"], "kinds": diag["kinds"],
                "verb": diag.get("verb") or ex.get("verb"), "why": ex.get("why"), "extra": ex.get("extra"),
                "ex": {k: v for k, v in ex.items() if k not in ("audio", "chips", "right", "pair_audio")},
            })
            if len(notebook) > 1500:                 # fixed ones go first; open ones only in a very full notebook
                notebook.sort(key=lambda m: (not m.get("resolved"), m.get("last", "")))
                del notebook[:len(notebook) - 1500]
        elif entry is not None and not entry.get("resolved"):
            # fixed = right on two DIFFERENT days (the retry at the end of the same lesson does not prove it stuck)
            if entry.get("ok_day") != srs.today():
                entry["streak"] = entry.get("streak", 0) + 1
                entry["ok_day"] = srs.today()
            if entry["streak"] >= 2:
                entry["resolved"] = True
                entry["resolved_on"] = srs.today()
        p.save()
        return answer_id


@route("POST", "grade/override")
def grade_override(query, body):
    """"I was right": the last answer was marked wrong but the learner's answer is fine.  Undo its penalty
    (review card, Mistake Notebook, today's score, tense pace), count it as right, and accept that answer for this
    exercise from now on."""
    last = STATE.get("last_answer") or {}
    if not last or last.get("id") != body.get("answer_id"):
        raise ApiError("That answer can no longer be changed — only the latest one can.")
    if last.get("correct"):
        return {"ok": True}
    p = P()
    key = last["key"]
    with p.lock:
        if last["had_card"]:
            p.data["srs"][key] = copy.deepcopy(last["card"])
        else:
            p.data["srs"].pop(key, None)
            p.data["seen_new"].pop(key, None)
        card = p.data["srs"].get(key)
        if card is None and C().exercises.get(last.get("ex_id") or "", [{}])[0].get("type") != "dialogue_q":
            card = srs.new_card()
            card.update({"topic": last["topic"], "kind": key.split(":", 1)[0]})
            p.data["srs"][key] = card
            p.data["seen_new"][key] = last.get("seen_new") or srs.today()
        if card is not None:
            srs.review(card, "correct")
        notebook = p.data["mistakes"]
        p.data["mistakes"] = [m for m in notebook if m["key"] != key]
        if last["had_entry"]:
            p.data["mistakes"].append(last["entry"])
        day = p.data["history"].get(srs.today())
        if day:
            day["correct"] = min(day.get("answers", 0), day.get("correct", 0) + 1)
        ts = p.data["topic_stats"].get(last["topic"])
        if ts:
            ts["right"] = min(ts.get("seen", 0), ts.get("right", 0) + 1)
        recent = (p.data.get("tense_recent") or {}).get(last.get("tense") or "")
        if recent and recent[-1] == 0:
            recent[-1] = 1
        typed = (last.get("typed") or "").strip()
        if typed and last.get("ex_id") and last["ex_id"] in C().exercises:
            acc = p.data.setdefault("accepted", {}).setdefault(last["ex_id"], [])
            if typed not in acc:
                acc.append(typed)
        last["correct"] = True
        p.save()
    return {"ok": True}


@route("POST", "report")
def report(query, body):
    """A problem the learner spotted (wrong answer, odd Spanish, bad translation): kept for `fix:`."""
    from .version import VERSION
    ex = body.get("ex") or {}
    item = {"date": datetime.now().isoformat(timespec="minutes"), "version": VERSION,
            "id": ex.get("id") or ex.get("key"), "type": ex.get("original_type") or ex.get("type"),
            "prompt": ex.get("prompt"), "es": ex.get("es"), "en": ex.get("en"),
            "expected": body.get("expected"), "typed": body.get("typed"),
            "note": (body.get("note") or "").strip()[:500]}
    p = P()
    with p.lock:
        p.data.setdefault("reports", []).append(item)
        del p.data["reports"][:-200]
        p.save()
    return {"ok": True, "count": len(p.data["reports"])}


@route("GET", "reports")
def reports(query, body):
    return {"items": list(P().data.get("reports") or [])}


@route("POST", "reports/clear")
def reports_clear(query, body):
    p = P()
    with p.lock:
        p.data["reports"] = []
        p.save()
    return {"ok": True}


# ---------------------------------------------------------------- Mistake Notebook
@route("GET", "notebook")
def notebook(query, body):
    from .session import key_retired
    items = [m for m in P().data["mistakes"] if not key_retired(m["key"])]
    show = query.get("show", "open")
    if show == "open":
        items = [m for m in items if not m.get("resolved")]
    elif show == "resolved":
        items = [m for m in items if m.get("resolved")]
    topics = sorted({m.get("topic") or "general" for m in P().data["mistakes"]})
    topics = [[t, explain.topic_label(t)] for t in topics]
    kinds = sorted({k for m in P().data["mistakes"] for k in m.get("kinds", [])})
    if query.get("topic"):
        items = [m for m in items if m.get("topic") == query["topic"]]
    if query.get("kind"):
        items = [m for m in items if query["kind"] in m.get("kinds", [])]
    items.sort(key=lambda m: m.get("last", ""), reverse=True)
    out = []
    for m in items[:200]:
        m = dict(m)
        m["topic_label"] = explain.topic_label(m.get("topic"))
        if m.get("verb") and m["verb"].get("inf"):
            m["table"] = D().table(m["verb"]["inf"], m["verb"].get("tense", "pres"), hit=m["verb"].get("person"))
        m["audio"] = A().ref(full_sentence(m.get("ex") or {}))
        out.append(m)
    return {"items": out, "topics": topics, "kinds": kinds,
            "open": len([m for m in P().data["mistakes"] if not m.get("resolved")]),
            "total": len(P().data["mistakes"])}


@route("POST", "notebook/remove")
def notebook_remove(query, body):
    p = P()
    with p.lock:
        p.data["mistakes"] = [m for m in p.data["mistakes"] if m.get("id") != body.get("id")]
        p.save()
    return {"ok": True}


# ---------------------------------------------------------------- verbs / words / culture
@route("GET", "verbs")
def verbs(query, body):
    out = []
    for inf, v in C().verbs.items():
        if v.get("reg") == "vulgar" and not vulgar_ok():
            continue
        out.append({"inf": inf, "en": v.get("en"), "level": v.get("level"), "rank": v.get("rank"),
                    "reg": v.get("reg", "neutral"), "note": v.get("note"),
                    "irregular": any(E().is_irregular(inf, t, p) for t, p in
                                     (("pres", "yo"), ("pres", "el"), ("pret", "yo"), ("pret", "el"), ("fut", "yo")))})
    return {"verbs": out}


@route("GET", "verb/*")
def verb(query, body, inf):
    if inf not in C().verbs and split_inf(inf)[0] not in C().verbs:
        raise ApiError("Verb not in the database: %s" % inf, 404)
    v = C().verbs.get(inf) or C().verbs.get(split_inf(inf)[0])
    return {"inf": inf, "en": v.get("en"), "level": v.get("level"), "reg": v.get("reg", "neutral"),
            "note": v.get("note"), "audio": A().ref(inf), "tables": D().full_tables(inf)}


def serve_vocab(it):
    it = dict(it)
    it["audio"] = A().ref(it.get("es"))
    it["ex_audio"] = A().ref(it.get("ex"))
    cards = P().data["srs"]
    card = cards.get("vocab:%s:en2es" % it["id"])
    it["known"] = bool(card and srs.is_known(card))         # known = typed right over spaced reviews
    it["seen"] = bool(card or cards.get("vocab:%s:es2en" % it["id"]))
    return it


@route("GET", "vocab")
def vocab(query, body):
    items = C().vocab_list(level=query.get("level") or None, topic=query.get("topic") or None,
                           include_vulgar=vulgar_ok())
    q = normalize(query.get("q", ""))
    if q:
        items = [i for i in items if q in normalize(i.get("es", "")) or q in normalize(i.get("en", ""))]
    if query.get("reg"):
        items = [i for i in items if i.get("reg") == query["reg"]]
    topics = sorted({i.get("topic") for i in C().vocab.values() if i.get("topic")})
    total = len(items)
    start = int(query.get("offset") or 0)
    return {"items": [serve_vocab(i) for i in items[start:start + 100]], "total": total, "topics": topics}


@route("GET", "culture")
def culture(query, body):
    notes = []
    for n in C().culture.values():
        if n.get("reg") == "vulgar" and not vulgar_ok():
            continue
        n = copy.deepcopy(n)
        n["examples"] = with_audio(n.get("examples"))
        notes.append(n)
    return {"notes": notes,
            "dialogues": [{"id": d["id"], "title": d.get("title"), "level": d.get("level"),
                           "kind": d.get("kind", "dialogue"), "setting": d.get("setting"),
                           "listen_first": bool(d.get("listen_first"))}
                          for d in C().dialogues.values()]}


@route("GET", "dialogue/*")
def dialogue(query, body, did):
    d = C().dialogues.get(did)
    if not d:
        raise ApiError("No such dialogue", 404)
    out = serve_dialogue(d)
    from . import course
    ch = course.chapter(did)
    if ch:                                       # a reading chapter of the course
        cs = course.course()
        si = cs["index"][did][0]
        st = P().data["units"].get(did) or {}
        out["chapter"] = {"stage_n": si + 1, "stage_title": cs["stages"][si]["title"], "pos": ch["pos"] + 1,
                          "count": len(cs["stages"][si]["chapters"]), "completed": bool(st.get("completed"))}
        out["next_chapter"] = course.next_after(did, P().data)
    return out
