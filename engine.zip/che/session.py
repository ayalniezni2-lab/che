"""Daily session ("Today"), free practice, placement test and stats."""
import random
from datetime import date, timedelta

from . import srs, explain
from .api import route, ApiError, C, P, A
from .api_learn import serve_exercise, vulgar_ok, serve_vocab, learner_taught, E
from . import drills, knowledge

ITEMS_FOR_MINUTES = {10: 22, 15: 32, 25: 52}


def taught_gate():
    """(allow, sentence_ok, focus) for drills that must stick to what the lessons have taught."""
    t = learner_taught()

    def allow(inf, tense):
        if tense not in t["tenses"]:
            return False                      # a tense no lesson has taught yet: never in a drill
        return True if knowledge.cell_taught(t, E(), inf, tense) else "new"   # new verb: its table first

    def sentence_ok(sent):
        v = sent.get("verb") or {}
        return not v.get("inf") or allow(v["inf"], v.get("tense", "pres")) is True

    return allow, sentence_ok, knowledge.focus_tense(P().data, C(), t), t


# ------------------------------------------------------------------ rebuilding an exercise from its key
def key_retired(key):
    """True for reviews / mistakes whose lesson, dialogue or word has been switched off ("retired": true)."""
    parts = key.split(":")
    if parts[0] == "ex":
        return key[3:] not in C().exercises
    if parts[0] == "vocab" and len(parts) == 3:
        return parts[1] in C().retired
    return False


def exercise_for_key(key):
    parts = key.split(":")
    kind = parts[0]
    try:
        if kind == "verb" and len(parts) == 4:
            inf, tense, person = parts[1], parts[2], (None if parts[3] == "-" else parts[3])
            v = C().verbs.get(inf)
            if v is None or not drills.verb_allowed(v, tense, person):
                return None
            if v.get("reg") == "vulgar" and not vulgar_ok():
                return None
            return drills.make_conj(inf, tense, person)
        if kind == "vocab" and len(parts) == 3:
            it = C().vocab.get(parts[1])
            if it is None or (it.get("reg") == "vulgar" and not vulgar_ok()):
                return None
            mode = parts[2]
            if mode == "listen" and it.get("no_audio"):
                mode = "es2en"
            if mode == "listen":
                mode = random.choice(["listen", "dictation"]) if it.get("ex") else "listen"
            return drills.make_vocab(it, mode)
        if kind == "ex":
            found = C().exercises.get(key[3:])
            if found:
                ex = dict(found[0])
                ex["key"] = key
                return ex
        if kind == "tpl":
            from . import templates
            return templates.exercise_for(C(), key)
    except Exception:
        return None
    return None


def due_keys():
    today = srs.today()
    cards = P().data["srs"]
    due = [(c.get("due", ""), srs.weakness(c), k) for k, c in cards.items() if srs.is_due(c, today)]
    due.sort(key=lambda x: (x[0], -x[1]))
    return [k for _, _, k in due]


def intro_card(item):
    it = serve_vocab(item)
    return {"id": "intro:" + item["id"], "type": "intro", "item": it, "generated": True}


def build_today():
    p = P().data
    minutes = int(p["settings"].get("session_minutes") or 15)
    target = ITEMS_FOR_MINUTES.get(minutes, int(minutes * 2.1))
    level = drills.learner_level()
    used, items = set(), []

    def add(ex, bucket):
        if not ex:
            return False
        key = ex.get("key") or ex.get("id")
        if key in used:
            return False
        used.add(key)
        ex["bucket"] = bucket
        items.append(ex)
        return True

    # 1. the chapter being learned now (course.py): fresh questions from it, about a quarter of the session
    from . import course
    n_ch = 0
    ch = course.today_chapter(p)
    if ch:
        unit = C().units.get(ch["id"]) or {}
        pool = [x for x in unit.get("exercises", []) if x.get("type") != "dialogue_q"
                and (vulgar_ok() or x.get("reg") != "vulgar")]
        random.shuffle(pool)
        pool.sort(key=lambda x: ("ex:" + x["id"]) in p["srs"])        # not practised yet first
        for x in pool:
            if n_ch >= target // 4:
                break
            if add(dict(x, key="ex:" + x["id"]), "chapter"):
                n_ch += 1

    # 2. mistakes to fix (about a sixth)
    mistakes = [m for m in p["mistakes"] if not m.get("resolved") and m.get("ex") and not key_retired(m["key"])]
    mistakes.sort(key=lambda m: (m.get("last", ""),), reverse=True)
    n_mist = 0
    for m in mistakes:
        if n_mist >= max(2, target // 6):
            break
        ex = exercise_for_key(m["key"]) or dict(m["ex"])
        if add(ex, "mistake"):
            n_mist += 1

    # 3. reviews that are due (up to about 40%): earlier chapters and tenses keep coming back
    n_due = 0
    for key in due_keys():
        if n_due >= (target * 2) // 5 or len(items) >= target:
            break
        if add(exercise_for_key(key), "review"):
            n_due += 1

    # 3. new material: a few new words (shown first, tested later) + fresh verb cells
    n_new_words = 0
    intros = []
    seen_vocab = {k.split(":")[1] for k in p["srs"] if k.startswith("vocab:")}
    lv = drills.LEVELS.index(level)
    fresh = [it for it in C().vocab_list(include_vulgar=False)
             if it["id"] not in seen_vocab and drills.LEVELS.index(it.get("level") or "a1") <= lv]
    # slang is never pushed: it comes after the everyday words of each level (most frequent first)
    fresh.sort(key=lambda it: (it.get("reg") == "slang", it.get("rank") or 99999))
    at_level = [it for it in fresh if it.get("level") == level]
    below = [it for it in fresh if it.get("level") != level]
    want_new = max(0, min(max(3, target // 8), (target - len(items)) // 2))
    # half the new words from the learner's own level, half filling gaps below it
    picked = at_level[:(want_new + 1) // 2]
    picked += below[:want_new - len(picked)]
    picked += [it for it in at_level if it not in picked][:want_new - len(picked)]
    # ... and slang stays under 1 in 10 of all the new words a learner has met
    slang_seen = sum(1 for k in seen_vocab if (C().vocab.get(k) or {}).get("reg") == "slang")
    slang_room = max(0, (len(seen_vocab) + len(picked)) // 10 - slang_seen)
    for it in [it for it in picked if it.get("reg") == "slang"][slang_room:]:
        picked.remove(it)
    for it in picked:
        intros.append(intro_card(it))
        add(drills.make_vocab(it, "es2en"), "new")
        add(drills.make_vocab(it, "en2es"), "new")
        n_new_words += 1

    # 4. fill up with weighted drills (weak spots + frequent verbs + listening) — only what lessons have taught,
    #    most of the verb practice on the tense being learned now (one tense at a time)
    allow, sentence_ok, focus, taught = taught_gate()
    room = target - len(items)
    if room > 0:
        n_conj = (room + 1) // 2
        for ex in drills.pick_conj(n_conj, level=level, exclude=used, allow=allow, prefer=focus, max_new=2):
            add(ex, "drill")
        for ex in drills.pick_vocab(target - len(items), level=level, new_ok=False, exclude=used,
                                    modes=("en2es", "listen", "dictation")):
            add(ex, "drill")
    try:
        from . import templates
        for ex in templates.pick(C(), P(), max(0, min(6, target - len(items))), level,
                                 sentence_ok=sentence_ok, tenses=taught["tenses"]):
            add(ex, "drill")
    except Exception:
        pass
    room = target - len(items)
    if room > 0:
        for ex in drills.pick_conj(room, level=level, exclude=used, allow=allow, prefer=focus, max_new=0):
            add(ex, "drill")
    for ex in [x for x in items if x.get("new_pair")]:       # teach first: the table, then the questions
        if not any(i.get("id") == "verbintro:%s:%s" % (ex["verb"]["inf"], ex["verb"]["tense"]) for i in intros):
            intros.append(drills.verb_intro(ex["verb"]["inf"], ex["verb"]["tense"]))

    # order: everything mixed, so older material comes back every few questions between the new chapter's;
    # tests of new words never directly after their intro
    new = [x for x in items if x["bucket"] == "new"]
    body = [x for x in items if x["bucket"] != "new"]
    random.shuffle(body)
    random.shuffle(new)
    out = list(intros)
    step = max(2, len(body) // (len(new) + 1)) if new else 0
    pos = 0
    for i, ex in enumerate(body):
        out.append(ex)
        if new and step and (i + 1) % step == 0 and pos < len(new) and i >= 2:
            out.append(new[pos])
            pos += 1
    out += new[pos:]
    served = [x if x.get("type") == "intro" else serve_exercise(x) for x in out]
    nxt = next_unit()
    return {"items": served, "minutes": minutes,
            "summary": {"chapter": n_ch, "chapter_title": ch["title"] if ch and n_ch else None,
                        "mistakes": n_mist, "reviews": n_due, "new_words": n_new_words,
                        "drills": len([x for x in items if x["bucket"] == "drill"])},
            "next_unit": nxt}


def next_unit():
    """The next chapter on the path (course.py): the first one in the current stage that is not done."""
    from . import course
    p = P().data
    return course.chapter_out(course.next_chapter(p), p)


@route("POST", "session/today")
def session_today(query, body):
    C().reload_if_changed()
    return build_today()


@route("POST", "session/finish")
def session_finish(query, body):
    p = P()
    with p.lock:
        from . import course
        course.ensure_saved(p.data)
        p.log_session()
        p.save()
        p.backup()
    return {"streak": p.streak()}


@route("POST", "drill")
def drill(query, body):
    """Endless practice.  body: {kind: conj|vocab|listen|sentences|mixed, n, tenses?, verbs?, level?, topic?}"""
    kind = body.get("kind", "mixed")
    n = max(1, min(int(body.get("n") or 12), 40))
    level = body.get("level") or None
    items = []
    allow, sentence_ok, focus, taught = taught_gate()

    def chosen(inf, tense):                   # the learner picked the tenses: allowed, new verbs get their table
        return True if knowledge.cell_taught(taught, E(), inf, tense) else "new"

    if kind == "conj":
        tenses = body.get("tenses") or sorted(taught["tenses"]) or ["pres"]     # none picked = what was taught
        items = drills.pick_conj(n, tenses=tenses, verbs=body.get("verbs") or None, level=level,
                                 allow=chosen, max_new=2)
    elif kind == "tense":
        # a workout for one tense: its table for anything new, the forms person by person, then sentences
        tense = body.get("tense") or focus or "pres"
        from . import templates
        conj = drills.pick_conj(max(6, n - 4), tenses=[tense], level=level, allow=chosen, max_new=1)
        sents = [x for x in templates.pick(C(), P(), 8, level or drills.learner_level(), sentence_ok=sentence_ok,
                                           tenses=[tense])
                 if (x.get("verb") or {}).get("tense") == tense][:4]
        items = conj[:3] + sents[:2] + conj[3:] + sents[2:]
    elif kind == "vocab":
        items = drills.pick_vocab(n, level=level, topic=body.get("topic") or None, modes=("en2es", "es2en"))
    elif kind == "listen":
        items = drills.pick_vocab(n, level=level, topic=body.get("topic") or None, modes=("listen", "dictation"))
    elif kind == "sentences":
        from . import templates
        items = templates.pick(C(), P(), n, level or drills.learner_level(), sentence_ok=sentence_ok,
                               tenses=taught["tenses"])
    else:
        items = drills.pick_conj(n // 3 + 1, level=level, allow=allow, prefer=focus, max_new=1)
        items += drills.pick_vocab(n // 3 + 1, level=level)
        try:
            from . import templates
            items += templates.pick(C(), P(), n // 3, level or drills.learner_level(), sentence_ok=sentence_ok,
                                    tenses=taught["tenses"])
        except Exception:
            pass
        random.shuffle(items)
        items = items[:n]
    served = [serve_exercise(x) for x in items]
    return {"items": drills.with_verb_intros(served)}


@route("GET", "pace")
def pace(query, body):
    """The tenses taught so far, in lesson order, with how comfortable the learner is with each."""
    p = P().data
    t = learner_taught()
    focus = knowledge.focus_tense(p, C(), t)
    out = []
    for tense in knowledge.curriculum(C())["tense_order"]:
        if tense not in t["tenses"] or tense in ("ger", "pp"):
            continue
        acc, n = knowledge.tense_score(p, tense)
        out.append({"tense": tense, "label": explain.tense_label(tense, long=True), "accuracy": round(100 * acc),
                    "answers": n, "mastered": knowledge.comfortable(p, t, tense), "focus": tense == focus,
                    "placement": tense in t["assumed_tenses"] and n == 0})
    return {"tenses": out, "goal": round(100 * knowledge.MASTERY), "min_answers": knowledge.MASTERY_MIN}


# ------------------------------------------------------------------ placement test
@route("GET", "placement")
def placement(query, body):
    data = C().meta.get("placement") or {}
    blocks = []
    for lv in drills.LEVELS:
        qs = [serve_exercise(dict(q, level=lv, topic="placement")) for q in data.get(lv, [])]
        blocks.append({"level": lv, "questions": qs})
    return {"blocks": blocks, "pass_mark": data.get("pass_mark", 0.67), "intro": data.get("intro")}


@route("POST", "placement/finish")
def placement_finish(query, body):
    level = body.get("level")
    if level not in drills.LEVELS:
        raise ApiError("bad level")
    p = P()
    with p.lock:
        p.data["placement"] = {"done": True, "level": level, "date": srs.today(),
                               "detail": body.get("detail") or {}}
        # the path starts at the stage that fits the result; earlier stages count as known
        from . import course
        cs = course.course()
        ids = [st["id"] for st in cs["stages"]]
        sid = cs["placement"].get(level, ids[0])
        p.data["course"] = {"stage": sid, "start": sid}
        p.save()
    return {"placement": p.data["placement"], "next_unit": next_unit()}


# ------------------------------------------------------------------ stats
@route("GET", "stats")
def stats(query, body):
    p = P().data
    cards = p["srs"]
    vocab_cards = {}
    for k, card in cards.items():
        if k.startswith("vocab:"):
            vocab_cards.setdefault(k.split(":")[1], []).append(card)
    words_known = sum(1 for cs in vocab_cards.values() if any(srs.is_known(c) for c in cs))
    verbs = {}
    tenses = {}
    for k, card in cards.items():
        if not k.startswith("verb:"):
            continue
        _, inf, tense, _ = k.split(":")
        verbs.setdefault(inf, []).append(card)
        t = tenses.setdefault(tense, {"seen": 0, "right": 0})
        t["seen"] += card.get("seen", 0)
        t["right"] += card.get("right", 0)
    mastered = [inf for inf, cs in verbs.items() if len([c for c in cs if c.get("reps", 0) >= 2]) >= 6]
    by_tense = [{"tense": t, "label": explain.tense_label(t), "seen": v["seen"],
                 "acc": round(v["right"] / v["seen"], 3) if v["seen"] else None} for t, v in tenses.items()]
    by_tense.sort(key=lambda x: (x["acc"] is None, x["acc"]))
    topics = [{"topic": explain.topic_label(t), "key": t, "seen": v["seen"], "acc": round(v["right"] / v["seen"], 3)}
              for t, v in p["topic_stats"].items() if v.get("seen")]
    topics.sort(key=lambda x: x["acc"])
    weakest = [t for t in topics if t["seen"] >= 5][:6]
    weak_verbs = sorted(((inf, sum(c.get("right", 0) for c in cs), sum(c.get("seen", 0) for c in cs))
                         for inf, cs in verbs.items()), key=lambda x: (x[1] / x[2]) if x[2] else 1)
    weak_verbs = [{"inf": i, "acc": round(r / s, 3), "seen": s} for i, r, s in weak_verbs if s >= 4][:8]
    days = []
    for i in range(13, -1, -1):
        d = (date.today() - timedelta(days=i)).isoformat()
        h = p["history"].get(d, {})
        days.append({"date": d, "answers": h.get("answers", 0), "correct": h.get("correct", 0),
                     "minutes": round(h.get("seconds", 0) / 60)})
    total_a = sum(h.get("answers", 0) for h in p["history"].values())
    total_c = sum(h.get("correct", 0) for h in p["history"].values())
    levels = []
    for lv in C().levels:
        units = C().units_of_level(lv["id"])
        levels.append({"id": lv["id"], "name": lv["name"], "units": len(units),
                       "done": sum(1 for u in units if p["units"].get(u["id"], {}).get("completed"))})
    return {
        "streak": P().streak(), "words_known": words_known, "words_seen": len(vocab_cards),
        "words_total": len(C().vocab), "verbs_mastered": len(mastered), "verbs_practised": len(verbs),
        "verbs_total": len(C().verbs), "accuracy": round(total_c / total_a, 3) if total_a else None,
        "answers_total": total_a, "due": len(due_keys()),
        "mistakes_open": len([m for m in p["mistakes"] if not m.get("resolved")]),
        "topics": topics, "weakest": weakest, "by_tense": by_tense, "weak_verbs": weak_verbs,
        "days": days, "levels": levels, "mastered": sorted(mastered)[:60],
    }
