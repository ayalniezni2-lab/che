"""Daily session ("Today"), free practice, placement test and stats."""
import random
from datetime import date, timedelta

from . import srs, explain
from .api import route, ApiError, C, P, A
from .api_learn import serve_exercise, vulgar_ok, serve_vocab
from . import drills

ITEMS_FOR_MINUTES = {10: 22, 15: 32, 25: 52}


# ------------------------------------------------------------------ rebuilding an exercise from its key
def exercise_for_key(key):
    parts = key.split(":")
    kind = parts[0]
    try:
        if kind == "verb" and len(parts) == 4:
            inf, tense, person = parts[1], parts[2], (None if parts[3] == "-" else parts[3])
            v = C().verbs.get(inf)
            if v is None or not drills.verb_allowed(v, tense, person):
                return None
            if v.get("reg") == "vulgar" and not vulgar_ok():
                return None
            return drills.make_conj(inf, tense, person)
        if kind == "vocab" and len(parts) == 3:
            it = C().vocab.get(parts[1])
            if it is None or (it.get("reg") == "vulgar" and not vulgar_ok()):
                return None
            mode = parts[2]
            if mode == "listen" and it.get("no_audio"):
                mode = "es2en"
            if mode == "listen":
                mode = random.choice(["listen", "dictation"]) if it.get("ex") else "listen"
            return drills.make_vocab(it, mode)
        if kind == "ex":
            found = C().exercises.get(key[3:])
            if found:
                ex = dict(found[0])
                ex["key"] = key
                return ex
        if kind == "tpl":
            from . import templates
            return templates.exercise_for(C(), key)
    except Exception:
        return None
    return None


def due_keys():
    today = srs.today()
    cards = P().data["srs"]
    due = [(c.get("due", ""), srs.weakness(c), k) for k, c in cards.items() if srs.is_due(c, today)]
    due.sort(key=lambda x: (x[0], -x[1]))
    return [k for _, _, k in due]


def intro_card(item):
    it = serve_vocab(item)
    return {"id": "intro:" + item["id"], "type": "intro", "item": it, "generated": True}


def build_today():
    p = P().data
    minutes = int(p["settings"].get("session_minutes") or 15)
    target = ITEMS_FOR_MINUTES.get(minutes, int(minutes * 2.1))
    level = drills.learner_level()
    used, items = set(), []

    def add(ex, bucket):
        if not ex:
            return False
        key = ex.get("key") or ex.get("id")
        if key in used:
            return False
        used.add(key)
        ex["bucket"] = bucket
        items.append(ex)
        return True

    # 1. mistakes to fix (about a fifth of the session)
    mistakes = [m for m in p["mistakes"] if not m.get("resolved") and m.get("ex")]
    mistakes.sort(key=lambda m: (m.get("last", ""),), reverse=True)
    n_mist = 0
    for m in mistakes:
        if n_mist >= max(3, target // 5):
            break
        ex = exercise_for_key(m["key"]) or dict(m["ex"])
        if add(ex, "mistake"):
            n_mist += 1

    # 2. reviews that are due (about half)
    n_due = 0
    for key in due_keys():
        if n_due >= target // 2:
            break
        if add(exercise_for_key(key), "review"):
            n_due += 1

    # 3. new material: a few new words (shown first, tested later) + fresh verb cells
    n_new_words = 0
    intros = []
    seen_vocab = {k.split(":")[1] for k in p["srs"] if k.startswith("vocab:")}
    lv = drills.LEVELS.index(level)
    fresh = [it for it in C().vocab_list(include_vulgar=False)
             if it["id"] not in seen_vocab and drills.LEVELS.index(it.get("level") or "a1") <= lv]
    # slang is never pushed: it comes after the everyday words of each level (most frequent first)
    fresh.sort(key=lambda it: (it.get("reg") == "slang", it.get("rank") or 99999))
    at_level = [it for it in fresh if it.get("level") == level]
    below = [it for it in fresh if it.get("level") != level]
    want_new = max(4, target // 6)
    # half the new words from the learner's own level, half filling gaps below it
    picked = at_level[:(want_new + 1) // 2]
    picked += below[:want_new - len(picked)]
    picked += [it for it in at_level if it not in picked][:want_new - len(picked)]
    # ... and slang stays under 1 in 10 of all the new words a learner has met
    slang_seen = sum(1 for k in seen_vocab if (C().vocab.get(k) or {}).get("reg") == "slang")
    slang_room = max(0, (len(seen_vocab) + len(picked)) // 10 - slang_seen)
    for it in [it for it in picked if it.get("reg") == "slang"][slang_room:]:
        picked.remove(it)
    for it in picked:
        intros.append(intro_card(it))
        add(drills.make_vocab(it, "es2en"), "new")
        add(drills.make_vocab(it, "en2es"), "new")
        n_new_words += 1

    # 4. fill up with weighted drills (weak spots + frequent verbs + listening)
    room = target - len(items)
    if room > 0:
        n_conj = (room + 1) // 2
        for ex in drills.pick_conj(n_conj, level=level, exclude=used):
            add(ex, "drill")
        for ex in drills.pick_vocab(target - len(items), level=level, new_ok=False, exclude=used,
                                    modes=("en2es", "listen", "dictation")):
            add(ex, "drill")
    try:
        from . import templates
        for ex in templates.pick(C(), P(), max(0, min(6, target - len(items) + 3)), level):
            add(ex, "drill")
    except Exception:
        pass
    room = target - len(items)
    if room > 0:
        for ex in drills.pick_conj(room, level=level, exclude=used):
            add(ex, "drill")

    # order: mistakes early, the rest shuffled; tests of new words never directly after their intro
    mist = [x for x in items if x["bucket"] == "mistake"]
    new = [x for x in items if x["bucket"] == "new"]
    rest = [x for x in items if x["bucket"] not in ("mistake", "new")]
    random.shuffle(rest)
    random.shuffle(new)
    body = mist + rest
    out = list(intros)
    step = max(2, len(body) // (len(new) + 1)) if new else 0
    pos = 0
    for i, ex in enumerate(body):
        out.append(ex)
        if new and step and (i + 1) % step == 0 and pos < len(new) and i >= 2:
            out.append(new[pos])
            pos += 1
    out += new[pos:]
    served = [x if x.get("type") == "intro" else serve_exercise(x) for x in out]
    nxt = next_unit()
    return {"items": served, "minutes": minutes,
            "summary": {"mistakes": n_mist, "reviews": n_due, "new_words": n_new_words,
                        "drills": len([x for x in items if x["bucket"] == "drill"])},
            "next_unit": nxt}


def next_unit():
    p = P().data
    lvl = (p.get("placement") or {}).get("level") or "a1"
    start = drills.LEVELS.index(lvl)
    units = [u for u in C().unit_order if vulgar_ok() or u.get("reg") != "vulgar"]
    for u in units:
        if drills.LEVELS.index(u.get("level", "a1")) >= start and not p["units"].get(u["id"], {}).get("completed"):
            return {"id": u["id"], "title": u.get("title"), "goal": u.get("goal"), "level": u.get("level")}
    for u in units:
        if not p["units"].get(u["id"], {}).get("completed"):
            return {"id": u["id"], "title": u.get("title"), "goal": u.get("goal"), "level": u.get("level")}
    return None


@route("POST", "session/today")
def session_today(query, body):
    C().reload_if_changed()
    return build_today()


@route("POST", "session/finish")
def session_finish(query, body):
    p = P()
    with p.lock:
        p.log_session()
        p.save()
        p.backup()
    return {"streak": p.streak()}


@route("POST", "drill")
def drill(query, body):
    """Endless practice.  body: {kind: conj|vocab|listen|sentences|mixed, n, tenses?, verbs?, level?, topic?}"""
    kind = body.get("kind", "mixed")
    n = max(1, min(int(body.get("n") or 12), 40))
    level = body.get("level") or None
    items = []
    if kind == "conj":
        items = drills.pick_conj(n, tenses=body.get("tenses") or None, verbs=body.get("verbs") or None, level=level)
    elif kind == "vocab":
        items = drills.pick_vocab(n, level=level, topic=body.get("topic") or None, modes=("en2es", "es2en"))
    elif kind == "listen":
        items = drills.pick_vocab(n, level=level, topic=body.get("topic") or None, modes=("listen", "dictation"))
    elif kind == "sentences":
        from . import templates
        items = templates.pick(C(), P(), n, level or drills.learner_level())
    else:
        items = drills.pick_conj(n // 3 + 1, level=level)
        items += drills.pick_vocab(n // 3 + 1, level=level)
        try:
            from . import templates
            items += templates.pick(C(), P(), n // 3, level or drills.learner_level())
        except Exception:
            pass
        random.shuffle(items)
        items = items[:n]
    return {"items": [serve_exercise(x) for x in items]}


# ------------------------------------------------------------------ placement test
@route("GET", "placement")
def placement(query, body):
    data = C().meta.get("placement") or {}
    blocks = []
    for lv in drills.LEVELS:
        qs = [serve_exercise(dict(q, level=lv, topic="placement")) for q in data.get(lv, [])]
        blocks.append({"level": lv, "questions": qs})
    return {"blocks": blocks, "pass_mark": data.get("pass_mark", 0.67), "intro": data.get("intro")}


@route("POST", "placement/finish")
def placement_finish(query, body):
    level = body.get("level")
    if level not in drills.LEVELS:
        raise ApiError("bad level")
    p = P()
    with p.lock:
        p.data["placement"] = {"done": True, "level": level, "date": srs.today(),
                               "detail": body.get("detail") or {}}
        p.save()
    return {"placement": p.data["placement"], "next_unit": next_unit()}


# ------------------------------------------------------------------ stats
@route("GET", "stats")
def stats(query, body):
    p = P().data
    cards = p["srs"]
    vocab_cards = {}
    for k, card in cards.items():
        if k.startswith("vocab:"):
            vocab_cards.setdefault(k.split(":")[1], []).append(card)
    words_known = sum(1 for cs in vocab_cards.values() if any(srs.is_known(c) for c in cs))
    verbs = {}
    tenses = {}
    for k, card in cards.items():
        if not k.startswith("verb:"):
            continue
        _, inf, tense, _ = k.split(":")
        verbs.setdefault(inf, []).append(card)
        t = tenses.setdefault(tense, {"seen": 0, "right": 0})
        t["seen"] += card.get("seen", 0)
        t["right"] += card.get("right", 0)
    mastered = [inf for inf, cs in verbs.items() if len([c for c in cs if c.get("reps", 0) >= 2]) >= 6]
    by_tense = [{"tense": t, "label": explain.tense_label(t), "seen": v["seen"],
                 "acc": round(v["right"] / v["seen"], 3) if v["seen"] else None} for t, v in tenses.items()]
    by_tense.sort(key=lambda x: (x["acc"] is None, x["acc"]))
    topics = [{"topic": explain.topic_label(t), "key": t, "seen": v["seen"], "acc": round(v["right"] / v["seen"], 3)}
              for t, v in p["topic_stats"].items() if v.get("seen")]
    topics.sort(key=lambda x: x["acc"])
    weakest = [t for t in topics if t["seen"] >= 5][:6]
    weak_verbs = sorted(((inf, sum(c.get("right", 0) for c in cs), sum(c.get("seen", 0) for c in cs))
                         for inf, cs in verbs.items()), key=lambda x: (x[1] / x[2]) if x[2] else 1)
    weak_verbs = [{"inf": i, "acc": round(r / s, 3), "seen": s} for i, r, s in weak_verbs if s >= 4][:8]
    days = []
    for i in range(13, -1, -1):
        d = (date.today() - timedelta(days=i)).isoformat()
        h = p["history"].get(d, {})
        days.append({"date": d, "answers": h.get("answers", 0), "correct": h.get("correct", 0),
                     "minutes": round(h.get("seconds", 0) / 60)})
    total_a = sum(h.get("answers", 0) for h in p["history"].values())
    total_c = sum(h.get("correct", 0) for h in p["history"].values())
    levels = []
    for lv in C().levels:
        units = C().units_of_level(lv["id"])
        levels.append({"id": lv["id"], "name": lv["name"], "units": len(units),
                       "done": sum(1 for u in units if p["units"].get(u["id"], {}).get("completed"))})
    return {
        "streak": P().streak(), "words_known": words_known, "words_seen": len(vocab_cards),
        "words_total": len(C().vocab), "verbs_mastered": len(mastered), "verbs_practised": len(verbs),
        "verbs_total": len(C().verbs), "accuracy": round(total_c / total_a, 3) if total_a else None,
        "answers_total": total_a, "due": len(due_keys()),
        "mistakes_open": len([m for m in p["mistakes"] if not m.get("resolved")]),
        "topics": topics, "weakest": weakest, "by_tense": by_tense, "weak_verbs": weak_verbs,
        "days": days, "levels": levels, "mastered": sorted(mastered)[:60],
    }
