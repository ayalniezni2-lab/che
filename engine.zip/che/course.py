"""The course path (content/meta/course.json): stages of chapters, one tense at a time, and where the learner is.

Guided, nothing locked — every chapter can be opened at any time:
  * a chapter is a unit or a reading (a short text with questions); kinds: tense, irregular, topic, general, reading
  * the learner has a current stage; the next chapter is the first one in it that is not done
    (done = finished with 70%+, or skipped after a short check of 80%+, or "skip anyway")
  * a stage is finished when all its chapters are done and its goal tense is comfortable (80% over 12+ answers);
    the home page then offers the next stage — and "move on now" is always possible
  * drills only use the tenses of the stages reached (knowledge.py asks known_units() here)
"""
import random
from datetime import datetime

from . import explain, knowledge
from .api import route, ApiError, C, P

SKIP_CHECK_N = 6
SKIP_PASS = 0.8
LEVELS = ["a1", "a2", "b1", "b2"]
KINDS = {"tense": "New tense", "irregular": "Irregular verbs", "topic": "Topic", "general": "Break",
         "reading": "Reading"}

_CACHE = {"sig": None}


# ------------------------------------------------------------------ the course itself (cached per content load)
def course(c=None):
    c = c or C()
    if _CACHE["sig"] is c._sig and _CACHE.get("content") is c:
        return _CACHE["value"]
    meta = c.meta.get("course") or {}
    stages, index, upto = [], {}, set()
    for st in meta.get("stages", []):
        chs = []
        for ch in st.get("chapters", []):
            if ch.get("unit") in c.units:
                u = c.units[ch["unit"]]
                item = {"id": u["id"], "type": "unit", "kind": ch.get("kind", "general"), "title": u.get("title"),
                        "goal": u.get("goal", ""), "level": u.get("level"), "reg": u.get("reg")}
            elif ch.get("reading") in c.dialogues:
                d = c.dialogues[ch["reading"]]
                item = {"id": d["id"], "type": "reading", "kind": "reading", "title": d.get("title"),
                        "goal": "Read a short text, then answer questions about it.", "level": d.get("level")}
            else:
                continue
            item.update(stage=st["id"], pos=len(chs))
            chs.append(item)
        upto |= set(st.get("tenses", []))
        stages.append({"id": st["id"], "title": st.get("title", st["id"]), "short": st.get("short", ""),
                       "intro": st.get("intro", ""), "tenses": list(st.get("tenses", [])),
                       "goal": list(st.get("goal", [])), "upto": set(upto), "chapters": chs})
    listed = {ch["id"] for st in stages for ch in st["chapters"]}
    extra = [u for u in c.unit_order if u["id"] not in listed]
    if extra or not stages:                    # units the course does not list yet: an open stage at the end
        stages.append({"id": "more", "title": "More chapters", "short": "More", "intro": "", "tenses": [],
                       "goal": [], "upto": None,
                       "chapters": [{"id": u["id"], "type": "unit", "kind": "general", "title": u.get("title"),
                                     "goal": u.get("goal", ""), "level": u.get("level"), "reg": u.get("reg"),
                                     "stage": "more", "pos": i} for i, u in enumerate(extra)]})
    for si, st in enumerate(stages):
        for ch in st["chapters"]:
            index[ch["id"]] = (si, ch)
    value = {"stages": stages, "index": index, "placement": meta.get("placement") or {}}
    _CACHE.update(sig=c._sig, content=c, value=value)
    return value


def chapter(cid, c=None):
    hit = course(c)["index"].get(cid)
    return hit[1] if hit else None


def tenses_upto(uid, c=None):
    """The tenses a unit may teach: those of its stage and the stages before (None = no limit)."""
    hit = course(c)["index"].get(uid)
    return course(c)["stages"][hit[0]]["upto"] if hit else None


def visible(st, vulgar=False):
    return [ch for ch in st["chapters"] if vulgar or ch.get("reg") != "vulgar"]


def is_done(p, cid):
    s = p["units"].get(cid) or {}
    return bool(s.get("completed") or s.get("skipped"))


def _opened(p, cid):
    s = p["units"].get(cid) or {}
    return bool(s.get("started") or s.get("completed") or s.get("skipped"))


# ------------------------------------------------------------------ where the learner is
def _goal_ok(p, st, assumed):
    for tense in st["goal"]:
        if assumed:
            if knowledge.struggling(p, tense):
                return False
        elif not knowledge.mastered(p, tense):
            return False
    return True


def stage_finished(p, si, start=None, c=None):
    cs = course(c)
    st = cs["stages"][si]
    vulgar = bool(p["settings"].get("vulgar"))
    chapters_ok = all(is_done(p, ch["id"]) for ch in visible(st, vulgar))
    return chapters_ok and _goal_ok(p, st, assumed=start is not None and si < start)


def state(p, c=None):
    """(current stage index, start stage index). Stored in progress["course"]; worked out if missing."""
    cs = course(c)
    ids = [st["id"] for st in cs["stages"]]
    saved = p.get("course") or {}
    lvl = (p.get("placement") or {}).get("level") or "a1"
    start_id = saved.get("start") or cs["placement"].get(lvl) or ids[0]
    start = ids.index(start_id) if start_id in ids else 0
    if saved.get("stage") in ids:
        return ids.index(saved["stage"]), start
    cur = start
    last = len([s for s in cs["stages"] if s["id"] != "more"]) - 1
    while cur < last and stage_finished(p, cur, start, c):
        cur += 1
    return cur, start


def ensure_saved(p, c=None):
    """Fix the current stage in the progress file the first time the learner does something (from then on it
    changes only when the learner moves on — finishing a stage offers the next one, it never jumps by itself)."""
    if not (p.get("course") or {}).get("stage"):
        cur, _ = state(p, c)
        set_stage(p, cur, c)


def set_stage(p, si, c=None):
    cs = course(c)
    cur, start = state(p, c)
    p["course"] = {"stage": cs["stages"][si]["id"], "start": cs["stages"][start]["id"]}


def known_units(p, c=None):
    """(lesson units, assumed units) — what drills may build on. Stages before the current one count in full
    (chapters never opened there are taken as known); the current stage counts what was opened; later stages
    only what was finished or skipped."""
    cs = course(c)
    cur, _ = state(p, c)
    lesson, assumed = set(), set()
    for si, st in enumerate(cs["stages"]):
        for ch in st["chapters"]:
            if ch["type"] != "unit":
                continue
            cid = ch["id"]
            if si < cur:
                (lesson if _opened(p, cid) else assumed).add(cid)
            elif si == cur or st["id"] == "more":
                if _opened(p, cid):
                    lesson.add(cid)
            elif is_done(p, cid):
                lesson.add(cid)
    return lesson, assumed


def next_chapter(p, c=None):
    cs = course(c)
    cur, _ = state(p, c)
    vulgar = bool(p["settings"].get("vulgar"))
    for ch in visible(cs["stages"][cur], vulgar):
        if not is_done(p, ch["id"]):
            return ch
    return None


def today_chapter(p, c=None):
    """The chapter Today practises: the one being worked on (opened, not done) — else the last one finished."""
    cs = course(c)
    cur, _ = state(p, c)
    best, best_t = None, ""
    fallback, fallback_t = None, ""
    for ch in cs["stages"][cur]["chapters"]:
        if ch["type"] != "unit":
            continue
        s = p["units"].get(ch["id"]) or {}
        if s.get("started") and not is_done(p, ch["id"]) and s["started"] > best_t:
            best, best_t = ch, s["started"]
        done_t = s.get("completed") or s.get("skipped") or ""
        if s.get("completed") and done_t > fallback_t:
            fallback, fallback_t = ch, done_t
    return best or fallback


def chapter_out(ch, p):
    if not ch:
        return None
    s = p["units"].get(ch["id"]) or {}
    return {"id": ch["id"], "type": ch["type"], "kind": ch["kind"], "kind_label": KINDS.get(ch["kind"], ""),
            "title": ch["title"], "goal": ch.get("goal", ""), "level": ch.get("level"), "stage": ch["stage"],
            "pos": ch["pos"] + 1, "completed": bool(s.get("completed")), "skipped": bool(s.get("skipped")),
            "started": bool(s.get("started")), "best": s.get("best")}


def summary(p, c=None):
    """Everything the home page and the Learn tab need about the path."""
    cs = course(c)
    cur, start = state(p, c)
    vulgar = bool(p["settings"].get("vulgar"))
    stages = []
    for si, st in enumerate(cs["stages"]):
        chs = visible(st, vulgar)
        stages.append({"id": st["id"], "n": si + 1, "title": st["title"], "short": st["short"], "intro": st["intro"],
                       "count": len(chs), "done": sum(1 for ch in chs if is_done(p, ch["id"])),
                       "current": si == cur, "chapters": [chapter_out(ch, p) for ch in chs]})
    st = cs["stages"][cur]
    goals = []
    for tense in st["goal"]:
        acc, n = knowledge.tense_score(p, tense)
        goals.append({"tense": tense, "label": explain.tense_label(tense, long=True), "accuracy": round(100 * acc),
                      "answers": n, "ok": knowledge.mastered(p, tense) or (cur < start and not knowledge.struggling(p, tense))})
    nxt_stage = cs["stages"][cur + 1] if cur + 1 < len(cs["stages"]) else None
    return {"stages": stages, "current": cur, "start": start,
            "next": chapter_out(next_chapter(p, c), p),
            "finished": stage_finished(p, cur, start, c),
            "chapters_done": all(is_done(p, ch["id"]) for ch in visible(st, vulgar)),
            "goals": goals, "goal_pct": round(100 * knowledge.MASTERY), "goal_min": knowledge.MASTERY_MIN,
            "next_stage": {"id": nxt_stage["id"], "n": cur + 2, "title": nxt_stage["title"]} if nxt_stage else None}


# ------------------------------------------------------------------ routes
@route("GET", "course")
def get_course(query, body):
    C().reload_if_changed()
    return summary(P().data)


@route("POST", "course/stage")
def move_to_stage(query, body):
    """Make a stage the current one ("move on to the next tense", or go back)."""
    cs = course()
    ids = [st["id"] for st in cs["stages"]]
    sid = body.get("stage")
    if sid == "next":
        cur, _ = state(P().data)
        sid = ids[min(cur + 1, len(ids) - 1)]
    if sid not in ids:
        raise ApiError("No such stage: %s" % sid)
    p = P()
    with p.lock:
        set_stage(p.data, ids.index(sid))
        p.save()
    return summary(p.data)


@route("GET", "course/check/*")
def skip_check(query, body, cid):
    """A few questions from a chapter: pass them (80%) and the chapter is marked done."""
    from .api_learn import serve_exercise, vulgar_ok
    from .drills import unit_drills
    u = C().units.get(cid)
    if not u:
        raise ApiError("Only lessons have a check.", 404)
    pool = [x for x in u.get("exercises", []) if x.get("type") not in ("dialogue_q",)
            and (vulgar_ok() or x.get("reg") != "vulgar")]
    random.shuffle(pool)
    # verb and translation questions say most about whether the chapter is known: put them first
    pool.sort(key=lambda x: 0 if (x.get("verb") or x.get("type") in ("en2es", "fill")) else 1)
    picked = pool[:SKIP_CHECK_N]
    if len(picked) < SKIP_CHECK_N:
        picked += unit_drills(u)[:SKIP_CHECK_N - len(picked)]
    random.shuffle(picked)
    return {"items": [serve_exercise(x) for x in picked], "pass": round(100 * SKIP_PASS)}


@route("POST", "course/skip")
def skip_chapter(query, body):
    """Mark a chapter as known: after the check (right / total), or anyway (force)."""
    cid = body.get("id")
    if not chapter(cid) and cid not in C().units:
        raise ApiError("No such chapter: %s" % cid, 404)
    total = int(body.get("total") or 0)
    right = int(body.get("right") or 0)
    passed = bool(body.get("force")) or (total > 0 and right / total >= SKIP_PASS)
    p = P()
    if passed:
        with p.lock:
            ensure_saved(p.data)
            st = p.data["units"].setdefault(cid, {})
            st["skipped"] = st.get("skipped") or datetime.now().isoformat(timespec="seconds")
            if total:
                st["check"] = {"right": right, "total": total}
            p.save()
    return {"passed": passed, "next": next_after(cid, p.data)}


@route("POST", "course/reading")
def reading_done(query, body):
    """A reading chapter: its questions answered (70% ticks it off, like a lesson)."""
    cid = body.get("id")
    if cid not in C().dialogues:
        raise ApiError("No such reading: %s" % cid, 404)
    total = int(body.get("total") or 0)
    score = (int(body.get("right") or 0) / total) if total else 1.0
    p = P()
    with p.lock:
        ensure_saved(p.data)
        st = p.data["units"].setdefault(cid, {})
        now = datetime.now().isoformat(timespec="seconds")
        st.setdefault("started", now)
        st["best"] = max(st.get("best") or 0, round(score, 3))
        if score >= 0.7:
            st["completed"] = st.get("completed") or now
        p.log_session()
        p.save()
    return {"passed": score >= 0.7, "next": next_after(cid, p.data)}


def next_after(cid, p):
    """The chapter after this one in the course (for the "Next" button), skipping hidden ones."""
    cs = course()
    vulgar = bool(p["settings"].get("vulgar"))
    flat = [ch for st in cs["stages"] for ch in visible(st, vulgar)]
    ids = [ch["id"] for ch in flat]
    if cid not in ids:
        return None
    i = ids.index(cid)
    return chapter_out(flat[i + 1], p) if i + 1 < len(flat) else None
