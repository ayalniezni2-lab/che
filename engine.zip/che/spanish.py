"""Spanish spelling utilities: normalization, syllable nuclei, stress and written accents.

Used by the conjugation engine (vos commands with pronouns: decime -> decímelo, compounds:
vio -> previó) and by grading (accent-insensitive comparison).
"""
import re
import unicodedata

STRONG = set("aeoáéó")
WEAK = set("iuü")
ACUTE = {"á": "a", "é": "e", "í": "i", "ó": "o", "ú": "u"}
ADD_ACUTE = {v: k for k, v in ACUTE.items()}
VOWELS = STRONG | WEAK | {"í", "ú"}


def strip_acute(word):
    """Remove acute accents only (keeps ñ and ü)."""
    return "".join(ACUTE.get(c, c) for c in word)


def fold(text):
    """Accent/ñ-insensitive folding of one string: tenés -> tenes, mañana -> manana."""
    text = unicodedata.normalize("NFD", text.lower())
    text = "".join(c for c in text if unicodedata.category(c) != "Mn")
    return unicodedata.normalize("NFC", text)


_PUNCT = re.compile(r"[¿?¡!.,;:\"“”«»()\[\]…—–\-]+")


def normalize(text):
    """Grading normalization: lowercase, no accents, ñ->n, no ¿¡/punctuation, single spaces."""
    text = fold(text or "")
    text = text.replace("’", "'").replace("`", "'")
    text = _PUNCT.sub(" ", text)
    text = text.replace("'", "")
    return re.sub(r"\s+", " ", text).strip()


_UNITS = ("cero uno dos tres cuatro cinco seis siete ocho nueve diez once doce trece catorce quince dieciseis "
          "diecisiete dieciocho diecinueve veinte veintiuno veintidos veintitres veinticuatro veinticinco veintiseis "
          "veintisiete veintiocho veintinueve").split()
_TENS = {3: "treinta", 4: "cuarenta", 5: "cincuenta", 6: "sesenta", 7: "setenta", 8: "ochenta", 9: "noventa"}
_HUNDREDS = {1: "ciento", 2: "doscientos", 3: "trescientos", 4: "cuatrocientos", 5: "quinientos",
             6: "seiscientos", 7: "setecientos", 8: "ochocientos", 9: "novecientos"}


def _words_below_1000(n):
    if n == 100:
        return "cien"
    out = []
    if n >= 100:
        out.append(_HUNDREDS[n // 100])
        n %= 100
    if n >= 30:
        out.append(_TENS[n // 10] + (" y " + _UNITS[n % 10] if n % 10 else ""))
    elif n or not out:
        out.append(_UNITS[n])
    return " ".join(out)


def number_words(n):
    """38 -> treinta y ocho, 2500 -> dos mil quinientos (no accents: for comparing normalized text)."""
    if n >= 1000000:
        return str(n)
    th, rest = divmod(n, 1000)
    out = []
    if th:
        out.append("mil" if th == 1 else _words_below_1000(th).replace("uno", "un") + " mil")
    if rest or not th:
        out.append(_words_below_1000(rest))
    return " ".join(out)


def spell_numbers(norm):
    """In NORMALIZED text (punctuation already turned into spaces, so 2.500 reads '2 500'): digits -> words,
    and un / una / uno -> uno, so '3' = 'tres' and 'calzo 38' = 'calzo treinta y ocho'."""
    text = re.sub(r"\b\d{1,3}(?: \d{3})+\b|\b\d+\b", lambda m: number_words(int(m.group(0).replace(" ", ""))), norm)
    return re.sub(r"\b(?:un|una|veintiun|veintiuna)\b", lambda m: "veintiuno" if m.group(0).startswith("v")
                  else "uno", text)


def tokens(text):
    """Word tokens with original spelling (accents kept), lowercased."""
    return re.findall(r"[a-záéíóúüñ]+", (text or "").lower())


def has_special(text):
    return bool(re.search(r"[áéíóúüñÁÉÍÓÚÜÑ¿¡]", text or ""))


# ------------------------------------------------------------------ syllable nuclei
def _vowel_positions(word):
    """Indexes of pronounced vowels.  Silent u (que, gui) is skipped; final y counts as i."""
    w = word.lower()
    out = []
    for i, c in enumerate(w):
        if c in VOWELS:
            if c == "u" and i > 0 and i + 1 < len(w):
                if w[i - 1] == "q" and w[i + 1] in "eiéí":
                    continue
                if w[i - 1] == "g" and w[i + 1] in "eiéí":
                    continue
            out.append(i)
        elif c == "y" and i == len(w) - 1 and i > 0 and w[i - 1] in VOWELS:
            out.append(i)
    return out


def nuclei(word):
    """List of syllable nuclei, each a list of letter indexes (diphthongs stay together)."""
    w = word.lower()
    groups = []
    cur = []
    for i in _vowel_positions(w):
        c = "i" if w[i] == "y" else w[i]
        if not cur or i != cur[-1] + 1:
            if cur:
                groups.append(cur)
            cur = [i]
            continue
        prev = "i" if w[cur[-1]] == "y" else w[cur[-1]]
        has_strong = any(w[j] in STRONG for j in cur)
        if c in "íú" or prev in "íú":
            groups.append(cur)          # accented weak vowel = hiatus (re-í, ca-í-a)
            cur = [i]
        elif c in STRONG and has_strong:
            groups.append(cur)          # two strong vowels = two syllables (le-o, ca-e)
            cur = [i]
        else:
            cur.append(i)               # diphthong / triphthong
    if cur:
        groups.append(cur)
    return groups


def count_syllables(word):
    return len(nuclei(word))


def stress_index(word):
    """Index (from the start) of the stressed nucleus."""
    w = word.lower()
    ns = nuclei(w)
    if not ns:
        return 0
    for k, g in enumerate(ns):
        if any(w[j] in ACUTE for j in g):
            return k
    if len(ns) == 1:
        return 0
    if w[-1] in "aeiouns":
        return len(ns) - 2
    return len(ns) - 1


def put_stress(word, idx):
    """Rewrite `word` so its written accent matches stress on nucleus `idx` (from the start).

    `word` may still carry its old accent: it is used to detect hiatus, then removed."""
    w = word.lower()
    ns = nuclei(w)
    if not ns:
        return w
    idx = max(0, min(idx, len(ns) - 1))
    g = ns[idx]
    plain = strip_acute(w)
    from_end = len(ns) - 1 - idx
    # which vowel of the nucleus carries the stress
    strong = [j for j in g if plain[j] in "aeo"]
    target = strong[0] if strong else g[-1]
    if plain[target] == "y":
        target = g[0]
    need = False
    if len(ns) == 1:
        need = False
    elif from_end == 0:
        need = plain[-1] in "aeiouns"
    elif from_end == 1:
        need = plain[-1] not in "aeiouns"
    else:
        need = True
    # hiatus: a stressed weak vowel that touches a strong vowel always takes the accent (reí, oíme)
    if len(g) == 1 and plain[target] in "iu":
        before = plain[target - 1] if target > 0 else ""
        after = plain[target + 1] if target + 1 < len(plain) else ""
        if before in "aeo" or after in "aeo":
            need = True
    if need and plain[target] in ADD_ACUTE:
        return plain[:target] + ADD_ACUTE[plain[target]] + plain[target + 1:]
    return plain


def attach(form, *pronouns):
    """Attach object pronouns to a command / -ndo form / infinitive, fixing the accent.

    attach('decí','me') -> 'decime'; attach('decí','me','lo') -> 'decímelo';
    attach('diga','me') -> 'dígame'; attach('levantá','te') -> 'levantate'."""
    idx = stress_index(form)
    return put_stress(form + "".join(pronouns), idx)


def with_prefix(prefix, form):
    """Compound verbs: mantener = man + tener.  Re-computes the accent (vio -> previó)."""
    if " " in form:                     # compound tense or reflexive: prefix the last word
        head, last = form.rsplit(" ", 1)
        return head + " " + with_prefix(prefix, last)
    base_idx = stress_index(form)
    extra = len(nuclei(prefix))
    return put_stress(prefix + form, base_idx + extra)


def diff_parts(actual, regular):
    """Split `actual` into [(text, is_irregular)] by comparing with the regular form."""
    if actual == regular or not regular:
        return [(actual, False)]
    a, r = actual, regular
    p = 0
    while p < len(a) and p < len(r) and a[p] == r[p]:
        p += 1
    s = 0
    while s < len(a) - p and s < len(r) - p and a[len(a) - 1 - s] == r[len(r) - 1 - s]:
        s += 1
    mid = a[p:len(a) - s]
    if not mid:                          # pure deletion: mark the letter after the gap
        if p < len(a):
            return [(a[:p], False), (a[p:p + 1], True), (a[p + 1:], False)]
        return [(a, True)]
    parts = [(a[:p], False), (mid, True), (a[len(a) - s:], False)]
    return [(t, f) for t, f in parts if t]
