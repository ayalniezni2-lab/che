"""Sentence templates: varied, always-grammatical practice sentences, with no AI at run time.

A template only combines things that were written to go together: every verb option brings its
OWN list of objects ("with"), so the generator can never produce nonsense like "I drink a car".
Expansion is deterministic and capped, so tools/generate_audio.py can pre-record every sentence.

Template shape (content/templates/*.json, or a pack's "templates" list):
{
  "id": "t-a1-iraf-plans", "level": "a1", "topic": "future", "tense": "iraf",
  "es": "{time} {subj} {verb} {obj}.",      "en": "{time} {subj} {verb} {obj}.",
  "why": "...", "extra": {"es": "...", "en": "..."},
  "time": [{"es": "mañana", "en": "tomorrow"}],                       (optional)
  "subj": [{"es": "yo", "en": "I", "p": "yo"}, {"es": "mi hermana", "en": "my sister", "p": "el", "g": "f"}],
  "verbs": [{"inf": "comprar", "en": "buy", "with": [{"es": "un auto", "en": "a car"}]}],
  "cap": 40
}
or a plain sentence bank:  {"id": "...", "level": "...", "topic": "...", "why": "...",
                            "sentences": [{"es": "...", "en": "...", "verb": {...}?}]}
"""
import hashlib
import random
import re

from . import explain, srs

PRONOUN_SUBJECTS = {"yo", "vos", "él", "ella", "usted", "nosotros", "nosotras", "ustedes", "ellos", "ellas"}
LEVELS = ["a1", "a2", "b1", "b2"]
_CACHE = {"sig": None, "data": {}}


def _engine():
    from .api_learn import services
    return services()["engine"]


def _tidy(text):
    text = re.sub(r"\s+", " ", text).strip()
    text = re.sub(r"\s+([.,!?])", r"\1", text)
    text = re.sub(r"([¿¡])\s+", r"\1", text)
    m = re.match(r"^([¿¡]?)(.)(.*)$", text, re.S)
    if m:
        text = m.group(1) + m.group(2).upper() + m.group(3)
    return text


def _fill(pattern, values):
    out = pattern
    for k, v in values.items():
        out = out.replace("{" + k + "}", v)
    return _tidy(out)


def expand(tpl, engine=None):
    """All sentences of one template (deterministic, capped)."""
    if tpl.get("sentences"):
        out = []
        for i, s in enumerate(tpl["sentences"]):
            out.append({"es": s["es"], "en": s["en"], "verb": s.get("verb"), "blank": s.get("blank"),
                        "accept": list(s.get("accept", [])), "n": i})
        return out
    engine = engine or _engine()
    tense = tpl.get("tense", "pres")
    times = tpl.get("time") or [{"es": "", "en": ""}]
    combos = []
    for subj in tpl.get("subj", []):
        for verb in tpl.get("verbs", []):
            for obj in verb.get("with") or [{"es": "", "en": ""}]:
                for time in (obj.get("time") or verb.get("time") or times):
                    combos.append((subj, verb, obj, time))
    seed = int(hashlib.sha1(tpl["id"].encode("utf-8")).hexdigest()[:8], 16)
    rnd = random.Random(seed)
    rnd.shuffle(combos)
    out = []
    for n, (subj, verb, obj, time) in enumerate(combos[:int(tpl.get("cap", 40))]):
        person = subj.get("p", "el")
        t = verb.get("tense", tense)
        form = engine.form(verb["inf"], t, person)
        en_base = obj.get("en_verb") or verb["en"]          # tener hambre = "be" hungry
        en_v = verb.get("en_forms", {}).get(person) or explain.en_verb(en_base, t, person)
        gender = subj.get("g", "m")
        plural = person in ("nos", "uds", "ellos")
        adj = obj.get("adj")
        obj_es = obj.get("es", "")
        if adj:
            obj_es = adj["f" if gender == "f" else "m"] + ("s" if plural else "")
        # "drop": the natural sentence leaves the pronoun out (voy a…, ¿venís?); with it is accepted too
        dropped = bool(subj.get("drop"))
        vals_es = {"subj": "" if dropped else subj["es"], "verb": form, "obj": obj_es, "time": time["es"]}
        vals_en = {"subj": subj["en"], "subj_obj": subj.get("en_obj", subj["en"]), "verb": en_v,
                   "obj": obj.get("en", ""), "time": time["en"]}
        es = _fill(tpl["es"], vals_es)
        accept = []
        if dropped:
            accept.append(_fill(tpl["es"], dict(vals_es, subj=subj["es"])))
        elif subj["es"].lower() in PRONOUN_SUBJECTS:
            accept.append(_fill(tpl["es"], dict(vals_es, subj="")))
        if time["es"] and tpl["es"].strip().startswith("{time}"):
            moved = tpl["es"].replace("{time}", "", 1).rstrip(". ") + " {time}."
            accept.append(_fill(moved, vals_es))
            if dropped:
                accept.append(_fill(moved, dict(vals_es, subj=subj["es"])))
            elif subj["es"].lower() in PRONOUN_SUBJECTS:
                accept.append(_fill(moved, dict(vals_es, subj="")))
        if adj and subj["es"].lower() in ("yo", "vos", "nosotros", "ustedes"):
            other = adj["m" if gender == "f" else "f"] + ("s" if plural else "")
            accept += [a.replace(obj_es, other) for a in [es] + list(accept)]
        out.append({"es": es, "en": _fill(tpl["en"], vals_en), "accept": accept, "n": n,
                    "verb": {"inf": verb["inf"], "tense": t, "person": person}, "blank": form})
    return out


def expand_all(content):
    sig = id(content.templates), len(content.templates)
    if _CACHE["sig"] != sig:
        data = {}
        engine = None
        try:
            engine = _engine()
        except Exception:
            from .conjugator import Engine
            engine = Engine(content.verbs, content.irregular)
        for tid, tpl in content.templates.items():
            try:
                data[tid] = expand(tpl, engine)
            except Exception as e:                      # reported by the validator
                data[tid] = []
                content.errors.append("template %s: %r" % (tid, e))
        _CACHE.update(sig=sig, data=data)
    return _CACHE["data"]


def make_exercise(tpl, sent, mode):
    base = {"id": "tpl:%s:%d:%s" % (tpl["id"], sent["n"], mode), "key": "tpl:" + tpl["id"],
            "topic": tpl.get("topic") or "sentences", "level": tpl.get("level"), "generated": True,
            "why": tpl.get("why", ""), "extra": tpl.get("extra"), "say": sent["es"]}
    if mode == "fill" and sent.get("blank") and sent["blank"].lower() in sent["es"].lower():
        i = sent["es"].lower().index(sent["blank"].lower())
        blanked = sent["es"][:i] + "___" + sent["es"][i + len(sent["blank"]):]
        inf = (sent.get("verb") or {}).get("inf")
        return dict(base, type="fill", prompt="Fill in the blank%s." % (" with the verb “%s”" % inf if inf else ""),
                    es=blanked, en=sent["en"], answer=sent["blank"].lower(), verb=sent.get("verb"))
    if mode == "order":
        return dict(base, type="order", prompt="Put the words in order.", en=sent["en"], answer=sent["es"],
                    verb=sent.get("verb"))
    if mode == "dictation":
        return dict(base, type="listen_type", prompt="Listen and type what you hear.", es=sent["es"],
                    en=sent["en"], answer=sent["es"])
    return dict(base, type="en2es", prompt="Say it in Argentine Spanish.", en=sent["en"], answer=sent["es"],
                accept=sent.get("accept", []), verb=sent.get("verb"))


def exercise_for(content, key, mode=None):
    tpl = content.templates.get(key.split(":", 1)[1])
    if not tpl:
        return None
    sents = expand_all(content).get(tpl["id"]) or []
    if not sents:
        return None
    sent = random.choice(sents)
    mode = mode or random.choice(["en2es", "en2es", "fill", "order", "dictation"])
    if mode == "dictation":
        from .api import A
        if not A().ref(sent["es"]):
            mode = "en2es"
    return make_exercise(tpl, sent, mode)


def pick(content, progress, n, level):
    if n <= 0 or not content.templates:
        return []
    cards = progress.data["srs"]
    pool, weights = [], []
    for tid, tpl in content.templates.items():
        if LEVELS.index(tpl.get("level") or "a1") > LEVELS.index(level or "a1"):
            continue
        card = cards.get("tpl:" + tid)
        weak = srs.weakness(card) if card else 0.5
        due = 1.6 if (card and srs.is_due(card)) else 1.0
        pool.append(tid)
        weights.append((0.35 + 1.65 * weak) * due)
    out, used = [], set()
    tries = 0
    while pool and len(out) < n and tries < n * 6:
        tries += 1
        tid = random.choices(pool, weights=weights, k=1)[0]
        ex = exercise_for(content, "tpl:" + tid)
        if ex and ex["say"] not in used:
            used.add(ex["say"])
            out.append(ex)
    return out
