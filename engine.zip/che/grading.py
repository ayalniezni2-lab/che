"""Grading: keyboard-friendly comparison, accent notes, multiple-choice routing, typo tolerance.

Rules (from the brief):
 1. Never lose points for missing accents, ñ, ¿ or ¡  -> both sides are normalized first.
 2. Always show the correct written form; if marks were left out, add a NEUTRAL note.
 3. When an accent/ñ changes the meaning, the exercise becomes multiple choice (never typed).
 4. Typo tolerance only for vocabulary words of 7+ letters, never for verb forms/endings.
"""
import hashlib
import random
import re

from .spanish import normalize, fold, tokens, has_special
from .conjugator import PERSONS, SIMPLE, IMP_PERSONS

TYPED_TYPES = ("type", "fill", "conj", "en2es", "es2en", "listen_type", "order")
CHOICE_TYPES = ("mc", "listen_mc", "dialogue_q")
ARTICLES = ("el", "la", "los", "las", "un", "una", "unos", "unas")

# Spanish usually leaves the subject out, but saying it is never a mistake ("yo voy a pensar", "él entra").
# normalized pronoun -> the table person it goes with
SUBJECTS = {"yo": "yo", "vos": "vos", "el": "el", "ella": "el", "usted": "el", "nosotros": "nos",
            "nosotras": "nos", "ustedes": "uds", "ellos": "ellos", "ellas": "ellos"}
CLITICS = {"no", "me", "te", "se", "lo", "la", "le", "nos", "los", "las", "les"}
PRONOUN_TYPES = ("type", "fill", "conj", "en2es")


def _loose(text):
    """lowercase, no punctuation, single spaces — but accents and ñ KEPT."""
    text = (text or "").lower().replace("’", "'")
    text = re.sub(r"[¿?¡!.,;:\"“”«»()\[\]…—–\-']+", " ", text)
    return re.sub(r"\s+", " ", text).strip()


def edit_distance(a, b):
    """Damerau-Levenshtein (adjacent swaps count as one)."""
    if a == b:
        return 0
    la, lb = len(a), len(b)
    if abs(la - lb) > 2:
        return 3
    d = [[0] * (lb + 1) for _ in range(la + 1)]
    for i in range(la + 1):
        d[i][0] = i
    for j in range(lb + 1):
        d[0][j] = j
    for i in range(1, la + 1):
        for j in range(1, lb + 1):
            cost = 0 if a[i - 1] == b[j - 1] else 1
            d[i][j] = min(d[i - 1][j] + 1, d[i][j - 1] + 1, d[i - 1][j - 1] + cost)
            if i > 1 and j > 1 and a[i - 1] == b[j - 2] and a[i - 2] == b[j - 1]:
                d[i][j] = min(d[i][j], d[i - 2][j - 2] + 1)
    return d[la][lb]


def only_ending_differs(a, b):
    """cansado/cansada, rojo/rojos, el/la … -> gender / number difference, not a typo."""
    ends = ("o", "a", "os", "as", "e", "es", "")
    for ea in ends:
        for eb in ends:
            if ea != eb and a.endswith(ea) and b.endswith(eb):
                if a[:len(a) - len(ea)] == b[:len(b) - len(eb)] and len(a) - len(ea) >= 2:
                    return True
    return False


class Grader:
    def __init__(self, content, engine):
        self.c = content
        self.e = engine
        self.pair_index = {}       # folded word -> [pair entries]
        for p in (content.meta.get("accent_pairs") or {}).get("pairs", []):
            self.pair_index.setdefault(fold(p["a"]), []).append(p)
        self._known = None
        self._form_index = None

    # ------------------------------------------------------------------ indexes
    @property
    def form_index(self):
        """folded verb form -> [(inf, tense, person)] over the whole verb database."""
        if self._form_index is None:
            idx = {}
            for inf in self.c.verbs:
                try:
                    for form, tense, person in self.e.all_forms(inf):
                        idx.setdefault(fold(form), []).append((inf, tense, person))
                except Exception:
                    continue
            self._form_index = idx
        return self._form_index

    @property
    def known_words(self):
        if self._known is None:
            known = set(self.form_index)
            for it in self.c.vocab.values():
                for tok in tokens(it.get("es", "")):
                    known.add(fold(tok))
            self._known = known
        return self._known

    def is_verb_form(self, word):
        return fold(word) in self.form_index

    # ------------------------------------------------------------------ multiple-choice routing
    def confusables(self, ex):
        """Written forms that a keyboard without accents cannot tell apart from the answer."""
        if ex.get("type") not in ("type", "fill", "conj", "en2es"):
            return []
        ans = (ex.get("answer") or "").strip().lower()
        toks = tokens(ans)
        if not toks:
            return []
        out = []
        article = ""
        if len(toks) == 2 and toks[0] in ARTICLES:          # el año -> año (the article is optional)
            article, toks = toks[0] + " ", toks[1:]
        if len(toks) == 1 and not ex.get("verb"):        # verb drills: only same-verb look-alikes matter
            for p in self.pair_index.get(fold(toks[0]), []):
                for w in (p["a"], p["b"]):
                    if w != toks[0] and article + w not in out:
                        out.append(article + w)
        verb = ex.get("verb")
        if verb and verb.get("inf") and has_special(ans):
            # habló needs a choice (typing "hablo" would be another word).  The plain member of such a
            # pair (hablo, habla, hable) can simply be typed: there is no accent to leave out.
            for form in self.lookalikes(verb["inf"], ans):
                if form not in out:
                    out.append(form)
        return out

    def lookalikes(self, inf, form):
        """Other forms of the same verb that differ from `form` only by an accent mark."""
        try:
            forms = self.e.all_forms(inf)
        except Exception:
            return []
        out = []
        for f, _, _ in forms:
            if f != form and fold(f) == fold(form) and f not in out:
                out.append(f)
        return out

    def present(self, ex):
        """Return the exercise as it should be shown.  Typed -> multiple choice when needed."""
        conf = self.confusables(ex)
        if not conf:
            return ex
        shown = dict(ex)
        options = [ex["answer"].strip().lower()] + conf
        verb = ex.get("verb")
        pool = [o for o in ex.get("options", []) if o not in options]
        if verb:
            try:
                t = self.e.conjugate(verb["inf"])
                tense = verb.get("tense")
                if tense in t and isinstance(t[tense], dict):
                    pool += [f for f in t[tense].values() if f not in options and f not in pool]
                pool += [f for f in t["pres"].values() if f not in options and f not in pool]
            except Exception:
                pass
        rnd = random.Random(int(hashlib.sha1((ex.get("id") or ex["answer"]).encode("utf-8")).hexdigest()[:8], 16))
        rnd.shuffle(pool)
        options += pool[:max(0, 4 - len(options))]
        rnd.shuffle(options)
        shown["original_type"] = ex.get("type")
        shown["type"] = "mc"
        shown["options"] = options
        shown["routed"] = True
        shown["route_note"] = ("On a keyboard without accents these would look the same, "
                               "so this one is a choice.")
        return shown

    # ------------------------------------------------------------------ grading
    def accepted(self, ex):
        out = [ex.get("answer", "")]
        out += list(ex.get("accept", []))
        if ex.get("article_optional"):
            for a in list(out):
                parts = a.split(" ", 1)
                if len(parts) == 2 and parts[0].lower() in ARTICLES:
                    out.append(parts[1])
        return [a for a in out if a]

    def _voseo_variant(self, ex):
        """'no hagás / que vos tengás' — also heard; accepted with a note."""
        verb = ex.get("verb") or {}
        if verb.get("person") != "vos" or verb.get("tense") not in ("subj", "impneg"):
            return None
        try:
            nos = self.e.form(verb["inf"], "subj", "nos")
        except Exception:
            return None
        head, _, last = nos.rpartition(" ")
        if last.endswith("emos"):
            v = last[:-4] + "és"
        elif last.endswith("amos"):
            v = last[:-4] + "ás"
        else:
            return None
        pron = "te " if head.endswith("nos") or head == "nos" else ""
        v = pron + v
        return ("no " + v) if verb["tense"] == "impneg" else v

    def grade(self, ex, answer):
        """-> dict(verdict, correct, expected, typed, accent_note, notes, matched)"""
        typed = (answer or "").strip()
        accepted = self.accepted(ex)
        expected = accepted[0] if accepted else ""
        res = {"verdict": "wrong", "correct": False, "expected": expected, "typed": typed,
               "accent_note": None, "notes": [], "matched": None}
        etype = ex.get("type")

        if etype in CHOICE_TYPES or ex.get("options") and etype == "mc":
            ok = _loose(typed) == _loose(expected) and typed != ""
            res.update(verdict="correct" if ok else "wrong", correct=ok, matched=expected if ok else None)
            return res

        nt = normalize(typed)
        if not nt:
            return res
        verb = ex.get("verb") or {}
        if verb.get("inf") and has_special(typed):
            # An accent that was TYPED counts: "habló" is not "hablo".  (Leaving accents out never hurts.)
            mine = _loose(typed)
            if mine != _loose(expected) and mine in self.lookalikes(verb["inf"], expected.strip().lower()):
                res["wrong_accent"] = True
                return res
        for a in accepted:
            if normalize(a) == nt:
                res.update(verdict="correct", correct=True, matched=a)
                shown = a if a != expected and ex.get("show_matched", True) else expected
                res["expected"] = shown
                if has_special(shown) and _loose(typed) != _loose(shown):
                    kind = "an accent" if re.search(r"[áéíóúü]", shown.lower()) else "ñ"
                    if "ñ" in shown.lower() and re.search(r"[áéíóú]", shown.lower()):
                        kind = "accent marks and ñ"
                    if not re.search(r"[áéíóúüñ]", shown.lower()):
                        kind = "¿ ¡"
                    res["accent_note"] = "Written with %s: %s" % (kind, shown)
                return res

        variant = self._voseo_variant(ex)
        if variant and normalize(variant) == nt:
            res.update(verdict="correct", correct=True, matched=expected)
            res["notes"].append("You will also hear **%s** in Buenos Aires. The form we practise "
                                "(and the one you will see written) is **%s**." % (variant, expected))
            return res

        # "hablastes / tuvistes": heard in relaxed speech but non-standard — anywhere in the answer
        mine = nt.split(" ")
        for a in accepted:
            theirs = normalize(a).split(" ")
            if len(theirs) != len(mine):
                continue
            diff = [(x, y) for x, y in zip(theirs, mine) if x != y]
            if len(diff) == 1 and diff[0][0].endswith("ste") and diff[0][1] == diff[0][0] + "s":
                word = next((t for t in tokens(a) if normalize(t) == diff[0][0]), diff[0][0])
                res.update(verdict="almost", correct=True, matched=a, expected=a)
                res["notes"].append("People do say **%ss** in relaxed speech, but it is considered "
                                    "non-standard. The form to learn is **%s**." % (word, word))
                return res

        pron = self._subject_pronoun(ex, nt, accepted)
        if pron:
            match, note = pron
            res.update(verdict="correct", correct=True, matched=match, expected=match)
            if note:
                res["notes"].append(note)
            return res

        typo = self._typo(ex, typed, accepted)
        if typo:
            res.update(verdict="almost", correct=True, matched=typo, expected=typo)
            res["notes"].append("Almost — check the spelling: **%s**." % typo)
            return res
        if len(accepted) > 1 and etype not in CHOICE_TYPES:
            # compare with the correct answer that is closest to what was typed (a variant without "que", etc.)
            mine = nt.split(" ")

            def dist(a):
                import difflib
                return 1 - difflib.SequenceMatcher(a=normalize(a).split(" "), b=mine).ratio()
            res["expected"] = min(accepted, key=dist)
        return res

    def _persons_in(self, words):
        """Table persons of the first verb form in a list of normalized words (skipping no / me / te…)."""
        i = 0
        while i < len(words) and words[i] in CLITICS:
            i += 1
        for n in (4, 3, 2, 1):
            key = " ".join(words[i:i + n])
            if n <= len(words) - i and key in self.form_index:
                return {p for _, _, p in self.form_index[key] if p}
        return set()

    def _subject_fits(self, pron, ex, rest):
        """Is this subject pronoun right for the answer (person) and for the English (he / she / you / they)?"""
        verb = ex.get("verb") or {}
        persons = {verb["person"]} if verb.get("person") else self._persons_in(rest)
        person = SUBJECTS[pron]
        if person not in persons:
            return False
        en = " %s " % re.sub(r"[^a-z' ]+", " ", (ex.get("en") or ex.get("prompt") or "").lower())
        if not en.strip():
            return True
        said = lambda *ws: any(" %s " % w in en for w in ws)
        if pron == "el":
            return said("he", "he's", "it") or not said("she", "she's", "you", "you're")
        if pron == "ella":
            return said("she", "she's", "it") or not said("he", "he's", "you", "you're")
        if pron == "usted":
            return said("you", "you're", "your") and not said("he", "she")
        if pron == "ustedes":
            return said("you", "you're", "your") or person not in persons
        if pron in ("ellos", "ellas"):
            return said("they", "they're", "them") or not said("you", "you're")
        return True

    def _subject_pronoun(self, ex, nt, accepted):
        """Accept an added subject pronoun (yo voy…) or a left-out one (voy… for yo voy…). -> (answer, note)"""
        if ex.get("type") not in PRONOUN_TYPES or ex.get("pronoun_strict"):
            return None
        mine = nt.split(" ")
        if ex.get("type") == "fill":
            before = normalize((ex.get("es") or "").split("___")[0]).split(" ")
            if before and before[-1] in SUBJECTS:
                return None                   # the sentence already has its subject right before the gap
        for a in accepted:
            theirs = normalize(a).split(" ")
            # added: "yo voy a pensar" for "voy a pensar"
            if len(mine) >= 2 and mine[0] in SUBJECTS and theirs == mine[1:] and theirs[0] not in SUBJECTS:
                if self._subject_fits(mine[0], ex, theirs):
                    word = {"el": "él"}.get(mine[0], mine[0])
                    return a, ("Correct. You can also leave out **%s**: the verb ending already says who." % word)
            # left out: "voy a pensar" for "yo voy a pensar"
            if len(theirs) >= 2 and theirs[0] in SUBJECTS and mine == theirs[1:] and ex.get("type") != "fill":
                return a, None
        return None

    def _typo(self, ex, typed, accepted):
        """One typo allowed in a 7+ letter VOCABULARY word.  Never in a verb form."""
        if ex.get("verb") or ex.get("type") == "conj" or ex.get("no_typo"):
            return None
        tt = normalize(typed).split(" ")
        for a in accepted:
            at = normalize(a).split(" ")
            if len(at) != len(tt):
                continue
            diffs = [(x, y) for x, y in zip(at, tt) if x != y]
            if len(diffs) != 1:
                continue
            want, got = diffs[0]
            if len(want) < 7 or edit_distance(want, got) != 1:
                continue
            if self.is_verb_form(want) and not ex.get("vocab"):
                continue                      # a verb form inside a sentence: endings must be exact
            is_verb = self.is_verb_form(want) or re.search(r"(ar|er|ir|ír)(se)?$", want)
            if is_verb:
                same = 0
                while same < min(len(want), len(got)) and want[same] == got[same]:
                    same += 1
                if same >= len(want) - 3:
                    continue                  # the slip is in the verb ending: never tolerated
            if only_ending_differs(want, got):
                continue                      # gender / number is grammar, not a typo
            if got in self.known_words:
                continue                      # a real (different) word, not a slip of the finger
            return a
        return None
