"""Word chapters: the word lists (content/vocab/*.json) cut into short chapters of new words.

Most words in the app are in no lesson: they used to arrive only as "a few new words a day" in Today. Now they come
as chapters of their own, on the path:
  * a word chapter = 10 places of one word list, in file order (CHUNK).  Ids are stable — w-<file>-<n> — because
    the chunks are cut by POSITION in the file, retired words included (retiring a word never shifts a chunk).
    Retired, vulgar and slang words are left out of the chapter itself (slang stays in the background).
  * after every WORDS_EVERY lesson / reading chapters finished, the path's next chapter is a word chapter
    (course.next_chapter) — never in the middle of a lesson that was started.
  * which words: the stage says which levels ("words": ["a1", "a2"] in course.json), taken in turn; chapters whose
    words the learner has (nearly) all met already are passed over.
  * done = 70% on its questions, or "I know these" (6 questions, 80%), like any chapter.  Progress lives in
    progress["units"][<id>], like lessons and readings.
"""
import random
from datetime import datetime

from .api import route, ApiError, C, P

CHUNK = 10
WORDS_EVERY = 2                 # one word chapter after every 2 lessons / readings
MIN_WORDS = 4                   # a chunk with fewer usable words is not a chapter
SKIP_TOPICS = {"lunfardo", "slang", "vulgar", "whatsapp", "sport"}
PASS = 0.7
KNOWN = 0.8                     # 80% of a chapter's words already met: it is passed over
LEVELS = ["a1", "a2", "b1", "b2"]
TITLES = {
    "abstract": "Ideas and opinions", "adjectives": "Describing words", "adverbs": "How, when and where",
    "airport": "At the airport", "banking": "The bank and paying", "body-clothes": "Body and clothes",
    "car": "The car", "city": "Around the city", "colors-weather": "Colours and weather",
    "complaints": "Complaints", "connectors": "Linking your sentences", "dates": "Dates",
    "delivery": "Deliveries and online shopping", "describing": "Describing things", "eating-out": "Eating out",
    "economy-politics": "Money, the economy and politics", "essentials": "The essentials", "feelings": "Feelings",
    "fillers": "Sounding natural", "food": "Food", "formal": "Formal Spanish", "going-out": "Going out",
    "greetings": "Hello and goodbye", "hair-pets": "Hairdresser and pets", "health": "Health", "home": "Home",
    "idioms": "Sayings", "job": "Jobs", "kitchen": "In the kitchen", "leisure": "Free time",
    "looks": "How people look", "market": "At the market", "media": "News and media", "money": "Money",
    "nature": "Nature", "numbers": "Numbers", "people": "People", "phone": "On the phone",
    "phrases": "Useful phrases", "plans": "Plans", "police": "Police and emergencies",
    "relationships": "Relationships", "repairs": "Repairs", "shopping": "Shopping and clothes", "study": "Studying",
    "tech": "Phones and computers", "time": "Time", "time-expressions": "When things happen",
    "tramites": "Renting and paperwork", "travel": "Travel", "work": "Work",
}

_CACHE = {"sig": None}


def _usable(it):
    return it is not None and it.get("reg") not in ("vulgar", "slang")


# ------------------------------------------------------------------ the chapters (cached per content load)
def tracks(c=None):
    """{level: [chapter, …]} in learning order: within a level, the first chunk of every list (most frequent lists
    first), then the second chunk of every list, and so on — so topics take turns."""
    c = c or C()
    if _CACHE["sig"] is c._sig and _CACHE.get("content") is c:
        return _CACHE["value"]
    by_level = {lv: [] for lv in LEVELS}
    for n, deck in enumerate(c.vocab_decks):
        if deck["topic"] in SKIP_TOPICS or deck["reg"] in ("vulgar", "slang") or deck["level"] not in by_level:
            continue
        chunks = []
        for k in range(0, len(deck["ids"]), CHUNK):
            ids = [i for i in deck["ids"][k:k + CHUNK] if _usable(c.vocab.get(i))]
            if len(ids) >= MIN_WORDS:
                chunks.append((k // CHUNK + 1, ids))
        if chunks:
            rank = deck["rank_base"] if deck["rank_base"] is not None else 10000 + n
            by_level[deck["level"]].append((rank, deck, chunks))
    out, index = {}, {}
    for lv, decks in by_level.items():
        decks.sort(key=lambda x: x[0])
        lst = []
        for turn in range(max([len(ch) for _, _, ch in decks] or [0])):
            for _, deck, chunks in decks:
                if turn >= len(chunks):
                    continue
                k, ids = chunks[turn]
                name = TITLES.get(deck["topic"], (deck["topic"] or "words").replace("-", " ").capitalize())
                many = len(chunks) > 1
                ch = {"id": "w-%s-%d" % (deck["id"], k), "type": "words", "kind": "words",
                      "title": "New words: %s%s" % (name, " (%d)" % k if many else ""),
                      "goal": "%d words and phrases about %s, each with an example sentence." % (len(ids), name.lower()),
                      "level": lv, "topic": deck["topic"], "ids": ids, "pos": len(lst), "stage": "words"}
                lst.append(ch)
                index[ch["id"]] = ch
        out[lv] = lst
    value = {"tracks": out, "index": index}
    _CACHE.update(sig=c._sig, content=c, value=value)
    return value


def get(cid, c=None):
    return tracks(c)["index"].get(cid)


def is_done(p, cid):
    s = p["units"].get(cid) or {}
    return bool(s.get("completed") or s.get("skipped"))


def _met(p):
    return {k.split(":")[1] for k in p["srs"] if k.startswith("vocab:")}


def known_share(p, ch, met=None):
    met = _met(p) if met is None else met
    return sum(1 for i in ch["ids"] if i in met) / float(len(ch["ids"]) or 1)


# ------------------------------------------------------------------ where the learner is
def words_due(p, c=None):
    """True when WORDS_EVERY lessons / readings were finished since the last word chapter."""
    from . import course
    index = course.course(c)["index"]
    last = max([(s.get("completed") or s.get("skipped") or "") for cid, s in p["units"].items()
                if cid.startswith("w-")] or [""])
    n = sum(1 for cid, s in p["units"].items()
            if cid in index and index[cid][1]["type"] in ("unit", "reading") and (s.get("completed") or "") > last)
    return n >= WORDS_EVERY


def stage_levels(p, c=None):
    from . import course
    cs = course.course(c)
    cur, _ = course.state(p, c)
    st = cs["stages"][cur]
    return st.get("words") or ["a1"]


def next_words(p, c=None):
    """The next word chapter: the stage's levels in turn; lists already (nearly) known are passed over."""
    t = tracks(c)["tracks"]
    levels = stage_levels(p, c)
    done = sum(1 for cid in p["units"] if cid.startswith("w-") and is_done(p, cid))
    turn = levels[done % len(levels):] + levels[:done % len(levels)]
    top = max(LEVELS.index(lv) for lv in levels)
    rest = [lv for lv in LEVELS if lv not in levels]
    rest.sort(key=lambda lv: (LEVELS.index(lv) > top, abs(LEVELS.index(lv) - top)))    # lower levels before higher
    met = _met(p)
    for lv in turn + rest:
        for ch in t.get(lv, []):
            if not is_done(p, ch["id"]) and known_share(p, ch, met) < KNOWN:
                return ch
    return None


def summary(p, c=None):
    t = tracks(c)["tracks"]
    all_ch = [ch for lv in LEVELS for ch in t.get(lv, [])]
    nxt = next_words(p, c)
    return {"done": sum(1 for ch in all_ch if is_done(p, ch["id"])), "count": len(all_ch),
            "next": out(nxt, p) if nxt else None, "due": words_due(p, c)}


def out(ch, p):
    s = p["units"].get(ch["id"]) or {}
    return {"id": ch["id"], "type": "words", "kind": "words", "kind_label": "New words", "title": ch["title"],
            "goal": ch["goal"], "level": ch["level"], "stage": ch["stage"], "pos": ch["pos"] + 1,
            "completed": bool(s.get("completed")), "skipped": bool(s.get("skipped")),
            "started": bool(s.get("started")), "best": s.get("best")}


# ------------------------------------------------------------------ the chapter's questions
def questions(ch):
    """Recognise first, then hear, then produce: the meaning of 6 (choice), 2 heard, all 10 typed in Spanish,
    2 example sentences typed as heard."""
    from . import drills
    items = [C().vocab[i] for i in ch["ids"] if i in C().vocab]
    rnd = random.Random()
    order = items[:]
    rnd.shuffle(order)
    first = [drills.make_vocab(it, "es2en") for it in order[:6]]
    hear = [drills.make_vocab(it, "listen") for it in order[6:] if not it.get("no_audio")][:2]
    typed = [drills.make_vocab(it, "en2es") for it in items]
    rnd.shuffle(typed)
    said = [drills.make_vocab(it, "dictation") for it in order if it.get("ex") and not it.get("no_audio")][:2]
    return first + hear + typed + said


# ------------------------------------------------------------------ routes
@route("GET", "wordch")
def list_chapters(query, body):
    p = P().data
    t = tracks()["tracks"]
    met = _met(p)
    levels = []
    for lv in LEVELS:
        chs = t.get(lv, [])
        if chs:
            levels.append({"level": lv, "chapters": [dict(out(ch, p), known=round(100 * known_share(p, ch, met)))
                                                     for ch in chs]})
    return {"levels": levels, "summary": summary(p)}


@route("GET", "wordch/*")
def get_chapter(query, body, cid):
    from .api_learn import serve_vocab, serve_exercise
    ch = get(cid)
    if not ch:
        raise ApiError("No such word chapter: %s" % cid, 404)
    p = P()
    st = p.data["units"].setdefault(cid, {})
    if not st.get("started"):
        with p.lock:
            st["started"] = datetime.now().isoformat(timespec="seconds")
            p.save()
    met = _met(p.data)
    words = [dict(serve_vocab(C().vocab[i]), met=i in met) for i in ch["ids"] if i in C().vocab]
    return dict(out(ch, p.data), words=words, exercises=[serve_exercise(x) for x in questions(ch)],
                status=st, pass_pct=round(100 * PASS))


@route("GET", "wordch/check/*")
def check(query, body, cid):
    """'I know these': 6 words typed in Spanish, graded without saving; 80% ticks the chapter off."""
    from . import drills
    from .api_learn import serve_exercise
    ch = get(cid)
    if not ch:
        raise ApiError("No such word chapter: %s" % cid, 404)
    items = [C().vocab[i] for i in ch["ids"] if i in C().vocab]
    random.shuffle(items)
    return {"items": [serve_exercise(drills.make_vocab(it, "en2es")) for it in items[:6]], "pass": 80}


@route("POST", "wordch/done")
def done(query, body):
    cid = body.get("id")
    if not get(cid):
        raise ApiError("No such word chapter: %s" % cid, 404)
    total = int(body.get("total") or 0)
    score = (int(body.get("right") or 0) / total) if total else 1.0
    p = P()
    with p.lock:
        from . import course
        course.ensure_saved(p.data)
        st = p.data["units"].setdefault(cid, {})
        now = datetime.now().isoformat(timespec="seconds")
        st.setdefault("started", now)
        st["attempts"] = st.get("attempts", 0) + 1
        st["best"] = max(st.get("best") or 0, round(score, 3))
        if score >= PASS:
            st["completed"] = st.get("completed") or now
        p.log_session()
        p.save()
    from . import course
    return {"passed": score >= PASS, "next": course.chapter_out(course.next_chapter(p.data), p.data)}
