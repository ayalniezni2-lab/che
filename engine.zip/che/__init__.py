"""Che! - a local app for learning Argentine (Rioplatense) Spanish."""
__version__ = "1.0"
