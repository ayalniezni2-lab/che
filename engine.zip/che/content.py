"""Content loading.  Everything under content/ is plain JSON.

Refill packs (content/packs/pack-*.json) are discovered automatically: a pack may contain
any of the sections  units / vocab / dialogues / culture / templates / verbs  and is merged
into the same indexes as the base content.  No code changes are ever needed for new packs.
"""
import glob
import json
import os
import threading

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CONTENT_DIR = os.path.join(ROOT, "content")

LEVEL_ORDER = ["a1", "a2", "b1", "b2"]
REGISTERS = ["neutral", "informal", "slang", "vulgar"]
EXERCISE_TYPES = ["mc", "type", "fill", "conj", "en2es", "es2en", "match", "order",
                  "listen_mc", "listen_type", "dialogue_q"]


def read_json(path, default=None):
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except FileNotFoundError:
        return default


def _files(*parts):
    return sorted(glob.glob(os.path.join(CONTENT_DIR, *parts), recursive=True))


class Content:
    def __init__(self):
        self.lock = threading.RLock()
        self.errors = []          # load problems (shown by the validator)
        self._sig = None
        self.load()

    # ------------------------------------------------------------------ loading
    def signature(self):
        sig = []
        for p in _files("**", "*.json"):
            try:
                sig.append((p, os.path.getmtime(p)))
            except OSError:
                pass
        return tuple(sig)

    def reload_if_changed(self):
        sig = self.signature()
        if sig != self._sig:
            self.load()
            return True
        return False

    def load(self):
        with self.lock:
            self.errors = []
            self.meta = {}
            for p in _files("meta", "*.json"):
                name = os.path.splitext(os.path.basename(p))[0]
                try:
                    self.meta[name] = read_json(p)
                except ValueError as e:
                    self.errors.append("%s: invalid JSON (%s)" % (p, e))
            self.levels = self.meta.get("levels") or [
                {"id": "a1", "name": "Survival", "cefr": "A1"},
                {"id": "a2", "name": "Everyday", "cefr": "A2"},
                {"id": "b1", "name": "Conversational", "cefr": "B1"},
                {"id": "b2", "name": "Fluent-ish", "cefr": "B2"},
            ]
            self.verbs = {}        # inf -> verb entry
            self.vocab = {}        # id -> item (defaults applied)
            self.units = {}        # id -> unit
            self.dialogues = {}    # id -> dialogue / reading
            self.culture = {}      # id -> note
            self.templates = {}    # id -> template
            self.sources = {}      # item id -> file it came from (for `fix:`)
            self.retired = {}      # id -> file: units / dialogues kept on disk but switched off ("retired": true)

            self._load_verbs()
            for p in _files("vocab", "*.json"):
                self._add_vocab_file(self._safe(p), p)
            for p in _files("units", "**", "*.json"):
                self._add_unit(self._safe(p), p)
            for p in _files("dialogues", "*.json"):
                self._add_many(self._safe(p), p, self.dialogues, "dialogue")
            for p in _files("culture", "*.json"):
                self._add_many(self._safe(p), p, self.culture, "culture note")
            for p in _files("templates", "*.json"):
                self._add_many(self._safe(p), p, self.templates, "template")
            for p in _files("packs", "pack-*.json"):
                self._add_pack(self._safe(p), p)

            # templates may name a shared slot list ("subj": "everyone") from meta/template_sets.json
            sets = self.meta.get("template_sets") or {}
            for tpl in self.templates.values():
                for key in ("subj", "time"):
                    if isinstance(tpl.get(key), str):
                        if tpl[key] in sets:
                            tpl[key] = sets[tpl[key]]
                        else:
                            self.errors.append("template %s: unknown %s set %r" % (tpl.get("id"), key, tpl[key]))
                            tpl[key] = []

            self.unit_order = sorted(
                self.units.values(),
                key=lambda u: (LEVEL_ORDER.index(u.get("level", "a1"))
                               if u.get("level") in LEVEL_ORDER else 9,
                               u.get("order", 999), u["id"]))
            self.exercises = {}    # exercise id -> (exercise, unit id / dialogue id)
            for u in self.units.values():
                for ex in u.get("exercises", []):
                    self._index_exercise(ex, u["id"], u)
            for d in self.dialogues.values():
                for ex in d.get("questions", []):
                    ex.setdefault("type", "dialogue_q")
                    ex.setdefault("dialogue", d["id"])
                    self._index_exercise(ex, d["id"], d)
            self._sig = self.signature()

    def _safe(self, path):
        try:
            return read_json(path)
        except ValueError as e:
            self.errors.append("%s: invalid JSON (%s)" % (os.path.relpath(path, ROOT), e))
            return None

    def _load_verbs(self):
        # verbs-a1.json, verbs-a2.json … : most-used first; rank = position overall
        for p in _files("verbs", "verbs*.json"):
            data = self._safe(p) or {}
            src = os.path.relpath(p, ROOT).replace("\\", "/")
            for v in data.get("verbs", []):
                v = dict(v)
                v.setdefault("level", data.get("level"))
                self._add_verb(v, src)
        self.irregular = self._safe(os.path.join(CONTENT_DIR, "verbs", "irregular.json")) or {}

    def _add_verb(self, v, src):
        inf = v.get("inf")
        if not inf:
            self.errors.append("%s: verb without 'inf'" % src)
            return
        if inf in self.verbs:
            self.errors.append("%s: duplicate verb %s" % (src, inf))
            return
        v.setdefault("rank", len(self.verbs) + 1)
        v.setdefault("reg", "neutral")
        self.verbs[inf] = v
        self.sources["verb:" + inf] = src

    def _add_vocab_file(self, data, path):
        if not data:
            return
        src = os.path.relpath(path, ROOT).replace("\\", "/")
        defaults = {"topic": data.get("topic"), "level": data.get("level"),
                    "reg": data.get("register", "neutral")}
        if not isinstance(data, dict) or not isinstance(data.get("items", []), list):
            self.errors.append("%s: a vocab file must be {topic, level, register, items:[…]}" % src)
            return
        rank_base = data.get("rank_base")
        for n, it in enumerate(data.get("items", [])):
            if not isinstance(it, dict):
                self.errors.append("%s: item %d is not an object: %r" % (src, n, str(it)[:60]))
                continue
            item = dict(it)
            for k, v in defaults.items():
                if item.get(k) is None:
                    item[k] = v
            if item.get("rank") is None:
                lvl = LEVEL_ORDER.index(item["level"]) if item.get("level") in LEVEL_ORDER else 3
                item["rank"] = (rank_base if rank_base is not None else 400 + lvl * 800) + n
            iid = item.get("id")
            if not iid:
                self.errors.append("%s: vocab item without id (%s)" % (src, item.get("es")))
                continue
            if iid in self.vocab:
                self.errors.append("%s: duplicate vocab id %s" % (src, iid))
                continue
            self.vocab[iid] = item
            self.sources[iid] = src

    def _add_unit(self, data, path):
        if not data:
            return
        src = os.path.relpath(path, ROOT).replace("\\", "/")
        uid = data.get("id")
        if not uid:
            self.errors.append("%s: unit without id" % src)
            return
        if uid in self.units or uid in self.retired:
            self.errors.append("%s: duplicate unit id %s" % (src, uid))
            return
        if data.get("retired"):
            self.retired[uid] = src
            return
        self.units[uid] = data
        self.sources[uid] = src

    def _add_many(self, data, path, target, label):
        if not data:
            return
        src = os.path.relpath(path, ROOT).replace("\\", "/")
        items = data if isinstance(data, list) else data.get("items", [data])
        for it in items:
            if not isinstance(it, dict):
                self.errors.append("%s: %s entry is not an object" % (src, label))
                continue
            iid = it.get("id")
            if not iid:
                self.errors.append("%s: %s without id" % (src, label))
                continue
            if iid in target or iid in self.retired:
                self.errors.append("%s: duplicate %s id %s" % (src, label, iid))
                continue
            if it.get("retired"):
                self.retired[iid] = src
                continue
            target[iid] = it
            self.sources[iid] = src

    def _add_pack(self, data, path):
        if not data:
            return
        src = os.path.relpath(path, ROOT).replace("\\", "/")
        for v in data.get("verbs", []):
            self._add_verb(v, src)
        for vf in data.get("vocab", []):
            # a pack's vocab section is a list of vocab "files" (same shape as content/vocab/*.json)
            self._add_vocab_file(vf, path)
        for u in data.get("units", []):
            self._add_unit(u, path)
        for key, target, label in (("dialogues", self.dialogues, "dialogue"),
                                   ("culture", self.culture, "culture note"),
                                   ("templates", self.templates, "template")):
            if data.get(key):
                self._add_many(data[key], path, target, label)
        if data.get("irregular"):
            self.irregular.update(data["irregular"])

    def _index_exercise(self, ex, owner_id, owner):
        eid = ex.get("id")
        if not eid:
            self.errors.append("%s: exercise without id" % owner_id)
            return
        if eid in self.exercises:
            self.errors.append("duplicate exercise id %s (in %s)" % (eid, owner_id))
            return
        ex.setdefault("topic", owner.get("topic"))
        ex.setdefault("level", owner.get("level"))
        self.exercises[eid] = (ex, owner_id)

    # ------------------------------------------------------------------ queries
    def units_of_level(self, level):
        return [u for u in self.unit_order if u.get("level") == level]

    def vocab_list(self, level=None, topic=None, include_vulgar=False):
        out = []
        for it in self.vocab.values():
            if level and it.get("level") != level:
                continue
            if topic and it.get("topic") != topic:
                continue
            if it.get("reg") == "vulgar" and not include_vulgar:
                continue
            out.append(it)
        return out

    def counts(self):
        return {"units": len(self.units), "verbs": len(self.verbs), "vocab": len(self.vocab),
                "dialogues": len(self.dialogues), "culture": len(self.culture),
                "templates": len(self.templates), "exercises": len(self.exercises)}
