"""The phone / web version: the browser runs this engine with Pyodide instead of talking to che/server.py.

web/js/backend.js unpacks engine.zip (che/ + content/ + audio/available.txt) into /app, keeps /app/progress in
the browser's own storage (IndexedDB), and calls call() for every request the app would send to /api/.
"""
import json

from . import api


def init():
    api.init()
    b = api.STATE["progress"]
    b.backup()


def _stamp():
    p = api.STATE.get("progress")
    return getattr(p, "revision", None) if p else None


def call(method, path, query_json, body_json):
    """Same contract as che/server.py's _api(): returns JSON text {code, payload} or {code, download}.
    "saved": true tells backend.js that the progress file changed, so it writes it to the phone's storage
    (also for a GET, e.g. opening a lesson marks it as started)."""
    query = json.loads(query_json or "{}")
    body = json.loads(body_json or "{}")
    before = _stamp()
    try:
        code, payload = api.dispatch(method, path, query, body)
    except api.ApiError as e:
        code, payload = e.code, {"error": str(e)}
    except Exception as e:                       # never break the app on one bad request
        import traceback
        traceback.print_exc()
        code, payload = 500, {"error": "%s: %s" % (type(e).__name__, e)}
    saved = _stamp() != before
    if isinstance(payload, tuple):               # (bytes, content-type, filename): a file to save
        data, ctype, name = payload
        text = data.decode("utf-8") if isinstance(data, bytes) else data
        return json.dumps({"code": code, "saved": saved, "download": {"text": text, "type": ctype, "name": name}},
                          ensure_ascii=False)
    return json.dumps({"code": code, "saved": saved, "payload": payload}, ensure_ascii=False)
