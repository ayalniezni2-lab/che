"""Mistake diagnosis — computed, no AI.

The app knows every form of every verb, so a wrong answer is looked up across all tenses and
persons of the target verb (plus the tú / vosotros / "regularized" forms it should NOT be) and
the learner is told exactly what they did.
"""
import difflib

from . import explain
from .conjugator import PERSONS, SIMPLE, COMPOUND, IMP_PERSONS, PERSON_LABEL, split_inf, _group, \
    _stem, _apply_sc, END, _E5
from .grading import edit_distance, only_ending_differs, ARTICLES
from .spanish import fold, normalize, tokens

CONFUSABLE = {
    frozenset(("ser", "estar")): "**ser** = what something is (identity, job, origin, character, the time). "
                                 "**estar** = how or where it is right now (mood, condition, location).",
    frozenset(("saber", "conocer")): "**saber** = to know a fact or how to do something. "
                                     "**conocer** = to know / be familiar with a person or a place.",
    frozenset(("pedir", "preguntar")): "**pedir** = to ask FOR something. **preguntar** = to ask a question.",
    frozenset(("llevar", "traer")): "**llevar** = to take something there (away from here). "
                                    "**traer** = to bring something here.",
    frozenset(("ir", "venir")): "**ir** = to go (away from where the speaker is). **venir** = to come (towards the speaker).",
    frozenset(("tener", "haber")): "**tener** = to have (own, hold). **haber** only helps other verbs (he comido) or means “there is” (hay).",
}
POR_PARA = ("Quick guide — **por**: cause or reason, exchange (“for $100”), “through / along / around”, "
            "how long. **para**: purpose (“in order to”), destination, deadline, who something is for.")
GUSTAR_LIKE = {"gustar", "encantar", "interesar", "importar", "molestar", "doler", "faltar", "quedar", "parecer",
               "costar", "convenir"}
IO_PRONOUNS = {"me", "te", "le", "nos", "les"}
REFL_NOTE = "The little pronoun follows the person: yo → **me**, vos → **te**, él/ella/usted → **se**, " \
            "nosotros → **nos**, ustedes/ellos → **se**."


def _b(text):
    return "**%s**" % text


class Diagnoser:
    def __init__(self, content, engine, grader):
        self.c, self.e, self.g = content, engine, grader
        banned = content.meta.get("banned") or {}
        self.banned_words = {}
        for w in banned.get("words", []):
            if w.get("ctx"):
                continue                      # context-dependent words are fine in other meanings
            for f in w.get("forms", []):
                self.banned_words.setdefault(fold(f), w)
        self.banned_verbs = {}
        for v in banned.get("verbs", []):
            try:
                t = engine._build(v["inf"], v.get("spec", {}))
                forms = [v["inf"], t["ger"], t["pp"]]
                for tense in SIMPLE:
                    forms += list(t[tense].values())
                for f in forms:
                    self.banned_verbs.setdefault(fold(f), v)
            except Exception:
                continue

    # ------------------------------------------------------------------ tables
    def table(self, inf, tense, hit=None, yours=None):
        try:
            t = self.e.conjugate(inf)
        except Exception:
            return None
        info = self.c.verbs.get(inf) or self.c.verbs.get(split_inf(inf)[0]) or {}
        audio = self._audio
        rows = []
        if tense in ("ger", "pp"):
            for key, label in (("ger", explain.tense_label("ger")), ("pp", explain.tense_label("pp"))):
                rows.append({"person": key, "label": label, "form": t[key],
                             "parts": self.e.parts(inf, key), "hit": key == tense, "audio": audio(t[key])})
        elif tense in ("imp", "impneg"):
            for key, neg in (("imp", False), ("impneg", True)):
                for p in IMP_PERSONS:
                    rows.append({"person": p, "label": explain.IMP_PERSON_ES[p] + (" — don't…" if neg else ""),
                                 "form": t[key][p], "parts": self.e.parts(inf, key, p),
                                 "hit": key == tense and p == hit,
                                 "yours": key == tense and p == yours, "audio": audio(t[key][p])})
        else:
            for p in PERSONS:
                rows.append({"person": p, "label": PERSON_LABEL[p], "form": t[tense][p],
                             "parts": self.e.parts(inf, tense, p),
                             "hit": p == hit or (hit in ("uds", "ellos") and p in ("uds", "ellos") and False),
                             "yours": p == yours, "audio": audio(t[tense][p])})
        return {"inf": inf, "tense": tense, "title": "%s — %s" % (inf, explain.tense_label(tense, long=True)),
                "subtitle": info.get("en", ""), "textbook": explain.TEXTBOOK.get(tense),
                "rows": rows, "tip": self.e.tip(inf, tense)}

    def full_tables(self, inf):
        order = ["pres", "pret", "impf", "iraf", "imp", "prog", "fut", "cond", "subj", "subjp", "perf", "plup", "ger"]
        return [self.table(inf, t) for t in order]

    def _audio(self, text):
        from .api import A
        try:
            return A().ref(text)
        except Exception:
            return None

    # ------------------------------------------------------------------ main entry
    def diagnose(self, ex, typed, expected):
        """-> {messages: [md strings], kinds: [str], table: {...}|None}"""
        msgs, kinds = [], []
        verb = dict(ex.get("verb") or {})
        table = None
        E = [fold(t) for t in tokens(expected)]
        T = [fold(t) for t in tokens(typed)]
        E_raw = tokens(expected)
        T_raw = tokens(typed)
        yours = None

        if not T:
            msgs.append("No answer — here is the right one: %s." % _b(expected))
            kinds.append("blank")
        target = None
        if verb.get("inf"):
            try:
                target = self.e.form(verb["inf"], verb.get("tense"), verb.get("person"))
            except Exception:
                target = None

        handled = False
        if T and target:
            tf = [fold(x) for x in tokens(target)]
            cand = None
            if len(E) == len(tf) or ex.get("type") == "conj":
                cand = " ".join(T)
                cand_raw = " ".join(T_raw)
            else:
                cand, cand_raw = self._aligned_segment(E, T, T_raw, tf)
            typed_accent = bool(cand_raw) and cand_raw != fold(cand_raw) and cand_raw != target.lower()
            if cand is not None and (cand != " ".join(tf) or typed_accent):
                m, k, yours = self._verb(verb["inf"], verb.get("tense"), verb.get("person"), cand, cand_raw, target)
                msgs += m
                kinds += k
                handled = True

        if T:
            m, k, auto = self._sentence(ex, E, T, E_raw, T_raw, skip_verb=handled, target=target)
            msgs += m
            kinds += k
            if auto and not verb.get("inf"):
                verb = auto
                try:
                    target = self.e.form(verb["inf"], verb["tense"], verb["person"])
                except Exception:
                    target = None

        if verb.get("inf") and verb.get("tense"):
            table = self.table(verb["inf"], verb["tense"], hit=verb.get("person"), yours=yours)
        if T and not msgs:
            msgs.append("You wrote %s; the answer is %s." % (_b(typed), _b(expected)))
            kinds.append("other")
        # look-alike pairs (sí / si, él / el …): say what each one means
        pair = None
        for p in self.g.pair_index.get(fold(expected), []):
            if {typed.strip().lower(), expected.strip().lower()} == {p["a"], p["b"]}:
                pair = p
        if pair:
            mine, mine_en = (pair["a"], pair["a_en"]) if typed.strip().lower() == pair["a"] else (pair["b"], pair["b_en"])
            want, want_en = (pair["a"], pair["a_en"]) if mine == pair["b"] else (pair["b"], pair["b_en"])
            msgs = ["%s means “%s”. Here you need %s = “%s”. The accent mark (or ñ) is the only difference, "
                    "and it changes the meaning." % (_b(mine), mine_en, _b(want), want_en)]
            kinds = ["accent_pair"]
        if ex.get("type") in ("mc", "listen_mc", "dialogue_q"):
            msgs = [m.replace("You wrote", "You chose").replace("you wrote", "you chose") for m in msgs]
        seen, out = set(), []
        for m in msgs:
            if m not in seen:
                seen.add(m)
                out.append(m)
        return {"messages": out, "kinds": list(dict.fromkeys(kinds)), "table": table, "verb": verb or None}

    # ------------------------------------------------------------------ verb analysis
    def _aligned_segment(self, E, T, T_raw, tf):
        """Find what the learner typed in the place of the target verb form inside a sentence."""
        n = len(tf)
        pos = next((i for i in range(len(E) - n + 1) if E[i:i + n] == tf), None)
        if pos is None:
            return None, None
        sm = difflib.SequenceMatcher(a=E, b=T, autojunk=False)
        for tag, i1, i2, j1, j2 in sm.get_opcodes():
            if tag == "replace" and i1 <= pos < i2:
                return " ".join(T[j1:j2]), " ".join(T_raw[j1:j2])
            if tag == "equal" and i1 <= pos and pos + n <= i2:
                return " ".join(tf), None       # the verb itself was right
        return None, None

    def _verb(self, inf, tense, person, cand, cand_raw, target):
        msgs, kinds, yours = [], [], None
        info = self.c.verbs.get(inf) or self.c.verbs.get(split_inf(inf)[0]) or {}
        en = explain.verb_en(info)
        base, refl = split_inf(inf)
        shown = cand_raw or cand
        need = "%s (%s)" % (explain.person_label(person, tense), explain.gloss(en, tense, person)) \
            if tense not in ("ger", "pp") else explain.tense_label(tense)

        forms = self.e.all_forms(inf, compounds=True)
        matches = []
        for f, t, p in forms:
            if fold(f) == cand and not (p == "ellos"):
                matches.append((t, p))
        literal = (cand_raw or "").lower()
        typed_accent = literal != fold(literal)     # the learner never HAS to type accents
        exact = [(t, p) for f, t, p in forms if f == literal and p != "ellos"] if typed_accent else []
        if exact:
            matches = exact                         # an accent was typed on purpose: take it literally
        elif matches:
            # typed without accents: if it is letter-for-letter the "regular pattern" form, that is the likelier story
            reg = self.e.regularized(inf)
            reg_target = reg[tense] if tense in ("ger", "pp") else reg[tense].get(person)
            if reg_target and literal == reg_target and fold(reg_target) != fold(target):
                matches = []
        matches = [m for m in matches if not (m[0] == tense and m[1] == person)] or matches
        if matches:
            same_tense = [m for m in matches if m[0] == tense]
            same_person = [m for m in matches if m[1] == person]
            t2, p2 = (same_tense or same_person or matches)[0]
            desc = explain.describe(t2, p2)
            gl = explain.gloss(en, t2, p2)
            if same_tense:
                kinds.append("wrong_person")
                yours = p2
                msgs.append("You wrote %s — that is %s (%s). Right tense, wrong person: this one needs %s, so it's %s."
                            % (_b(shown), desc, gl, need, _b(target)))
            elif same_person:
                kinds.append("wrong_tense")
                msgs.append("You wrote %s, which is %s (%s). Right person, wrong tense: here we need the %s — %s (%s)."
                            % (_b(shown), desc, gl, explain.tense_label(tense), _b(target),
                               explain.gloss(en, tense, person)))
            else:
                kinds.append("wrong_form")
                msgs.append("You wrote %s, which is %s (%s). This one needs %s: %s (%s)."
                            % (_b(shown), desc, gl, explain.describe(tense, person), _b(target),
                               explain.gloss(en, tense, person)))
            return msgs, kinds, yours

        # --- reflexive pronoun problems
        if refl and " " in target:
            pron, _, vpart = target.partition(" ")
            if cand == fold(vpart):
                kinds.append("missing_reflexive")
                msgs.append("%s needs its little pronoun: %s. %s" % (_b(inf), _b(target), REFL_NOTE))
                return msgs, kinds, yours
            cparts = cand.split(" ")
            if len(cparts) >= 2 and " ".join(cparts[1:]) == fold(vpart) and cparts[0] in ("me", "te", "se", "nos"):
                kinds.append("wrong_reflexive")
                msgs.append("The verb is right, the pronoun is not: %s, not %s. %s"
                            % (_b(target), _b(shown), REFL_NOTE))
                return msgs, kinds, yours

        # --- vowel change wrongly applied to vos / nosotros (checked first when the accent was typed)
        sc_hit = self._stem_change_on_vos(inf, base, tense, person, cand, cand_raw, shown, target)
        if sc_hit and (person == "nos" or (cand_raw and cand_raw != fold(cand_raw))):
            return sc_hit[0], sc_hit[1], yours

        # --- tú form (Spain / Mexico)
        tu = {k: v for k, v in self.e.tu_forms(inf).items()}
        vos_forms = {fold(f) for f, t, p in forms if p == "vos"}
        for k, f in tu.items():
            if fold(f) == cand and cand not in vos_forms:
                kinds.append("tu_form")
                vos_form = self.e.form(inf, "imp" if k == "imp" else "pres", "vos")
                m = "%s is the **tú** form, used in Spain and Mexico. In Argentina people say **vos**: %s." \
                    % (_b(shown), _b(vos_form))
                if sc_hit:
                    m += " Notice that with vos the vowel in the middle of the verb does not change."
                if fold(vos_form) != fold(target):
                    m += " (And this sentence needs %s: %s.)" % (need, _b(target))
                msgs.append(m)
                return msgs, kinds, "vos" if tense in ("pres",) else None

        # --- vosotros form (Spain)
        for k, f in self.e.vosotros_forms(inf).items():
            if fold(f) == cand and cand not in vos_forms:
                kinds.append("vosotros_form")
                uds = self.e.form(inf, k if k != "imp" else "imp", "uds")
                msgs.append("%s is the **vosotros** form, which exists only in Spain. In Argentina the plural "
                            "“you” is always **ustedes**: %s.%s"
                            % (_b(shown), _b(uds),
                               "" if fold(uds) == fold(target) else " (This sentence needs %s: %s.)" % (need, _b(target))))
                return msgs, kinds, yours

        # --- regular pattern used on an irregular verb / missed spelling change
        reg = self.e.regularized(inf)
        reg_target = reg[tense] if tense in ("ger", "pp") else reg[tense].get(person)
        if reg_target and fold(reg_target) != fold(target):
            hit_reg = cand == fold(reg_target)
            other = None
            if not hit_reg:
                for t in SIMPLE:
                    for p in PERSONS[:5]:
                        if fold(reg[t][p]) == cand and fold(self.e.form(inf, t, p)) != cand:
                            other = (t, p)
                            break
                    if other:
                        break
            if hit_reg or other:
                spelling_only = self._spelling_only(inf, tense, person, target)
                if spelling_only:
                    kinds.append("spelling_rule")
                    msgs.append("%s follows the normal pattern, and that is almost right — but the spelling has to "
                                "change to keep the same sound: %s." % (_b(shown), _b(target)))
                else:
                    kinds.append("regularized")
                    msgs.append("%s follows the normal pattern, but %s is irregular in the %s: %s."
                                % (_b(shown), _b(base), explain.tense_label(tense), _b(target)))
                if other and not hit_reg:
                    msgs.append("(The form you built would also be %s; this sentence needs %s.)"
                                % (explain.describe(*other), need))
                return msgs, kinds, yours

        if sc_hit:
            return sc_hit[0], sc_hit[1], yours

        # --- a form of a different verb
        others = [x for x in self.g.form_index.get(cand, []) if split_inf(x[0])[0] != base]
        if others:
            oinf, ot, op = others[0]
            pair = frozenset((split_inf(oinf)[0], base))
            oen = (self.c.verbs.get(oinf) or {}).get("en", "")
            if pair in CONFUSABLE:
                kinds.append("ser_estar" if pair == frozenset(("ser", "estar")) else "verb_choice")
                msgs.append("You used %s (%s); this sentence needs %s: %s. %s"
                            % (_b(oinf), shown, _b(base), _b(target), CONFUSABLE[pair]))
            else:
                kinds.append("other_verb")
                msgs.append("%s is a form of %s (%s). This one needs %s (%s): %s."
                            % (_b(shown), _b(oinf), oen, _b(inf), en, _b(target)))
            return msgs, kinds, yours

        if edit_distance(cand, fold(target)) == 1:
            kinds.append("verb_spelling")
            msgs.append("Very close — you wrote %s, the form is %s. Verb endings have to be exact, because the "
                        "ending is what tells you *who* and *when*." % (_b(shown), _b(target)))
            return msgs, kinds, yours

        kinds.append("verb_form")
        msgs.append("The form needed here is %s — %s%s."
                    % (_b(target), explain.describe(tense, person),
                       "" if tense in ("ger", "pp") else " (%s)" % explain.gloss(en, tense, person)))
        return msgs, kinds, yours

    def _stem_change_on_vos(self, inf, base, tense, person, cand, cand_raw, shown, target):
        """puedés / puedemos: the vowel change applied where the stress is on the ending."""
        _, _, spec = self.e.info(inf)
        sc = spec.get("sc")
        if not sc and spec.get("like"):
            sc = (self.e.irr.get(spec["like"]) or {}).get("sc")
        if not (sc and tense in ("pres", "imp") and person in ("vos", "nos")):
            return None
        g, stem = _group(base), _stem(base)
        changed = _apply_sc(stem, sc)
        if tense == "pres":
            wrong = changed + END["pres"][g][_E5.index(person)]
        else:
            wrong = changed + {"ar": "á", "er": "é", "ir": "í"}[g]
        if fold(wrong) != cand.split(" ")[-1]:
            return None
        src, dst = sc.split(">")
        msg = ("%s: the %s → %s change never happens with **%s**, because the stress falls on the ending, "
               "not on the middle of the verb. It is simply %s."
               % (_b(shown), src, dst.replace("h", ""), "vos" if person == "vos" else "nosotros", _b(target)))
        return [msg], ["stem_change_vos"]

    def _spelling_only(self, inf, tense, person, target):
        """True when the verb is regular here and only a sound-keeping spelling rule applies."""
        base, refl = split_inf(inf)
        try:
            t = self.e._build(base, {})
            t = self.e._with_compounds(base, t)
            if refl:
                t = self.e._reflexive(t)
            f = t[tense] if tense in ("ger", "pp") else t[tense].get(person)
            return f == target
        except Exception:
            return False

    # ------------------------------------------------------------------ sentence-level analysis
    def _gustar_rule(self, E, T, E_raw):
        """“no gusto el frío” → explain that gustar turns the sentence around."""
        for i in range(len(E) - 1):
            if E[i] not in IO_PRONOUNS:
                continue
            cells = [c for c in self.g.form_index.get(E[i + 1], []) if split_inf(c[0])[0] in GUSTAR_LIKE]
            if not cells:
                continue
            inf = split_inf(cells[0][0])[0]
            for j, t in enumerate(T):
                if any(split_inf(c[0])[0] == inf for c in self.g.form_index.get(t, [])):
                    if j == 0 or T[j - 1] not in IO_PRONOUNS:
                        idea = {"gustar": "pleasing", "encantar": "delightful", "interesar": "interesting",
                                "importar": "important", "molestar": "bothering", "doler": "hurting",
                                "faltar": "missing", "quedar": "left over", "parecer": "seeming",
                                "costar": "hard", "convenir": "a good idea"}.get(inf, "pleasing")
                        return ("With **%s** Spanish turns the sentence around: the THING is what does the action, "
                                "and the person goes in front as **me / te / le / nos / les**. So it is **%s** — "
                                "think “to me, it is %s”. You never say “yo %s” for this."
                                % (inf, " ".join(E_raw), idea, self.e.form(inf, "pres", "yo")))
        return None

    def _sentence(self, ex, E, T, E_raw, T_raw, skip_verb=False, target=None):
        msgs, kinds, auto_verb = [], [], None
        if E == T:
            return msgs, kinds, auto_verb
        g = self._gustar_rule(E, T, E_raw)
        if g:
            return [g], ["gustar"], auto_verb
        if len(E) > 1 and sorted(E) == sorted(T):
            kinds.append("word_order")
            msgs.append("All the right words — only the order is different. It should be: %s."
                        % _b(" ".join(E_raw)))
            return msgs, kinds, auto_verb
        tf = [fold(x) for x in tokens(target)] if target else []
        sm = difflib.SequenceMatcher(a=E, b=T, autojunk=False)
        missing, extra = [], []
        for tag, i1, i2, j1, j2 in sm.get_opcodes():
            if tag == "equal":
                continue
            if tag == "delete":
                missing += E_raw[i1:i2]
                continue
            if tag == "insert":
                extra += T_raw[j1:j2]
                continue
            es, ts = E[i1:i2], T[j1:j2]
            if skip_verb and tf and any(x in tf for x in es):
                continue
            if len(es) == len(ts):
                pairs = [(k, k) for k in range(len(es))]
            else:
                # different lengths: pair each typed word with the most similar expected word
                pairs, used = [], set()
                for kt, t in enumerate(ts):
                    best = min((k for k in range(len(es)) if k not in used),
                               key=lambda k: edit_distance(es[k], t), default=None)
                    if best is not None and edit_distance(es[best], t) <= max(2, len(t) // 2):
                        pairs.append((best, kt))
                        used.add(best)
                    else:
                        extra.append(T_raw[j1 + kt])
                missing += [E_raw[i1 + k] for k in range(len(es)) if k not in used]
            for ke, kt in pairs:
                m, kd, av = self._token_pair(es[ke], ts[kt], E_raw[i1 + ke], T_raw[j1 + kt], ex)
                msgs += m
                kinds += kd
                auto_verb = auto_verb or av
        for w in extra:
            m = self._banned(fold(w), w)
            if m:
                msgs.append(m)
                kinds.append("spain_word")
        if skip_verb and tf:
            missing = [x for x in missing if fold(x) not in tf]
            extra = [x for x in extra if fold(x) not in tf]
        if missing and len(E) > 1:
            kinds.append("missing_word")
            note = ""
            if "a" in [fold(x) for x in missing] and any(x in E for x in ("voy", "vas", "va", "vamos", "van")):
                note = " The going-to future always keeps the little **a**: voy **a** comer."
            msgs.append("You left out: %s.%s" % (", ".join(_b(x) for x in missing), note))
        if extra and len(E) > 1:
            kinds.append("extra_word")
            msgs.append("Extra word%s: %s." % ("s" if len(extra) > 1 else "", ", ".join(_b(x) for x in extra)))
        return msgs, kinds, auto_verb

    def _banned(self, tok, raw):
        w = self.banned_words.get(tok)
        if w and not w.get("textbook"):
            return "%s is not used in Argentina. People in Buenos Aires say %s." % (_b(raw), _b(w["ar"]))
        if w and w.get("textbook"):
            return "%s is the textbook word; Argentines say %s." % (_b(raw), _b(w["ar"]))
        v = self.banned_verbs.get(tok)
        if v:
            return "%s (from %s) is not used this way in Argentina — say %s.%s" \
                % (_b(raw), v["inf"], _b(v["ar"]), " " + v["why"] if v.get("why") else "")
        return None

    def _token_pair(self, e, t, e_raw, t_raw, ex):
        msgs, kinds, auto = [], [], None
        if {e, t} == {"por", "para"}:
            kinds.append("por_para")
            msgs.append("You used %s; this sentence needs %s. %s" % (_b(t_raw), _b(e_raw), POR_PARA))
            return msgs, kinds, auto
        b = self._banned(t, t_raw)
        if b:
            kinds.append("spain_word")
            msgs.append(b)
            return msgs, kinds, auto
        if t in ("tu", "ti", "contigo") and e in ("vos", "con vos"):
            kinds.append("tu_form")
            msgs.append("In Argentina it is %s, not %s — **vos** replaces both tú and ti (para vos, con vos)."
                        % (_b(e_raw), _b(t_raw)))
            return msgs, kinds, auto
        if e in ARTICLES and t in ARTICLES:
            kinds.append("agreement")
            msgs.append("It's %s here, not %s: the little word has to match the noun — masculine or feminine, "
                        "one or many." % (_b(e_raw), _b(t_raw)))
            return msgs, kinds, auto
        ef, tfm = self.g.form_index.get(e, []), self.g.form_index.get(t, [])
        if ef and tfm:
            e_infs = {split_inf(x[0])[0] for x in ef}
            t_infs = {split_inf(x[0])[0] for x in tfm}
            common = e_infs & t_infs
            if common:
                inf = sorted(common, key=lambda i: (self.c.verbs.get(i) or {}).get("rank", 999))[0]
                cell = next(x for x in ef if split_inf(x[0])[0] == inf)
                auto = {"inf": cell[0], "tense": cell[1], "person": cell[2]}
                m, k, _ = self._verb(cell[0], cell[1], cell[2], t, t_raw, self.e.form(*cell))
                return m, k, auto
            for pair, note in CONFUSABLE.items():
                if (e_infs & pair) and (t_infs & pair) and not (e_infs & t_infs):
                    a, bb = list(e_infs & pair)[0], list(t_infs & pair)[0]
                    cell = next(x for x in ef if split_inf(x[0])[0] == a)
                    auto = {"inf": cell[0], "tense": cell[1], "person": cell[2]}
                    kinds.append("ser_estar" if pair == frozenset(("ser", "estar")) else "verb_choice")
                    msgs.append("You used %s (%s); this sentence needs %s (%s). %s"
                                % (_b(bb), t_raw, _b(a), e_raw, note))
                    return msgs, kinds, auto
        if ef and not tfm:
            # maybe a tú / vosotros form of the expected verb
            for inf0, tense0, person0 in ef[:3]:
                m, k, _ = self._verb(inf0, tense0, person0, t, t_raw, self.e.form(inf0, tense0, person0))
                if k and k[0] in ("tu_form", "vosotros_form", "regularized", "spelling_rule", "stem_change_vos"):
                    return m, k, {"inf": inf0, "tense": tense0, "person": person0}
        if only_ending_differs(e, t) and len(e) > 2:
            kinds.append("agreement")
            end = "feminine plural" if e.endswith("as") else "masculine plural" if e.endswith("os") else \
                "feminine singular" if e.endswith("a") else "masculine singular" if e.endswith("o") else \
                "plural" if e.endswith("s") else "singular"
            msgs.append("%s → %s: describing words and nouns have to match in gender and number (here: %s)."
                        % (_b(t_raw), _b(e_raw), end))
            return msgs, kinds, auto
        if edit_distance(e, t) == 1:
            kinds.append("spelling")
            msgs.append("Check the spelling: you wrote %s, it is %s." % (_b(t_raw), _b(e_raw)))
            return msgs, kinds, auto
        other = self._vocab_meaning(t)
        if other:
            kinds.append("wrong_word")
            msgs.append("%s means “%s”. Here you need %s." % (_b(t_raw), other, _b(e_raw)))
            return msgs, kinds, auto
        kinds.append("wrong_word")
        msgs.append("You wrote %s where the sentence needs %s." % (_b(t_raw), _b(e_raw)))
        return msgs, kinds, auto

    def _vocab_meaning(self, tok):
        if not hasattr(self, "_vm"):
            self._vm = {}
            for it in self.c.vocab.values():
                es = normalize(it.get("es", ""))
                self._vm.setdefault(es, it.get("en"))
                parts = es.split(" ", 1)
                if len(parts) == 2 and parts[0] in ARTICLES:
                    self._vm.setdefault(parts[1], it.get("en"))
        return self._vm.get(tok)
