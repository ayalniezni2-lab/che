"""Endless practice, zero usage: drills are built from the verb database, the vocabulary base
and the sentence templates.  Weighted toward weak spots and toward high-frequency items."""
import hashlib
import random
from datetime import date

from . import explain, srs
from .conjugator import PERSONS, END, FUT, COND, _E5, _group, split_inf

LEVELS = ["a1", "a2", "b1", "b2"]
TENSES_BY_LEVEL = {
    "a1": ["pres", "iraf", "imp"],
    "a2": ["pret", "impf", "prog", "ger"],
    "b1": ["subj", "impneg", "fut", "cond", "pp", "perf"],
    "b2": ["subjp", "plup"],
}
PERSON_WEIGHT = {"yo": 1.0, "vos": 1.25, "el": 1.0, "nos": 0.7, "uds": 0.55, "ellos": 0.55}
SUBJECTS = {"yo": ["yo"], "vos": ["vos"], "el": ["él", "ella", "usted"], "nos": ["nosotros"],
            "uds": ["ustedes"], "ellos": ["ellos", "ellas"]}

RULE = {
    "pres": "Present endings for -%s verbs: **%s**.",
    "pret": "Past (finished actions) endings for -%s verbs: **%s**.",
    "impf": "“Used to / was doing” endings for -%s verbs: **%s**.",
}


def tenses_up_to(level):
    out = []
    for lv in LEVELS[:LEVELS.index(level) + 1 if level in LEVELS else 1]:
        out += TENSES_BY_LEVEL[lv]
    return out


def _svc():
    from .api_learn import services
    return services()


def _C():
    from .api import C
    return C()


def _P():
    from .api import P
    return P()


# ------------------------------------------------------------------ conjugation drills
# "estoy estando", "estoy pudiendo", "estoy sabiendo"… are not natural Spanish: never drill them
NO_PROG = {"estar", "haber", "poder", "saber", "ser", "querer", "parecer", "parecerse", "soler", "caber", "valer",
           "deber", "existir", "pertenecer", "merecer", "gustar", "encantar", "importar", "interesar", "faltar",
           "convenir", "ocurrir", "suceder", "necesitar", "llamarse", "odiar", "costar", "tener"}


def verb_allowed(v, tense, person):
    if v.get("drill") is False:
        return False
    if tense == "prog" and v.get("inf") in NO_PROG:
        return False
    if v.get("only") and tense not in v["only"]:
        return False
    if v.get("persons") and person and person not in v["persons"]:
        return False
    if tense in ("imp", "impneg") and (v.get("no_imp") or v.get("persons")):
        return False
    return True


def conj_why(inf, tense, person):
    e = _svc()["engine"]
    base, refl = split_inf(inf)
    g = _group(base)
    form = e.form(inf, tense, person)
    irregular = e.is_irregular(inf, tense, person)
    tip = e.tip(inf, tense) if irregular else None
    if tense in RULE:
        general = RULE[tense] % (g, ", ".join("-" + x for x in END[tense][g]))
        if tense == "pres" and person == "vos":
            general = ("With **vos** the present is simply the dictionary form minus -r, plus **-s**, stressed on the "
                       "ending: hablar → hablás, comer → comés, vivir → vivís. No vowel change, ever.")
    elif tense == "fut":
        general = "Simple future = the whole dictionary form (hablar, comer…) + **%s**." % ", ".join("-" + x for x in FUT)
    elif tense == "cond":
        general = "The “would” form = the whole dictionary form (hablar, comer…) + **%s**." % ", ".join("-" + x for x in COND)
    elif tense == "subj":
        general = ("The “wishes / not sure” form swaps the vowel: -ar verbs take **e** (hable), -er / -ir verbs take "
                   "**a** (coma, viva). Build it from the yo form of the present: tengo → tenga, hago → haga.")
    elif tense == "subjp":
        general = ("Past “wishes / not sure” form: take the ellos past form, drop **-ron**, add **-ra, -ras, -ra, "
                   "-ramos, -ran**: tuvieron → tuviera, hablaron → hablara.")
    elif tense == "imp":
        general = ("Command for **vos** = the dictionary form without its -r, stressed on the last vowel: hablá, comé, "
                   "vení, decí." if person == "vos" else
                   "Commands for usted / ustedes borrow the “wishes” form: hable, coma, venga · hablen, coman, vengan.")
    elif tense == "impneg":
        general = "“Don't…” = **no** + the “wishes” form: no hables, no comas, no vengas."
    elif tense == "ger":
        general = "The -ndo form: -ar → **-ando**, -er / -ir → **-iendo**."
    elif tense == "pp":
        general = "The “done” form: -ar → **-ado**, -er / -ir → **-ido** (hablado, comido, vivido)."
    elif tense == "iraf":
        general = "The everyday future: present of **ir** + **a** + the dictionary form — voy a, vas a, va a, vamos a, van a."
    elif tense == "prog":
        general = "Happening right now: present of **estar** + the -ndo form — estoy comiendo."
    elif tense == "perf":
        general = ("**haber** (he, has, ha, hemos, han) + the “done” form (comido, hecho). You will read it more than hear it: in Buenos "
                   "Aires people normally just use the simple past (comí, not he comido).")
    elif tense == "plup":
        general = "“Had done” = **había, habías, había, habíamos, habían** + the “done” form (comido, hecho)."
    else:
        general = ""
    if refl:
        general += " **%s** also carries its pronoun: me, te, se, nos, se." % inf
    if irregular:
        # the memory tip itself is shown once, in the 💡 box under the table — never repeated here
        spelling = (e.families.get("spelling") or {}).get("tip")
        if tip and spelling and tip.endswith(spelling):
            return ("%s keeps its normal endings — only the spelling changes, to keep the same sound: **%s**."
                    % (base, form))
        if tip:
            return "%s is irregular here: **%s**. The table shows the whole pattern." % (base, form)
        return "%s is irregular here: **%s**. %s" % (base, form, general)
    return general


def _plain(spec):
    return not any(spec.get(k) for k in ("sc", "zc", "shift", "yo", "pret_stem", "fut_stem", "like", "pres",
                                          "pret", "impf", "subj", "ger", "pp", "imp"))


def conj_extra(inf, tense, person):
    """Another common verb that behaves the same way in the same cell (same family of irregularity)."""
    e = _svc()["engine"]
    c = _C()
    base, refl = split_inf(inf)
    g = _group(base)
    irregular = e.is_irregular(inf, tense, person)
    _, _, spec = e.info(inf)
    fam = (spec.get("family") or {}).get(tense) if isinstance(spec.get("family"), dict) else None
    fam = fam or e._infer_family(base, spec, tense)
    if irregular and not fam:
        return None                                   # one of a kind (ser, ir…): nothing behaves the same
    preferred = ["hablar", "comer", "vivir", "trabajar", "aprender", "escribir"]
    ordered = [x for x in preferred if x in c.verbs] + [x for x in c.verbs if x not in preferred]
    for other in ordered:
        v = c.verbs[other]
        ob, orf = split_inf(other)
        if ob == base or orf != refl or v.get("reg") == "vulgar" or not verb_allowed(v, tense, person):
            continue
        _, _, os_ = e.info(other)
        if irregular:
            ofam = (os_.get("family") or {}).get(tense) if isinstance(os_.get("family"), dict) else None
            ofam = ofam or e._infer_family(ob, os_, tense)
            if ofam != fam or not e.is_irregular(other, tense, person):
                continue
            if fam == "sc_boot" and os_.get("sc") != spec.get("sc"):
                continue
        else:
            if _group(ob) != g or not _plain(os_) or e.is_irregular(other, tense, person):
                continue
        subj = "" if tense in ("ger", "pp", "imp", "impneg") else SUBJECTS[person][0] + " "
        return {"es": "%s → %s%s" % (other, subj, e.form(other, tense, person)),
                "en": "%s → %s" % (v.get("en", ""), explain.gloss(explain.verb_en(v), tense, person)),
                "say": e.form(other, tense, person)}
    return None


def make_conj(inf, tense, person=None):
    e = _svc()["engine"]
    v = _C().verbs.get(inf) or {}
    form = e.form(inf, tense, person)
    accept = []
    t = e.conjugate(inf)
    if t.get("reflexive") and tense in ("iraf", "prog"):
        # me voy a levantar = voy a levantarme ; me estoy levantando = estoy levantándome
        from .spanish import attach
        from .conjugator import REFLEXIVE, IR_PRES, ESTAR_PRES
        if tense == "iraf":
            accept.append("%s a %s" % (IR_PRES[person], attach(t["base"], REFLEXIVE[person])))
        else:
            accept.append("%s %s" % (ESTAR_PRES[person], attach(e.conjugate(t["base"])["ger"], REFLEXIVE[person])))
    who = explain.person_label(person, tense) if person else ""
    ex = {
        "id": "conj:%s:%s:%s" % (inf, tense, person or "-"),
        "key": "verb:%s:%s:%s" % (inf, tense, person or "-"),
        "type": "conj", "topic": "conj:" + tense, "level": v.get("level"),
        "prompt": "Type the right form.",
        "inf": inf, "inf_en": v.get("en", ""), "reg": v.get("reg", "neutral"),
        "tense_label": explain.tense_label(tense, long=True), "person_label": who,
        "gloss": explain.gloss_with_who(explain.verb_en(v), tense, person),
        "verb": {"inf": inf, "tense": tense, "person": person},
        "answer": form, "accept": accept, "generated": True,
        "why": conj_why(inf, tense, person), "extra": conj_extra(inf, tense, person),
    }
    return ex


def _cells(v, inf, tenses, persons=None):
    out = []
    for tense in tenses:
        if tense in ("ger", "pp"):
            if verb_allowed(v, tense, None):
                out.append((inf, tense, None))
            continue
        ps = ["vos", "el", "uds"] if tense in ("imp", "impneg") else PERSONS
        for p in ps:
            if persons and p not in persons:
                continue
            if verb_allowed(v, tense, p):
                out.append((inf, tense, p))
    return out


def unit_drills(unit):
    """Expand a unit's generator specs:  {"kind":"conj","verbs":[…],"tenses":[…],"persons":[…],"n":6}"""
    out = []
    c = _C()
    seed = int(hashlib.sha1((unit["id"] + date.today().isoformat()).encode()).hexdigest()[:8], 16)
    rnd = random.Random(seed)
    for spec in unit.get("drills", []):
        if spec.get("kind") != "conj":
            continue
        cells = []
        for inf in spec.get("verbs", []):
            v = c.verbs.get(inf)
            if v is None:
                continue
            cells += _cells(v, inf, spec.get("tenses", ["pres"]), spec.get("persons"))
        rnd.shuffle(cells)
        picked, seen_forms = [], set()
        for cell in cells:
            if cell[2] == "ellos" and (cell[0], cell[1], "uds") in picked:
                continue
            picked.append(cell)
            if len(picked) >= spec.get("n", 6):
                break
        for inf, tense, person in picked:
            ex = make_conj(inf, tense, person)
            ex["id"] = "%s:%s" % (unit["id"], ex["id"])
            ex["topic"] = unit.get("topic") or ex["topic"]
            out.append(ex)
    return out


def learner_level():
    """How hard new words and verbs may be: the placement level, raised by the hardest chapter opened so far
    (the course mixes levels: an A2 topic chapter can sit in the present-tense stage)."""
    p = _P().data
    lvl = (p.get("placement") or {}).get("level") or "a1"
    best = LEVELS.index(lvl) if lvl in LEVELS else 0
    c = _C()
    from . import course
    cur, _ = course.state(p, c)
    index = course.course(c)["index"]
    for uid, st in p["units"].items():
        u = c.units.get(uid) or c.dialogues.get(uid)
        hit = index.get(uid)
        if hit and hit[0] > cur:
            continue                           # a peek at a later stage does not raise the level
        if u and (st.get("started") or st.get("completed") or st.get("skipped")) and u.get("level") in LEVELS:
            best = max(best, LEVELS.index(u["level"]))
    return LEVELS[best]


def pick_conj(n, tenses=None, verbs=None, level=None, exclude=(), allow=None, max_new=2, prefer=None):
    """Weighted choice of n conjugation cells: weak spots and frequent verbs come up more.

    allow(inf, tense) -> True (taught), "new" (may come with an intro card first) or False (not yet).
    At most max_new different new verb+tense pairs per call. prefer = a tense to give ~60% of the cells.
    """
    c, p = _C(), _P().data
    level = level or learner_level()
    tenses = tenses or tenses_up_to(level)
    cards = p["srs"]
    pool, weights, newness = [], [], []
    for inf, v in c.verbs.items():
        if verbs and inf not in verbs:
            continue
        if v.get("reg") == "vulgar" and not p["settings"].get("vulgar"):
            continue
        if not verbs and LEVELS.index(v.get("level") or "a1") > LEVELS.index(level):
            continue
        freq = 1.0 / (1.0 + (v.get("rank", 300) / 40.0))
        for cell in _cells(v, inf, tenses):
            if cell[2] == "ellos":
                continue
            ok = allow(cell[0], cell[1]) if allow else True
            if not ok:
                continue
            key = "verb:%s:%s:%s" % (cell[0], cell[1], cell[2] or "-")
            if key in exclude:
                continue
            card = cards.get(key)
            weak = srs.weakness(card) if card else 0.5
            due = 1.6 if (card and srs.is_due(card)) else 1.0
            focus = 1.0
            if prefer:
                focus = 2.5 if cell[1] == prefer else 0.6
            pool.append(cell)
            newness.append(ok == "new")
            weights.append(freq * (0.35 + 1.65 * weak) * due * focus * PERSON_WEIGHT.get(cell[2] or "yo", 1.0)
                           * (0.5 if ok == "new" else 1.0))
    out, new_pairs = [], set()
    while pool and len(out) < n:
        i = random.choices(range(len(pool)), weights=weights, k=1)[0]
        inf, tense, person = pool[i]
        if newness[i] and (inf, tense) not in new_pairs:
            if len(new_pairs) >= max_new:
                pool.pop(i); weights.pop(i); newness.pop(i)
                continue
            new_pairs.add((inf, tense))
        ex = make_conj(inf, tense, person)
        if newness[i]:
            ex["new_pair"] = True
        out.append(ex)
        pool.pop(i)
        weights.pop(i)
        newness.pop(i)
    return out


def verb_intro(inf, tense):
    """A card that shows a verb's table BEFORE it is ever asked (teach first, then test)."""
    svc = _svc()
    v = _C().verbs.get(inf) or {}
    table = svc["diagnoser"].table(inf, tense)
    return {"id": "verbintro:%s:%s" % (inf, tense), "type": "intro", "kind": "verb", "generated": True,
            "inf": inf, "en": v.get("en", ""), "tense": tense,
            "title": "New: %s in the %s" % (inf, explain.tense_label(tense, long=True)),
            "table": table}   # the table already carries the memory tip (shown once, as 💡)


def with_verb_intros(exs):
    """Put an intro card in front of the first question about each new verb+tense pair."""
    out, done = [], set()
    for ex in exs:
        v = ex.get("verb") or {}
        pair = (v.get("inf"), v.get("tense"))
        if ex.get("new_pair") and pair not in done:
            done.add(pair)
            out.append(verb_intro(*pair))
        out.append(ex)
    return out


# ------------------------------------------------------------------ vocabulary drills
def _distractors(item, field, n=3):
    c = _C()
    same = [x for x in c.vocab.values() if x["id"] != item["id"] and x.get(field) != item.get(field)
            and x.get("reg") != "vulgar"]
    rnd = random.Random()
    topic = [x for x in same if x.get("topic") == item.get("topic")]
    level = [x for x in same if x.get("level") == item.get("level") and x not in topic]
    rnd.shuffle(topic)
    rnd.shuffle(level)
    rnd.shuffle(same)
    out, seen = [], {item.get(field)}
    for x in topic[:2] + level + same:
        if x.get(field) not in seen:
            seen.add(x.get(field))
            out.append(x.get(field))
        if len(out) >= n:
            break
    return out


def make_vocab(item, mode):
    """mode: en2es (typed) | es2en (choice) | listen (hear the word, choose its meaning) | dictation"""
    reg = item.get("reg", "neutral")
    base = {"vocab": item["id"], "topic": item.get("topic") or "vocab", "level": item.get("level"),
            "reg": reg, "generated": True, "note": item.get("note"),
            "extra": {"es": item["ex"], "en": item.get("ex_en", "")} if item.get("ex") else None}
    tag = "" if reg == "neutral" else " (%s)" % reg
    if mode == "en2es":
        ex = dict(base, id="vocab:%s:en2es" % item["id"], key="vocab:%s:en2es" % item["id"], type="en2es",
                  prompt="How do you say this in Argentine Spanish?", en=item["en"] + tag, answer=item["es"],
                  accept=list(item.get("alt", [])), article_optional=True, say=item["es"],
                  why=item.get("note") or "“%s” = **%s**." % (item["en"], item["es"]))
    elif mode == "es2en":
        ex = dict(base, id="vocab:%s:es2en" % item["id"], key="vocab:%s:es2en" % item["id"], type="mc",
                  prompt="What does this mean?", es=item["es"], answer=item["en"],
                  options=[item["en"]] + _distractors(item, "en"),
                  why=item.get("note") or "**%s** = “%s”." % (item["es"], item["en"]))
    elif mode == "listen":
        ex = dict(base, id="vocab:%s:listen" % item["id"], key="vocab:%s:listen" % item["id"], type="listen_mc",
                  prompt="Listen. What does it mean?", es=item["es"], answer=item["en"],
                  options=[item["en"]] + _distractors(item, "en"),
                  why="You heard **%s** = “%s”." % (item["es"], item["en"]))
    else:
        ex = dict(base, id="vocab:%s:dictation" % item["id"], key="vocab:%s:listen" % item["id"],
                  type="listen_type", prompt="Listen and type what you hear.", es=item["ex"],
                  en=item.get("ex_en"), answer=item["ex"], extra=None,
                  why="The sentence was: **%s** (%s)" % (item["ex"], item.get("ex_en", "")))
    return ex


def pick_vocab(n, level=None, topic=None, modes=("en2es", "es2en", "listen", "dictation"), new_ok=True,
               exclude=()):
    c, p = _C(), _P().data
    level = level or learner_level()
    cards = p["srs"]
    pool, weights = [], []
    for it in c.vocab.values():
        if it.get("reg") == "vulgar" and not p["settings"].get("vulgar"):
            continue
        if topic and it.get("topic") != topic:
            continue
        if not topic and LEVELS.index(it.get("level") or "a1") > LEVELS.index(level):
            continue
        for mode in modes:
            if mode == "dictation" and not it.get("ex"):
                continue
            if mode in ("listen", "dictation") and it.get("no_audio"):
                continue                      # e.g. chat abbreviations: nothing sensible to listen to
            key = "vocab:%s:%s" % (it["id"], "listen" if mode == "dictation" else mode)
            if key in exclude:
                continue
            card = cards.get(key)
            if card is None and not new_ok:
                continue
            weak = srs.weakness(card) if card else 0.45
            due = 1.8 if (card and srs.is_due(card)) else (1.0 if card is None else 0.35)
            rank = it.get("rank") or 1500
            pool.append((it, mode))
            rare = 0.25 if (card is None and it.get("reg") == "slang") else 1.0   # new slang: seldom
            weights.append((1.0 / (1.0 + rank / 600.0)) * (0.3 + 1.7 * weak) * due * rare)
    out, used = [], set()
    while pool and len(out) < n:
        i = random.choices(range(len(pool)), weights=weights, k=1)[0]
        it, mode = pool.pop(i)
        weights.pop(i)
        if it["id"] in used:
            continue
        used.add(it["id"])
        out.append(make_vocab(it, mode))
    return out
