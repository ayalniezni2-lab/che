"""What the learner has been TAUGHT so far, and the "one tense at a time" pace.

Drills, word hints and the next-lesson advice all ask this module, so nothing is tested before a lesson
(or an intro card) has shown it:
  * known units  = course.py: every chapter of the stages before the current one, what was opened in the current
                   stage, and what was finished in later ones
  * taught       = the tenses, verb+tense pairs and words those units teach, plus anything already practised
  * a verb in a tense may be drilled when it was taught in that tense, or when it is regular there and its
    group (-ar / -er / -ir) was taught in that tense; anything else first gets an intro card with its table
  * focus tense  = the newest taught tense not yet mastered; mastered = 80% right over the last 20 answers
"""
import re

from .spanish import fold, normalize

LEVELS = ["a1", "a2", "b1", "b2"]
MASTERY = 0.8          # share right over the recent answers
MASTERY_MIN = 12       # answers needed before a tense can count as mastered
WINDOW = 20            # recent answers kept per tense
ARTICLES = ("el", "la", "los", "las", "un", "una", "unos", "unas")
# grammar words: never hinted (they are taught by the lessons, not as vocabulary)
STOP = set("""a al de del en y e o u que el la lo los las un una unos unas le les me te se nos mi mis tu tus su sus
con por para sin no si sí muy más ya yo vos él ella ellos ellas nosotros nosotras ustedes usted este esta estos estas
ese esa esos esas eso esto como cuando pero también bien hay es son está están soy sos qué cómo dónde quién cuál
cuándo cuánto cuánta""".split())

_CUR = {"sig": None}
_REG = {}


# ------------------------------------------------------------------ what each unit teaches
def _group(inf):
    base = inf[:-2] if inf.endswith("se") else inf
    return {"ír": "ir"}.get(base[-2:], base[-2:])


def _unit_teaches(u):
    pairs, words = set(), set()
    for d in u.get("drills", []) or []:
        if d.get("kind") == "conj":
            for v in d.get("verbs") or []:
                for t in d.get("tenses") or []:
                    pairs.add((v, t))
    for b in u.get("teach", []):
        if b.get("t") == "verbtable" and b.get("verb"):
            pairs.add((b["verb"], b.get("tense", "pres")))
        elif b.get("t") == "vocab":
            words.update(b.get("ids") or [])
    for ex in u.get("exercises", []):
        v = ex.get("verb") or {}
        if v.get("inf") and v.get("tense"):
            pairs.add((v["inf"], v["tense"]))
        if ex.get("vocab"):
            words.add(ex["vocab"])
    return pairs, words


def curriculum(c):
    """Per unit: (verb, tense) pairs, word ids, and the tenses it is the first to teach. Cached per content load.
    A unit only teaches the tenses of its course stage (and earlier ones): a stray past-tense example in a
    present-tense chapter does not unlock the past."""
    if _CUR["sig"] is not c._sig or _CUR.get("content") is not c:
        from . import course
        units, seen, order = {}, set(), []
        for u in c.unit_order:
            pairs, words = _unit_teaches(u)
            allowed = course.tenses_upto(u["id"], c)
            if allowed is not None:
                pairs = {(v, t) for v, t in pairs if t in allowed}
            tenses = {t for _, t in pairs}
            new = tenses - seen
            seen |= tenses
            order += [t for t in sorted(new)]
            units[u["id"]] = {"pairs": pairs, "words": words, "tenses": tenses, "new_tenses": new}
        _CUR.update(sig=c._sig, content=c, units=units, tense_order=order)
        _REG.clear()
    return _CUR


# ------------------------------------------------------------------ what this learner has been taught
def known_units(p, c, level=None):
    """(units opened / finished, units taken as known without being opened) — see course.known_units()."""
    from . import course
    return course.known_units(p, c)


def _unit_spanish(c, u):
    """All the Spanish a unit SHOWS with its translation: examples, tables, `code` in the text, its dialogue."""
    out = []
    for b in u.get("teach", []):
        t = b.get("t")
        if t == "examples":
            out += [it.get("es", "") for it in b.get("items", [])]
        elif t == "table":
            out += [str(cell) for row in b.get("rows", []) for cell in row]
        elif t == "dialogue":
            d = c.dialogues.get(b.get("ref")) or {}
            out += [line.get("es", "") for line in d.get("lines", [])]
        if b.get("md"):
            out += re.findall(r"`([^`]+)`", b["md"])
    return out


def unit_seen(c, grader):
    """Per unit: vocab ids and verbs that appear in its teaching (not only its word lists). Cached."""
    if _CUR.get("seen_sig") is not c._sig:
        single, multi = _word_index(c)
        seen = {}
        for u in c.unit_order:
            ids, verbs = set(), set()
            for text in _unit_spanish(c, u):
                words = [normalize(w) for w in re.findall(r"[A-Za-zÁÉÍÓÚÜÑáéíóúüñ]+", text)]
                for i, w in enumerate(words):
                    for n in (2, 3, 4):
                        hit = multi.get(" ".join(words[i:i + n]))
                        if hit:
                            ids.add(hit["id"])
                    if w in single:
                        ids.add(single[w]["id"])
                    if w in c.verbs:
                        verbs.add(w)
                    elif w in grader.form_index:
                        verbs.add(grader.form_index[w][0][0])
            seen[u["id"]] = (ids, verbs)
        _CUR.update(seen_sig=c._sig, seen=seen)
    return _CUR["seen"]


def taught(p, c, level, grader=None):
    cur = curriculum(c)
    pairs, words, seen_verbs = set(), set(), set()
    lesson_tenses, assumed_tenses = set(), set()
    seen = unit_seen(c, grader) if grader else {}
    opened, assumed = known_units(p, c, level)
    for uid in opened | assumed:
        info = cur["units"].get(uid)
        if info:
            pairs |= info["pairs"]
            words |= info["words"]
            # lessons actually opened set the pace; chapters of earlier stages never opened are taken as known
            (lesson_tenses if uid in opened else assumed_tenses).update(info["tenses"])
        if uid in seen:                        # read in a lesson, with its translation: no hint needed
            words |= seen[uid][0]
            seen_verbs |= seen[uid][1]
    for key in p["srs"]:                       # anything already practised counts as seen
        part = key.split(":")
        if part[0] == "verb" and len(part) >= 3:
            pairs.add((part[1], part[2]))
        elif part[0] == "vocab" and len(part) >= 2:
            words.add(part[1])
    tenses = {t for _, t in pairs}
    groups = {}
    for inf, t in pairs:
        groups.setdefault(t, set()).add(_group(inf))
    return {"pairs": pairs, "verbs": {v for v, _ in pairs}, "tenses": tenses, "groups": groups, "words": words,
            "seen_verbs": seen_verbs | {v for v, _ in pairs}, "reflexive": any(v.endswith("se") for v, _ in pairs),
            "lesson_tenses": lesson_tenses, "assumed_tenses": assumed_tenses - lesson_tenses}


def regular_in(engine, inf, tense):
    key = (inf, tense)
    if key not in _REG:
        from .conjugator import PERSONS, IMP_PERSONS
        persons = [None] if tense in ("ger", "pp") else (IMP_PERSONS if tense in ("imp", "impneg") else PERSONS)
        try:
            _REG[key] = not any(engine.is_irregular(inf, tense, p) for p in persons)
        except Exception:
            _REG[key] = False
    return _REG[key]


def cell_taught(t, engine, inf, tense):
    """May this verb be drilled in this tense without an intro card first?"""
    if (inf, tense) in t["pairs"]:
        return True
    if tense not in t["tenses"]:
        return False
    if inf.endswith("se") and not t["reflexive"]:
        return False
    return regular_in(engine, inf, tense) and _group(inf) in t["groups"].get(tense, set())


# ------------------------------------------------------------------ the pace: one tense at a time
def record(p, tense, correct):
    recent = p.setdefault("tense_recent", {}).setdefault(tense, [])
    recent.append(1 if correct else 0)
    del recent[:-WINDOW]


def tense_score(p, tense):
    recent = (p.get("tense_recent") or {}).get(tense) or []
    return (sum(recent) / len(recent) if recent else 0.0), len(recent)


def mastered(p, tense):
    acc, n = tense_score(p, tense)
    return n >= MASTERY_MIN and acc >= MASTERY


def struggling(p, tense):
    acc, n = tense_score(p, tense)
    return n >= MASTERY_MIN and acc < MASTERY


def comfortable(p, t, tense):
    """Mastered — or covered by the placement test and not shown otherwise by the learner's answers."""
    if tense in t.get("assumed_tenses", ()) and tense not in t.get("lesson_tenses", ()):
        return not struggling(p, tense)
    return mastered(p, tense)


def focus_tense(p, c, t):
    """The newest tense from the lessons the learner has opened that is not comfortable yet (or None)."""
    pool = set(t.get("lesson_tenses", ())) | {x for x in t.get("assumed_tenses", ()) if struggling(p, x)}
    order = [x for x in curriculum(c)["tense_order"] if x in pool and x not in ("ger", "pp")]
    for tense in reversed(order):
        if not comfortable(p, t, tense):
            return tense
    return None


# ------------------------------------------------------------------ hints for words not taught yet
def _word_index(c):
    if _CUR.get("words_sig") is not c._sig:
        single, multi = {}, {}
        for it in sorted(c.vocab.values(), key=lambda x: x.get("rank") or 99999):
            if it.get("reg") == "vulgar" or it.get("no_audio"):
                continue
            words = normalize(it.get("es", "")).split(" ")
            if len(words) > 1 and words[0] in ARTICLES:
                words = words[1:]
            if not words or not words[0] or "/" in it.get("es", ""):
                continue
            if len(words) == 1:
                w = words[0]
                forms = {w, w + "s", w + "es"}
                if w.endswith("o"):
                    forms |= {w[:-1] + "a", w[:-1] + "as", w[:-1] + "os"}
                if w.endswith("z"):
                    forms.add(w[:-1] + "ces")
                for f in forms:
                    single.setdefault(f, it)
            elif len(words) <= 4:
                multi.setdefault(" ".join(words), it)
        _CUR.update(words_sig=c._sig, single=single, multi=multi)
    return _CUR["single"], _CUR["multi"]


def exercise_spanish(ex):
    es = ex.get("es") or ""
    if "___" in es:
        return ex.get("say") or es.replace("___", ex.get("answer", ""))
    if ex.get("type") in ("en2es", "order", "conj", "type"):
        return ex.get("say") or ex.get("answer", "")
    return es or ""


def hints(c, grader, ex, t, limit=4):
    """[{es, en}] for words in this exercise that no lesson has taught this learner yet."""
    if ex.get("topic") == "placement" or ex.get("type") in ("match", "intro", "conj"):
        return []
    text = exercise_spanish(ex)
    if not text:
        return []
    single, multi = _word_index(c)
    raw = re.findall(r"[A-Za-zÁÉÍÓÚÜÑáéíóúüñ]+", text)
    words = [normalize(w) for w in raw]
    out, used, i = [], set(), 0
    target = ex.get("vocab")
    while i < len(words) and len(out) < limit:
        hit, step = None, 1
        for n in (4, 3, 2):                                  # phrases first: "todos los días"
            if i + n <= len(words) and " ".join(words[i:i + n]) in multi:
                hit, step = multi[" ".join(words[i:i + n])], n
                break
        w = words[i]
        proper = raw[i][:1].isupper() and i > 0
        if hit is None and w not in STOP and not proper:
            hit = single.get(w)
            if hit is None and (w in grader.form_index or w in c.verbs):   # a verb form -> its dictionary form
                inf = w if w in c.verbs else grader.form_index[w][0][0]
                if inf not in t.get("seen_verbs", t["verbs"]):
                    v = c.verbs.get(inf) or {}
                    if inf not in used and v.get("en"):
                        used.add(inf)
                        out.append({"es": inf, "en": v["en"]})
        if hit is not None and hit["id"] not in t["words"] and hit["id"] != target and hit["id"] not in used:
            used.add(hit["id"])
            out.append({"es": hit["es"], "en": hit["en"]})
        i += step
    return out
