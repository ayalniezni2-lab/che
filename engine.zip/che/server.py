"""Che! local server.  Python standard library only.

Serves the web/ frontend, the pre-generated audio/ clips and a small JSON API.
Binds to 127.0.0.1 only: it is a personal app, nothing is exposed to the network.
"""
import json
import mimetypes
import os
import posixpath
import sys
import threading
import traceback
import urllib.parse
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

from . import api

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
WEB_DIR = os.path.join(ROOT, "web")
AUDIO_DIR = os.path.join(ROOT, "audio")

mimetypes.add_type("application/javascript", ".js")
mimetypes.add_type("audio/mpeg", ".mp3")
mimetypes.add_type("image/svg+xml", ".svg")
mimetypes.add_type("application/manifest+json", ".webmanifest")
mimetypes.add_type("image/x-icon", ".ico")


class Handler(BaseHTTPRequestHandler):
    server_version = "Che/1.0"
    protocol_version = "HTTP/1.1"

    def log_message(self, fmt, *args):   # keep the console quiet
        pass

    # ------------------------------------------------------------ helpers
    def _send(self, code, body, ctype="application/json; charset=utf-8", extra=None):
        if isinstance(body, (dict, list)):
            body = json.dumps(body, ensure_ascii=False).encode("utf-8")
        elif isinstance(body, str):
            body = body.encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        for k, v in (extra or {}).items():
            self.send_header(k, v)
        self.end_headers()
        if self.command != "HEAD":
            self.wfile.write(body)

    def _send_file(self, path, cache=False):
        if not os.path.isfile(path):
            return self._send(404, {"error": "not found"})
        ctype = mimetypes.guess_type(path)[0] or "application/octet-stream"
        if ctype.startswith("text/") or ctype == "application/javascript":
            ctype += "; charset=utf-8"
        size = os.path.getsize(path)
        start, end = 0, size - 1
        rng = self.headers.get("Range")
        code = 200
        if rng and rng.startswith("bytes="):
            try:
                a, b = rng[6:].split("-", 1)
                start = int(a) if a else 0
                end = int(b) if b else size - 1
                end = min(end, size - 1)
                if start <= end:
                    code = 206
                else:
                    start, end = 0, size - 1
            except ValueError:
                start, end = 0, size - 1
        length = end - start + 1
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(length))
        self.send_header("Accept-Ranges", "bytes")
        if code == 206:
            self.send_header("Content-Range", "bytes %d-%d/%d" % (start, end, size))
        self.send_header("Cache-Control", "max-age=86400" if cache else "no-cache")
        self.end_headers()
        if self.command == "HEAD":
            return
        with open(path, "rb") as f:
            f.seek(start)
            self.wfile.write(f.read(length))

    @staticmethod
    def _safe_join(base, rel):
        rel = posixpath.normpath(urllib.parse.unquote(rel)).lstrip("/")
        if rel.startswith("..") or os.path.isabs(rel):
            return None
        full = os.path.abspath(os.path.join(base, rel))
        if not full.startswith(os.path.abspath(base)):
            return None
        return full

    def _body(self):
        n = int(self.headers.get("Content-Length") or 0)
        if n <= 0:
            return {}
        raw = self.rfile.read(n)
        try:
            return json.loads(raw.decode("utf-8"))
        except ValueError:
            return {}

    # ------------------------------------------------------------ routing
    def do_HEAD(self):
        self.do_GET()

    def do_GET(self):
        try:
            url = urllib.parse.urlsplit(self.path)
            path = url.path
            query = {k: v[0] for k, v in urllib.parse.parse_qs(url.query).items()}
            if path.startswith("/api/"):
                return self._api("GET", path[5:], query, {})
            if path.startswith("/audio/"):
                full = self._safe_join(AUDIO_DIR, path[7:])
                if not full:
                    return self._send(403, {"error": "forbidden"})
                return self._send_file(full, cache=True)
            if path in ("/", ""):
                path = "/index.html"
            full = self._safe_join(WEB_DIR, path)
            if not full:
                return self._send(403, {"error": "forbidden"})
            return self._send_file(full)
        except (BrokenPipeError, ConnectionResetError):
            pass
        except Exception:                      # never kill the server on a bad request
            traceback.print_exc()
            try:
                self._send(500, {"error": "server error"})
            except Exception:
                pass

    def do_POST(self):
        try:
            url = urllib.parse.urlsplit(self.path)
            if not url.path.startswith("/api/"):
                return self._send(404, {"error": "not found"})
            query = {k: v[0] for k, v in urllib.parse.parse_qs(url.query).items()}
            return self._api("POST", url.path[5:], query, self._body())
        except (BrokenPipeError, ConnectionResetError):
            pass
        except Exception:
            traceback.print_exc()
            try:
                self._send(500, {"error": "server error"})
            except Exception:
                pass

    def _api(self, method, route, query, body):
        try:
            code, payload = api.dispatch(method, route, query, body)
        except api.ApiError as e:
            code, payload = e.code, {"error": str(e)}
        except Exception as e:
            traceback.print_exc()
            code, payload = 500, {"error": "%s: %s" % (type(e).__name__, e)}
        if isinstance(payload, tuple):         # (bytes, content-type, filename) download
            data, ctype, fname = payload
            return self._send(code, data, ctype,
                              {"Content-Disposition": 'attachment; filename="%s"' % fname})
        return self._send(code, payload)


def find_port(preferred=8765, tries=20):
    import socket
    for port in range(preferred, preferred + tries):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            try:
                s.bind(("127.0.0.1", port))
                return port
            except OSError:
                continue
    raise SystemExit("No free port found between %d and %d." % (preferred, preferred + tries))


def serve(port=None, open_browser=True):
    api.init()
    port = port or find_port()
    httpd = ThreadingHTTPServer(("127.0.0.1", port), Handler)
    httpd.daemon_threads = True
    url = "http://127.0.0.1:%d/" % port
    print("")
    print("  Che!  is running at  " + url)
    print("  Leave this window open while you study.  Close it (or press Ctrl+C) to stop.")
    print("")
    sys.stdout.flush()
    if open_browser:
        import webbrowser
        threading.Timer(0.6, lambda: webbrowser.open(url)).start()
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        api.shutdown()
        httpd.server_close()
        print("Chau!")
