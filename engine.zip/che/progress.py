"""Progress storage: one real JSON file, atomic writes, rolling backups.

progress/progress.json is the learner's whole history.  Every save is written to a
temporary file first and then swapped in, so a crash can never leave half a file.
Backups: one at server start and at most one every BACKUP_EVERY seconds while the
data is changing; the newest KEEP_BACKUPS copies are kept in progress/backups/.
"""
import copy
import json
import os
import shutil
import threading
import time
from datetime import date, datetime, timedelta

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PROGRESS_DIR = os.path.join(ROOT, "progress")
PROGRESS_FILE = os.path.join(PROGRESS_DIR, "progress.json")
BACKUP_DIR = os.path.join(PROGRESS_DIR, "backups")
KEEP_BACKUPS = 10
BACKUP_EVERY = 600  # seconds

DEFAULT_SETTINGS = {
    "theme": "auto",        # auto | light | dark
    "vulgar": False,        # vulgar items are opt-in
    "audio_rate": 1.0,      # 1.0 or 0.75
    "autoplay": True,       # auto-play audio on listening exercises / after answers
    "shortcuts": True,      # a' -> á typing shortcuts
    "session_minutes": 15,
    "last_export": None,    # YYYY-MM-DD of the last Export (or Import) — drives the backup reminder
    "backup_snooze": None,  # YYYY-MM-DD: "remind me in a week" hides the reminder until this day
}


def _now():
    return datetime.now().isoformat(timespec="seconds")


def today_str():
    return date.today().isoformat()


def new_progress():
    return {
        "version": 1,
        "created": _now(),
        "updated": _now(),
        "settings": dict(DEFAULT_SETTINGS),
        "placement": {"done": False, "level": None, "date": None, "detail": {}},
        "units": {},        # unit id -> {started, completed, best, attempts, last}
        "srs": {},          # item key -> scheduling card
        "mistakes": [],     # Mistake Notebook entries
        "history": {},      # YYYY-MM-DD -> {answers, correct, seconds, sessions}
        "topic_stats": {},  # topic -> {seen, right}
        "seen_new": {},     # item key -> first-seen date (for "new material" pacing)
    }


class ProgressStore:
    def __init__(self, path=PROGRESS_FILE, backup_dir=BACKUP_DIR):
        self.path = path
        self.backup_dir = backup_dir
        self.lock = threading.RLock()
        self._last_backup = 0.0
        self._dirty_since_backup = False
        os.makedirs(os.path.dirname(self.path), exist_ok=True)
        os.makedirs(self.backup_dir, exist_ok=True)
        self.data = self._load()
        if os.path.exists(self.path):
            self.backup(force=True)

    # ---------- loading ----------
    def _load(self):
        if not os.path.exists(self.path):
            data = new_progress()
            self._write(data)
            return data
        try:
            with open(self.path, "r", encoding="utf-8") as f:
                data = json.load(f)
        except (ValueError, OSError):
            # Corrupt file: keep it aside, restore the newest good backup if any.
            bad = self.path + ".corrupt-" + datetime.now().strftime("%Y%m%d-%H%M%S")
            try:
                shutil.copy2(self.path, bad)
            except OSError:
                pass
            data = self._restore_latest_backup() or new_progress()
        return self._upgrade(data)

    def _restore_latest_backup(self):
        for name in sorted(os.listdir(self.backup_dir), reverse=True):
            try:
                with open(os.path.join(self.backup_dir, name), "r", encoding="utf-8") as f:
                    return json.load(f)
            except (ValueError, OSError):
                continue
        return None

    @staticmethod
    def _upgrade(data):
        base = new_progress()
        for k, v in base.items():
            if k not in data:
                data[k] = v
        for k, v in DEFAULT_SETTINGS.items():
            data["settings"].setdefault(k, v)
        return data

    # ---------- saving ----------
    def _write(self, data):
        tmp = self.path + ".tmp"
        text = json.dumps(data, ensure_ascii=False, indent=1)
        with open(tmp, "w", encoding="utf-8") as f:
            f.write(text)
            f.flush()
            try:
                os.fsync(f.fileno())
            except OSError:
                pass
        # OneDrive / antivirus can briefly lock the target: retry a few times.
        for attempt in range(8):
            try:
                os.replace(tmp, self.path)
                return
            except PermissionError:
                time.sleep(0.15 * (attempt + 1))
        # last resort: plain overwrite
        with open(self.path, "w", encoding="utf-8") as f:
            f.write(text)

    def save(self):
        with self.lock:
            self.data["updated"] = _now()
            self._write(self.data)
            self._dirty_since_backup = True
            if time.time() - self._last_backup > BACKUP_EVERY:
                self.backup()

    def backup(self, force=False):
        with self.lock:
            if not force and not self._dirty_since_backup:
                return None
            if not os.path.exists(self.path):
                return None
            stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
            dest = os.path.join(self.backup_dir, "progress-%s.json" % stamp)
            try:
                shutil.copy2(self.path, dest)
            except OSError:
                return None
            self._last_backup = time.time()
            self._dirty_since_backup = False
            names = sorted(n for n in os.listdir(self.backup_dir) if n.startswith("progress-"))
            for old in names[:-KEEP_BACKUPS]:
                try:
                    os.remove(os.path.join(self.backup_dir, old))
                except OSError:
                    pass
            return dest

    # ---------- export / import ----------
    def export(self):
        with self.lock:
            return copy.deepcopy(self.data)

    def import_data(self, data):
        if not isinstance(data, dict) or "srs" not in data or "version" not in data:
            raise ValueError("This does not look like a Che! progress file.")
        with self.lock:
            self.backup(force=True)
            self.data = self._upgrade(data)
            self.save()

    def reset(self):
        with self.lock:
            self.backup(force=True)
            settings = self.data.get("settings", dict(DEFAULT_SETTINGS))
            self.data = new_progress()
            self.data["settings"] = settings
            self.save()

    # ---------- small helpers used across the app ----------
    def log_answer(self, correct, seconds=0.0, topic=None):
        with self.lock:
            day = self.data["history"].setdefault(
                today_str(), {"answers": 0, "correct": 0, "seconds": 0, "sessions": 0})
            day["answers"] += 1
            day["correct"] += 1 if correct else 0
            day["seconds"] = round(day.get("seconds", 0) + min(float(seconds or 0), 120.0), 1)
            if topic:
                ts = self.data["topic_stats"].setdefault(topic, {"seen": 0, "right": 0})
                ts["seen"] += 1
                ts["right"] += 1 if correct else 0

    def log_session(self):
        with self.lock:
            day = self.data["history"].setdefault(
                today_str(), {"answers": 0, "correct": 0, "seconds": 0, "sessions": 0})
            day["sessions"] = day.get("sessions", 0) + 1

    def streak(self):
        """Consecutive days (ending today or yesterday) with at least 5 answers."""
        hist = self.data.get("history", {})

        def active(d):
            return hist.get(d.isoformat(), {}).get("answers", 0) >= 5

        d = date.today()
        if not active(d):
            d = d - timedelta(days=1)
        n = 0
        while active(d):
            n += 1
            d = d - timedelta(days=1)
        return n
