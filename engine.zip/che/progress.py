"""Progress storage: one real JSON file, atomic writes, rolling backups.

progress/progress.json is the learner's whole history.  Every save is written to a
temporary file first and then swapped in, so a crash can never leave half a file.
Backups (progress/backups/): ONE PER DAY — the day's copy is refreshed at start and at most every
BACKUP_EVERY seconds while the data is changing, and the copies of the last KEEP_BACKUPS days are kept
(opening the app ten times in one day used to push out every older copy).  Before an Import, a Restore or
"Start over" a separate "before-…" copy is made; the last KEEP_SPECIAL of those are kept.
"""
import copy
import json
import os
import shutil
import threading
import time
from datetime import date, datetime, timedelta

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SHARED_NAME = "Che Spanish progress"


def _documents_dir():
    """The user's real Documents folder (on Windows it may have been moved, e.g. into OneDrive)."""
    try:
        import winreg
        key = winreg.OpenKey(winreg.HKEY_CURRENT_USER,
                             r"Software\Microsoft\Windows\CurrentVersion\Explorer\User Shell Folders")
        path = os.path.expandvars(winreg.QueryValueEx(key, "Personal")[0])
        if os.path.isdir(path):
            return path
    except Exception:
        pass
    docs = os.path.join(os.path.expanduser("~"), "Documents")
    return docs if os.path.isdir(docs) else os.path.expanduser("~")


def progress_dir(root=ROOT):
    """Where the progress lives.  The builder's own copy: <app>/progress.  A friend's zip copy (release.json next to
    run.py): Documents/Che Spanish progress — outside the app folder, so a newer zip unzipped anywhere finds the same
    progress.  The first start of such a copy adopts a progress/ folder copied into it from an older version (it never
    overwrites progress that is already there)."""
    local = os.path.join(root, "progress")
    if not os.path.exists(os.path.join(root, "release.json")):
        return local
    shared = os.path.join(_documents_dir(), SHARED_NAME)
    try:
        os.makedirs(shared, exist_ok=True)
        src, dst = os.path.join(local, "progress.json"), os.path.join(shared, "progress.json")
        if os.path.exists(src) and not os.path.exists(dst):
            shutil.copy2(src, dst)
        return shared
    except OSError:
        return local


PROGRESS_DIR = progress_dir()
PROGRESS_FILE = os.path.join(PROGRESS_DIR, "progress.json")
BACKUP_DIR = os.path.join(PROGRESS_DIR, "backups")
KEEP_BACKUPS = 10   # days
KEEP_SPECIAL = 5    # "before-import / before-restore / before-reset" copies
BACKUP_EVERY = 600  # seconds

DEFAULT_SETTINGS = {
    "theme": "auto",        # auto | light | dark
    "vulgar": False,        # vulgar items are opt-in
    "audio_rate": 1.0,      # 1.0 or 0.75
    "autoplay": True,       # auto-play audio on listening exercises / after answers
    "shortcuts": True,      # a' -> á typing shortcuts
    "session_minutes": 15,
    "last_export": None,    # YYYY-MM-DD of the last Export (or Import) — drives the backup reminder
    "backup_snooze": None,  # YYYY-MM-DD: "remind me in a week" hides the reminder until this day
}


def _now():
    return datetime.now().isoformat(timespec="seconds")


def today_str():
    return date.today().isoformat()


def new_progress():
    return {
        "version": 1,
        "created": _now(),
        "updated": _now(),
        "settings": dict(DEFAULT_SETTINGS),
        "placement": {"done": False, "level": None, "date": None, "detail": {}},
        "units": {},        # unit id -> {started, completed, best, attempts, last}
        "srs": {},          # item key -> scheduling card
        "mistakes": [],     # Mistake Notebook entries
        "history": {},      # YYYY-MM-DD -> {answers, correct, seconds, sessions}
        "topic_stats": {},  # topic -> {seen, right}
        "seen_new": {},     # item key -> first-seen date (new words per day)
        "accepted": {},     # exercise id -> answers the learner marked "I was right" (accepted from then on)
        "reports": [],      # problems the learner reported from the feedback card (for `fix:`)
    }


class ProgressStore:
    def __init__(self, path=PROGRESS_FILE, backup_dir=BACKUP_DIR):
        self.path = path
        self.backup_dir = backup_dir
        self.lock = threading.RLock()
        self._last_backup = 0.0
        self._dirty_since_backup = False
        self.revision = 0                # +1 on every save (the phone version writes storage when it changes)
        os.makedirs(os.path.dirname(self.path), exist_ok=True)
        os.makedirs(self.backup_dir, exist_ok=True)
        self.data = self._load()
        if os.path.exists(self.path):
            self.backup(force=True)

    # ---------- loading ----------
    def _load(self):
        if not os.path.exists(self.path):
            data = new_progress()
            self._write(data)
            return data
        try:
            with open(self.path, "r", encoding="utf-8") as f:
                data = json.load(f)
            if not isinstance(data, dict):
                raise ValueError("not a progress object")
        except (ValueError, OSError):
            # Corrupt file: keep it aside, restore the newest good backup if any — and write that back at once,
            # so the next backup copies good data (not the broken file, which would push out good copies).
            bad = self.path + ".corrupt-" + datetime.now().strftime("%Y%m%d-%H%M%S")
            try:
                shutil.copy2(self.path, bad)
            except OSError:
                pass
            data = self._upgrade(self._restore_latest_backup() or new_progress())
            self._write(data)
        return self._upgrade(data)

    def _restore_latest_backup(self):
        for name in sorted(self._backup_names(), reverse=True):
            try:
                with open(os.path.join(self.backup_dir, name), "r", encoding="utf-8") as f:
                    data = json.load(f)
                if isinstance(data, dict):
                    return data
            except (ValueError, OSError):
                continue
        return None

    @staticmethod
    def _upgrade(data):
        """Fill in anything an older (or damaged) file lacks — with the right types."""
        base = new_progress()
        for k, v in base.items():
            if k not in data or (v is not None and not isinstance(data[k], type(v))):
                data[k] = v
        for k, v in DEFAULT_SETTINGS.items():
            data["settings"].setdefault(k, v)
        data["srs"] = {k: c for k, c in data["srs"].items() if isinstance(c, dict)}
        data["mistakes"] = [m for m in data["mistakes"] if isinstance(m, dict) and m.get("key")]
        return data

    # ---------- saving ----------
    def _write(self, data):
        tmp = self.path + ".tmp"
        text = json.dumps(data, ensure_ascii=False, indent=1)
        with open(tmp, "w", encoding="utf-8") as f:
            f.write(text)
            f.flush()
            try:
                os.fsync(f.fileno())
            except OSError:
                pass
        # OneDrive / antivirus can briefly lock the target: retry a few times.
        for attempt in range(8):
            try:
                os.replace(tmp, self.path)
                return
            except PermissionError:
                time.sleep(0.15 * (attempt + 1))
        # last resort: plain overwrite
        with open(self.path, "w", encoding="utf-8") as f:
            f.write(text)

    def save(self):
        with self.lock:
            self.data["updated"] = _now()
            self._write(self.data)
            self.revision += 1
            self._dirty_since_backup = True
            if time.time() - self._last_backup > BACKUP_EVERY:
                self.backup()

    def _backup_names(self):
        try:
            return [n for n in os.listdir(self.backup_dir) if n.startswith("progress-") and n.endswith(".json")]
        except OSError:
            return []

    def backup(self, force=False, label=None):
        """The day's copy (progress-YYYYMMDD-HHMMSS.json, one kept per day), or — with a label — an extra copy
        that is kept apart (progress-YYYYMMDD-HHMMSS-before-import.json)."""
        with self.lock:
            if not force and not self._dirty_since_backup:
                return None
            if not os.path.exists(self.path):
                return None
            stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
            dest = os.path.join(self.backup_dir, "progress-%s%s.json" % (stamp, "-" + label if label else ""))
            try:
                shutil.copy2(self.path, dest)
            except OSError:
                return None
            self._last_backup = time.time()
            self._dirty_since_backup = False
            self._prune()
            return dest

    def _prune(self):
        names = sorted(self._backup_names())
        special = [n for n in names if "-before-" in n]
        daily = {}
        for n in names:                                   # the newest copy of each day
            if "-before-" not in n:
                daily[n[9:17]] = n
        keep = set(special[-KEEP_SPECIAL:]) | set(sorted(daily.values())[-KEEP_BACKUPS:])
        for old in names:
            if old not in keep:
                try:
                    os.remove(os.path.join(self.backup_dir, old))
                except OSError:
                    pass

    def list_backups(self):
        """[{name, when, label, answers, cards, chapters}] newest first — Settings → Earlier copies."""
        out = []
        for n in sorted(self._backup_names(), reverse=True):
            try:
                with open(os.path.join(self.backup_dir, n), "r", encoding="utf-8") as f:
                    d = json.load(f)
            except (ValueError, OSError):
                continue
            if not isinstance(d, dict):
                continue
            when = "%s-%s-%s %s:%s" % (n[9:13], n[13:15], n[15:17], n[18:20], n[20:22])
            label = n[25:-5].replace("-", " ") if "-before-" in n else ""
            out.append({"name": n, "when": when, "label": label,
                        "answers": sum(h.get("answers", 0) for h in (d.get("history") or {}).values()
                                       if isinstance(h, dict)),
                        "cards": len(d.get("srs") or {}),
                        "chapters": sum(1 for u in (d.get("units") or {}).values()
                                        if isinstance(u, dict) and u.get("completed"))})
        return out

    def restore(self, name):
        """Go back to an earlier copy (the current progress is kept first as a "before-restore" copy)."""
        if name not in self._backup_names():
            raise ValueError("No such copy.")
        with open(os.path.join(self.backup_dir, name), "r", encoding="utf-8") as f:
            data = json.load(f)
        self.import_data(data, label="before-restore")

    # ---------- export / import ----------
    def export(self):
        with self.lock:
            return copy.deepcopy(self.data)

    def import_data(self, data, label="before-import"):
        if not isinstance(data, dict) or not isinstance(data.get("srs"), dict) or "version" not in data:
            raise ValueError("This does not look like a Che! progress file.")
        if not isinstance(data.get("settings", {}), dict):
            data["settings"] = {}
        with self.lock:
            self.backup(force=True, label=label)
            self.data = self._upgrade(copy.deepcopy(data))
            self.save()

    def reset(self):
        with self.lock:
            self.backup(force=True, label="before-reset")
            settings = self.data.get("settings", dict(DEFAULT_SETTINGS))
            self.data = new_progress()
            self.data["settings"] = settings
            self.save()

    # ---------- small helpers used across the app ----------
    def log_answer(self, correct, seconds=0.0, topic=None):
        with self.lock:
            day = self.data["history"].setdefault(
                today_str(), {"answers": 0, "correct": 0, "seconds": 0, "sessions": 0})
            day["answers"] += 1
            day["correct"] += 1 if correct else 0
            day["seconds"] = round(day.get("seconds", 0) + min(float(seconds or 0), 120.0), 1)
            if topic:
                ts = self.data["topic_stats"].setdefault(topic, {"seen": 0, "right": 0})
                ts["seen"] += 1
                ts["right"] += 1 if correct else 0

    def log_session(self):
        with self.lock:
            day = self.data["history"].setdefault(
                today_str(), {"answers": 0, "correct": 0, "seconds": 0, "sessions": 0})
            day["sessions"] = day.get("sessions", 0) + 1

    def streak(self):
        """Consecutive days (ending today or yesterday) with at least 5 answers."""
        hist = self.data.get("history", {})

        def active(d):
            return hist.get(d.isoformat(), {}).get("answers", 0) >= 5

        d = date.today()
        if not active(d):
            d = d - timedelta(days=1)
        n = 0
        while active(d):
            n += 1
            d = d - timedelta(days=1)
        return n
