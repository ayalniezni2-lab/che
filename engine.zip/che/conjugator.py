"""Conjugation engine — Argentine layout.  SINGLE SOURCE OF TRUTH for drills and diagnosis.

Persons, always and only:  yo / vos / él-ella-usted / nosotros / ustedes / ellos-ellas.
There is no tú row and no vosotros row.  (tú / vosotros forms are computed further down
ONLY so that mistakes can be recognised and content can be checked; they are never shown.)

Regular verbs come from rules (with automatic spelling changes).  Irregular verbs are
described in content/verbs/irregular.json: explicit cells, special stems, or "like" another verb.
"""
from .spanish import strip_acute, put_stress, nuclei, attach, with_prefix, diff_parts, fold

PERSONS = ["yo", "vos", "el", "nos", "uds", "ellos"]
PERSON_LABEL = {"yo": "yo", "vos": "vos", "el": "él / ella / usted", "nos": "nosotros",
                "uds": "ustedes", "ellos": "ellos / ellas"}
REFLEXIVE = {"yo": "me", "vos": "te", "el": "se", "nos": "nos", "uds": "se", "ellos": "se"}
SIMPLE = ["pres", "pret", "impf", "fut", "cond", "subj", "subjp"]
COMPOUND = ["iraf", "prog", "perf", "plup"]
ALL_TENSES = SIMPLE + COMPOUND + ["imp", "impneg"]
IMP_PERSONS = ["vos", "el", "uds"]          # vos / usted / ustedes

_E5 = ["yo", "vos", "el", "nos", "uds"]
END = {
    "pres": {"ar": ["o", "ás", "a", "amos", "an"], "er": ["o", "és", "e", "emos", "en"],
             "ir": ["o", "ís", "e", "imos", "en"]},
    "pret": {"ar": ["é", "aste", "ó", "amos", "aron"], "er": ["í", "iste", "ió", "imos", "ieron"],
             "ir": ["í", "iste", "ió", "imos", "ieron"]},
    "impf": {"ar": ["aba", "abas", "aba", "ábamos", "aban"], "er": ["ía", "ías", "ía", "íamos", "ían"],
             "ir": ["ía", "ías", "ía", "íamos", "ían"]},
    "subj": {"ar": ["e", "es", "e", "emos", "en"], "er": ["a", "as", "a", "amos", "an"],
             "ir": ["a", "as", "a", "amos", "an"]},
}
FUT = ["é", "ás", "á", "emos", "án"]
COND = ["ía", "ías", "ía", "íamos", "ían"]
STRONG_PRET = ["e", "iste", "o", "imos", "ieron"]
HABER_PRES = {"yo": "he", "vos": "has", "el": "ha", "nos": "hemos", "uds": "han", "ellos": "han"}
HABER_IMPF = {"yo": "había", "vos": "habías", "el": "había", "nos": "habíamos", "uds": "habían",
              "ellos": "habían"}
IR_PRES = {"yo": "voy", "vos": "vas", "el": "va", "nos": "vamos", "uds": "van", "ellos": "van"}
ESTAR_PRES = {"yo": "estoy", "vos": "estás", "el": "está", "nos": "estamos", "uds": "están",
              "ellos": "están"}


class ConjugationError(Exception):
    pass


def split_inf(inf):
    """'levantarse' -> ('levantar', True);  'reír' keeps its accent in the base."""
    refl = inf.endswith("se") and len(inf) >= 4 and inf[-4:-2] in ("ar", "er", "ir", "ír")
    return (inf[:-2], True) if refl else (inf, False)


def _group(base):
    return "ir" if base.endswith("ír") else base[-2:]


def _stem(base):
    return base[:-2]


def _mono(form):
    """Monosyllables carry no written accent (das, ves, vio, di) unless given explicitly."""
    return strip_acute(form) if len(nuclei(form)) <= 1 else form


def _apply_sc(stem, sc):
    if not sc:
        return stem
    src, dst = sc.split(">")
    i = stem.rfind(src)
    if i < 0:
        return stem
    if dst == "hue":
        return stem[:i] + "hue" + stem[i + 1:]
    return stem[:i] + dst + stem[i + len(src):]


def _weak_sc(stem, sc):
    """-ir verbs: e->i / o->u in some forms (pidió, durmiendo, sintamos)."""
    if sc in ("e>ie", "e>i"):
        return _apply_sc(stem, "e>i")
    if sc == "o>ue":
        return _apply_sc(stem, "o>u")
    return stem


def _vowel_stem(stem):
    return bool(stem) and not stem.endswith(("gu", "qu")) and stem[-1] in "aeou"


def _join(stem, ending, group, zc=False, ortho=True):
    if not ortho or not ending:
        return stem + ending
    first = strip_acute(ending[0])
    if group == "ar" and first in "ei":
        if stem.endswith("gu"):
            stem = stem[:-2] + "gü"
        elif stem.endswith("c"):
            stem = stem[:-1] + "qu"
        elif stem.endswith("g"):
            stem = stem[:-1] + "gu"
        elif stem.endswith("z"):
            stem = stem[:-1] + "c"
    elif group in ("er", "ir") and first in "ao":
        if stem.endswith("gu"):
            stem = stem[:-1]
        elif stem.endswith("qu"):
            stem = stem[:-2] + "c"
        elif stem.endswith("g"):
            stem = stem[:-1] + "j"
        elif stem.endswith("c"):
            stem = stem[:-1] + ("zc" if zc else "z")
    return stem + ending


class Engine:
    def __init__(self, verbs, irregular):
        """verbs: {inf: entry} from verbs.json; irregular: content of irregular.json."""
        self.verbs = verbs or {}
        irregular = irregular or {}
        self.irr = irregular.get("verbs", irregular)
        self.families = irregular.get("families", {})
        self._cache = {}

    # ------------------------------------------------------------------ public
    def info(self, inf):
        base, refl = split_inf(inf)
        spec = dict(self.verbs.get(inf) or self.verbs.get(base) or {})
        spec.update(self.irr.get(base, {}))
        model = spec.get("like")
        if model:                                   # mantener behaves like tener: same families and stems
            for k, v in dict(self.irr.get(model, {})).items():
                if k in ("family", "sc", "zc", "pret_stem", "fut_stem", "yo") and k not in spec:
                    spec[k] = v
        return base, refl, spec

    def conjugate(self, inf):
        """-> {'inf','base','reflexive', tense: {person: form}, 'ger','pp','imp','impneg'}"""
        if inf in self._cache:
            return self._cache[inf]
        base, refl, spec = self.info(inf)
        t = self._build(base, spec)
        t = self._with_compounds(base, t)
        if refl:
            t = self._reflexive(t)
        t["inf"], t["base"], t["reflexive"] = inf, base, refl
        self._cache[inf] = t
        return t

    def form(self, inf, tense, person=None):
        t = self.conjugate(inf)
        if tense in ("ger", "pp"):
            return t[tense]
        return t[tense][person]

    def regularized(self, inf):
        """What the verb would look like with no irregularities at all (for diagnosis/highlighting)."""
        key = "~" + inf
        if key not in self._cache:
            base, refl, _ = self.info(inf)
            t = self._with_compounds(base, self._build(base, {}, ortho=False))
            if refl:
                t = self._reflexive(t)
            self._cache[key] = t
        return self._cache[key]

    def is_irregular(self, inf, tense, person=None):
        a, r = self.conjugate(inf), self.regularized(inf)
        if tense in ("ger", "pp"):
            return a[tense] != r[tense]
        return a[tense].get(person) != r[tense].get(person)

    def parts(self, inf, tense, person=None):
        """[(text, is_irregular)] for colouring the irregular part of a form."""
        a, r = self.conjugate(inf), self.regularized(inf)
        if tense in ("ger", "pp"):
            return diff_parts(a[tense], r[tense])
        af, rf = a[tense][person], r[tense].get(person, "")
        if " " in af and af.count(" ") == rf.count(" "):
            out = []
            for aw, rw in zip(af.split(" "), rf.split(" ")):
                if out:
                    out.append((" ", False))
                out.extend(diff_parts(aw, rw))
            return out
        return diff_parts(af, rf)

    def all_forms(self, inf, compounds=False):
        """[(form, tense, person)] — every cell of every table for this verb."""
        t = self.conjugate(inf)
        out = []
        for tense in SIMPLE + (COMPOUND if compounds else []):
            for p in PERSONS:
                out.append((t[tense][p], tense, p))
        for p in IMP_PERSONS:
            out.append((t["imp"][p], "imp", p))
            out.append((t["impneg"][p], "impneg", p))
        out.append((t["ger"], "ger", None))
        out.append((t["pp"], "pp", None))
        return out

    def tip(self, inf, tense):
        """One-line memory tip for this verb + tense: explicit tip > explicit family > inferred."""
        base, _, spec = self.info(inf)
        if spec.get("like"):
            model = dict(self.verbs.get(spec["like"], {}))
            model.update(self.irr.get(spec["like"], {}))
            for k in ("tip", "family", "sc", "pret_stem", "fut_stem", "zc", "yo"):
                if k in model and k not in spec:
                    spec[k] = model[k]
            note = "%s is %s + %s, so it copies %s exactly. " % (
                base, spec.get("prefix") or base[:len(base) - len(spec["like"])], spec["like"], spec["like"])
        else:
            note = ""
        tips = spec.get("tip") or {}
        if isinstance(tips, str):
            return note + tips
        if tense in tips:
            return note + tips[tense]
        fam = spec.get("family")
        fam = fam.get(tense) if isinstance(fam, dict) else fam
        if not fam:
            fam = self._infer_family(base, spec, tense)
        if fam and fam in self.families:
            f = self.families[fam]
            if not f.get("tenses") or tense in f["tenses"] or fam == "spelling":
                return note + f.get("tip", "")
        return note.strip() or None

    def _infer_family(self, base, spec, tense):
        g, stem = _group(base), _stem(base)
        sc = spec.get("sc")
        if tense in ("pres", "subj", "imp", "impneg"):
            if sc:
                return "sc_boot"
            if spec.get("zc"):
                return "zc"
            if spec.get("yo", "").endswith("go"):
                return "go_yo"
        if tense in ("pret", "subjp"):
            ps = spec.get("pret_stem")
            if ps:
                return "j_pret" if ps.endswith("j") else "strong_pret"
            if g == "ir" and sc in ("e>ie", "e>i", "o>ue"):
                return "ir_weak"
            if g in ("er", "ir") and _vowel_stem(stem):
                return "y_vowel"
        if tense in ("fut", "cond") and spec.get("fut_stem"):
            return "fut_stem"
        if tense == "ger":
            if g == "ir" and sc in ("e>ie", "e>i", "o>ue"):
                return "ir_weak"
            if g in ("er", "ir") and _vowel_stem(stem):
                return "y_vowel"
        if tense in ("pres", "pret", "subj", "imp", "impneg"):
            if (g == "ar" and stem.endswith(("c", "g", "z"))) or                (g in ("er", "ir") and stem.endswith(("g", "gu", "c"))):
                return "spelling"
        return None

    # ------------------------------------------------------------------ building
    def _build(self, base, spec, ortho=True):
        if spec.get("like"):
            return self._build_like(base, spec)
        g, stem = _group(base), _stem(base)
        sc = spec.get("sc")
        zc = bool(spec.get("zc"))
        t = {}

        # ---- present
        sc_stem = _apply_sc(stem, sc)
        if spec.get("shift") and stem[-1] in "iu":
            sc_stem = stem[:-1] + {"i": "í", "u": "ú"}[stem[-1]]
        uir = ortho and g == "ir" and stem.endswith("u") and _vowel_stem(stem)
        pres = {}
        for p, e in zip(_E5, END["pres"][g]):
            s = stem if p in ("vos", "nos") else sc_stem
            if uir and strip_acute(e[0]) in "aeo":
                s = s + "y"
            pres[p] = _join(s, e, g, zc, ortho)
        pres["vos"] = _mono(pres["vos"])
        if spec.get("yo"):
            pres["yo"] = spec["yo"]
        pres.update(spec.get("pres", {}))
        pres["ellos"] = pres["uds"]
        t["pres"] = pres

        # ---- preterite
        pret = {}
        ps = spec.get("pret_stem")
        if ps:
            for p, e in zip(_E5, STRONG_PRET):
                if ps.endswith("j") and e == "ieron":
                    e = "eron"
                s = ps[:-1] + "z" if (ps.endswith("c") and e == "o") else ps
                pret[p] = s + e
        else:
            weak = _weak_sc(stem, sc) if g == "ir" else stem
            vs = ortho and g in ("er", "ir") and _vowel_stem(stem)
            for p, e in zip(_E5, END["pret"][g]):
                s = weak if p in ("el", "uds") else stem
                if vs:
                    if e == "ió":
                        e = "yó"
                    elif e == "ieron":
                        e = "yeron"
                    elif stem[-1] in "aeo" and e in ("iste", "imos"):
                        e = "í" + e[1:]
                elif ortho and s.endswith(("ñ", "ll")) and e in ("ió", "ieron"):
                    e = e[1:]
                pret[p] = _join(s, e, g, zc, ortho)
        pret.update(spec.get("pret", {}))
        pret["ellos"] = pret["uds"]
        t["pret"] = pret

        # ---- "used to" past
        impf = {p: stem + e for p, e in zip(_E5, END["impf"][g])}
        impf.update(spec.get("impf", {}))
        impf["ellos"] = impf["uds"]
        t["impf"] = impf

        # ---- simple future / would
        fs = spec.get("fut_stem") or strip_acute(base)
        t["fut"] = {p: fs + e for p, e in zip(_E5, FUT)}
        t["fut"].update(spec.get("fut", {}))
        t["fut"]["ellos"] = t["fut"]["uds"]
        t["cond"] = {p: fs + e for p, e in zip(_E5, COND)}
        t["cond"].update(spec.get("cond", {}))
        t["cond"]["ellos"] = t["cond"]["uds"]

        # ---- "wishes / not sure" shape (present)
        subj = {}
        yo = pres["yo"]
        if yo.endswith("o") and not yo.endswith("oy"):
            y = "y" if uir else ""
            if yo == _join(sc_stem + y, "o", g, zc, ortho):
                # yo follows the rules: pienso -> piense … pensemos; pido -> pida … pidamos
                nos_stem = (_weak_sc(stem, sc) if g == "ir" else stem) + y
                for p, e in zip(_E5, END["subj"][g]):
                    subj[p] = _join(nos_stem if p == "nos" else sc_stem + y, e, g, zc, ortho)
            else:
                # irregular yo: tengo -> tenga … tengamos; hago -> haga; digo -> diga
                for p, e in zip(_E5, END["subj"][g]):
                    subj[p] = yo[:-1] + e
        subj.update(spec.get("subj", {}))
        if len([p for p in _E5 if p in subj]) < 5:
            raise ConjugationError("%s: the present 'wishes' forms need explicit cells" % base)
        subj["ellos"] = subj["uds"]
        t["subj"] = subj

        # ---- "wishes / not sure" shape (past), built from the ellos past form
        ell = pret["uds"]
        if not ell.endswith("ron"):
            raise ConjugationError("%s: odd ellos past form %r" % (base, ell))
        root = ell[:-3]
        subjp = {}
        for p, e in zip(_E5, ["ra", "ras", "ra", "ramos", "ran"]):
            f = root + e
            if p == "nos":
                f = put_stress(f, len(nuclei(root)) - 1)
            subjp[p] = f
        subjp.update(spec.get("subjp", {}))
        subjp["ellos"] = subjp["uds"]
        t["subjp"] = subjp

        # ---- -ndo form and participle
        if spec.get("ger"):
            t["ger"] = spec["ger"]
        elif g == "ar":
            t["ger"] = stem + "ando"
        else:
            s = _weak_sc(stem, sc) if g == "ir" else stem
            if ortho and _vowel_stem(s):
                t["ger"] = s + "yendo"
            elif ortho and s.endswith(("ñ", "ll")):
                t["ger"] = s + "endo"
            else:
                t["ger"] = s + "iendo"
        if spec.get("pp"):
            t["pp"] = spec["pp"]
        elif g == "ar":
            t["pp"] = stem + "ado"
        else:
            t["pp"] = stem + ("ído" if (ortho and stem and stem[-1] in "aeo") else "ido")

        # ---- commands
        vos_imp = base[:-1]
        vos_imp = put_stress(vos_imp, len(nuclei(vos_imp)) - 1)
        imp = {"vos": vos_imp, "el": subj["el"], "uds": subj["uds"], "nos": subj["nos"]}
        imp.update(spec.get("imp", {}))
        t["imp"] = imp
        t["impneg"] = {"vos": "no " + subj["vos"], "el": "no " + subj["el"],
                       "uds": "no " + subj["uds"], "nos": "no " + subj["nos"]}
        return t

    def _build_like(self, base, spec):
        model = spec["like"]
        prefix = spec.get("prefix")
        if prefix is None:
            if not base.endswith(strip_acute(model)) and not base.endswith(model):
                raise ConjugationError("%s: cannot derive prefix from %s" % (base, model))
            prefix = base[:len(base) - len(model)]
        mspec = dict(self.verbs.get(model, {}))
        mspec.update(self.irr.get(model, {}))
        src = self._build(model, mspec)
        t = {}
        for k, v in src.items():
            if isinstance(v, dict):
                t[k] = {}
                for p, f in v.items():
                    if k == "impneg":
                        t[k][p] = "no " + with_prefix(prefix, f[3:])
                    else:
                        t[k][p] = with_prefix(prefix, f)
            else:
                t[k] = with_prefix(prefix, v)
        for k in ("pres", "pret", "impf", "fut", "cond", "subj", "subjp", "imp"):
            if k in spec:
                t[k].update(spec[k])
        for k in ("ger", "pp"):
            if k in spec:
                t[k] = spec[k]
        return t

    @staticmethod
    def _with_compounds(base, t):
        inf = base
        t = dict(t)
        t["iraf"] = {p: "%s a %s" % (IR_PRES[p], inf) for p in PERSONS}
        t["prog"] = {p: "%s %s" % (ESTAR_PRES[p], t["ger"]) for p in PERSONS}
        t["perf"] = {p: "%s %s" % (HABER_PRES[p], t["pp"]) for p in PERSONS}
        t["plup"] = {p: "%s %s" % (HABER_IMPF[p], t["pp"]) for p in PERSONS}
        return t

    @staticmethod
    def _reflexive(t):
        out = {}
        for k, v in t.items():
            if k in SIMPLE or k in ("perf", "plup", "prog", "iraf"):
                out[k] = {p: REFLEXIVE[p] + " " + f for p, f in v.items()}
            elif k == "imp":
                out[k] = {p: attach(f, {"vos": "te", "el": "se", "uds": "se", "nos": "nos"}[p])
                          for p, f in v.items() if p != "nos"}
                nos = v.get("nos", "")
                out[k]["nos"] = attach(nos[:-1], "nos") if nos.endswith("s") else nos
            elif k == "impneg":
                out[k] = {p: "no " + {"vos": "te", "el": "se", "uds": "se", "nos": "nos"}[p] + " " + f[3:]
                          for p, f in v.items()}
            elif k == "ger":
                out[k] = attach(v, "se")
            else:
                out[k] = v
        return out

    # ------------------------------------------------------------------ detection-only forms
    def tu_forms(self, inf):
        """Forms used with tú (Spain/Mexico) that DIFFER from the vos forms.  Detection only."""
        base, refl, spec = self.info(inf)
        if spec.get("like"):
            prefix = spec.get("prefix")
            if prefix is None:
                prefix = base[:len(base) - len(spec["like"])]
            src = self.tu_forms(spec["like"])
            return {k: with_prefix(prefix, v) for k, v in src.items()}
        t = self.conjugate(base)
        g, stem = _group(base), _stem(base)
        out = {}
        special = spec.get("tu") or {}
        pres_tu = special.get("pres")
        if not pres_tu:
            el = t["pres"]["el"]
            pres_tu = el + "s" if not el.endswith("s") else el
        if pres_tu != t["pres"]["vos"]:
            out["pres"] = pres_tu
        imp_tu = special.get("imp") or t["pres"]["el"]
        if imp_tu != t["imp"]["vos"]:
            out["imp"] = imp_tu
        return out

    def vosotros_forms(self, inf):
        """vosotros forms (Spain).  Detection only — never displayed."""
        base, refl, spec = self.info(inf)
        t = self.conjugate(base)
        g = _group(base)
        out = {}
        special = spec.get("vosotros") or {}
        stem = _stem(base)
        pres = special.get("pres") or _mono(stem + {"ar": "áis", "er": "éis", "ir": "ís"}[g])
        out["pres"] = pres
        out["pret"] = t["pret"]["vos"] + "is"
        body = t["impf"]["nos"][:-3]          # hablába / comía / éra / íba
        out["impf"] = (body if body.endswith("ía") else strip_acute(body)) + "is"
        out["fut"] = t["fut"]["yo"][:-1] + "éis"
        out["cond"] = t["cond"]["yo"] + "is"
        sn = t["subj"]["nos"]
        out["subj"] = _mono(sn[:-4] + ("éis" if sn.endswith("emos") else "áis"))
        out["subjp"] = strip_acute(t["subjp"]["nos"][:-3]) + "is"
        out["imp"] = special.get("imp") or strip_acute(base[:-1]) + "d"
        return out
