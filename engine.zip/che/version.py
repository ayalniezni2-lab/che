"""The app version, shown small at the bottom of the home screen.

Bump MINOR for new features or content, PATCH for fixes, and add a line to CHANGES (newest first).
"""
VERSION = "1.14.1"

CHANGES = [
    ("1.14.1", "2026-11-06", "Fix: a name at the start of a sentence (Lucas y yo…) no longer shows up under “New words” "
                             "as a word to learn (Lucas was shown as la luca)."),
    ("1.14.0", "2026-11-04", "🔇 Can't listen now: a listening question can be skipped without counting as a "
                             "mistake, and quiet mode skips all listening for the rest of the day (no sound plays by "
                             "itself; listen-first readings show their text). Settings and the home screen turn it off."),
    ("1.13.0", "2026-11-04", "3 new extra chapters for the less common forms: regrets and “should have” "
                             "(tendrías que haberme avisado, me hubiera gustado), understanding the news (fue "
                             "detenido, resultaron heridos), feelings with the done form (harto de, acostumbrado a)."),
    ("1.12.0", "2026-11-04", "3 new extra chapters for the simple future: notices, forecasts and messages (se "
                             "cortará el agua, habrá tormentas), the future that admits a point (será caro, pero…; "
                             "¿será posible?), encouraging and promising (¡te va a ir bárbaro!, sin falta)."),
    ("1.11.0", "2026-11-04", "3 new extra chapters for the “would” form: what would be nice or useful (estaría "
                             "bueno, me vendría bien), suggesting what to do (habría que, podríamos, ¿y si…?), "
                             "answering invitations (me encantaría, pero…; te confirmo)."),
    ("1.10.0", "2026-11-04", "3 new extra chapters for the “wishes / not sure” form: looking for something unknown "
                             "(busco un depto que tenga balcón), just in case / unless / as long as (por si llueve, "
                             "salvo que llueva), saying it gently (no es que no quiera, es que…)."),
    ("1.9.0", "2026-11-04", "3 new extra chapters for commands: how direct to be (pasame la sal or ¿me pasás la "
                            "sal?, signs), commands to a group (pasen, siéntense, no se olviden), a command + another "
                            "verb (dejá de, andá a, acordate de, probá)."),
    ("1.8.0", "2026-11-04", "3 new extra chapters for the “used to” past: plans that didn't happen (iba a llamarte, "
                            "pero…), setting the scene of a story (eran las tres, hacía frío), the polite past "
                            "(quería un kilo de…, te llamaba por…)."),
    ("1.7.0", "2026-11-04", "Today = your next chapter + a quick review (the old mixed session is the Big review); "
                            "each stage: basics, a check, then extra chapters; word chapters (10 new words) after every "
                            "two lessons; 3 new past-tense chapters; 'already know the present? start at the past'."),
    ("1.6.0", "2026-10-14", "Review spacing fixed (only due reviews move on, 6 new words a day, catch-up mode, daily "
                            "listening); daily backups + Earlier copies; share-sheet export; offline audio; fast start; "
                            "bottom tab bar; I was right / Report; resume; reply exercises; listen-first readings; "
                            "stage 1 shortened, no tenses before they are taught; 12 new chapters, 6 readings, ~330 words."),
    ("1.5.1", "2026-10-05", "Phone: the Check button is no longer hidden by the keyboard (one row of accent buttons, "
                            "no shortcuts line; the keyboard's 'go' key checks the answer)."),
    ("1.5.0", "2026-10-03", "Chapter introductions, new reading chapters and lessons, version number, quieter backup "
                            "reminder; friends' computer copies keep progress in Documents."),
    ("1.4.0", "2026-10-03", "The course path: 8 stages, one tense at a time; skip a chapter after a check; move on."),
    ("1.3.0", "2026-10-03", "Tip shown once, tense buttons un-select, backup reminder, customs and vos chapters removed."),
    ("1.2.0", "2026-10-02", "Learner notes: gap in fill-in audio, clear 'you', word hints, teach before test, one tense at a time."),
    ("1.1.0", "2026-09-25", "Phone website, friends' zip, slang in the background."),
    ("1.0.0", "2026-09-22", "First build."),
]
