"""The app version, shown small at the bottom of the home screen.

Bump MINOR for new features or content, PATCH for fixes, and add a line to CHANGES (newest first).
"""
VERSION = "1.6.0"

CHANGES = [
    ("1.6.0", "2026-10-14", "Review spacing fixed (only due reviews move on, 6 new words a day, catch-up mode, daily "
                            "listening); daily backups + Earlier copies; share-sheet export; offline audio; fast start; "
                            "bottom tab bar; I was right / Report; resume; reply exercises; listen-first readings; "
                            "stage 1 shortened, no tenses before they are taught; 12 new chapters, 6 readings, ~330 words."),
    ("1.5.1", "2026-10-05", "Phone: the Check button is no longer hidden by the keyboard (one row of accent buttons, "
                            "no shortcuts line; the keyboard's 'go' key checks the answer)."),
    ("1.5.0", "2026-10-03", "Chapter introductions, new reading chapters and lessons, version number, quieter backup "
                            "reminder; friends' computer copies keep progress in Documents."),
    ("1.4.0", "2026-10-03", "The course path: 8 stages, one tense at a time; skip a chapter after a check; move on."),
    ("1.3.0", "2026-10-03", "Tip shown once, tense buttons un-select, backup reminder, customs and vos chapters removed."),
    ("1.2.0", "2026-10-02", "Learner notes: gap in fill-in audio, clear 'you', word hints, teach before test, one tense at a time."),
    ("1.1.0", "2026-09-25", "Phone website, friends' zip, slang in the background."),
    ("1.0.0", "2026-09-22", "First build."),
]
