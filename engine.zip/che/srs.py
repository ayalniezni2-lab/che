"""Spaced repetition (SM-2 style).  One card per item key:

  vocab:<id>:<en2es|es2en|listen|dict>   a word or phrase, per direction (dict = type the example you hear)
  verb:<inf>:<tense>:<person>         one cell of a conjugation table
  ex:<exercise id>                    a hand-written exercise
  tpl:<template id>                   a sentence pattern

Only a review that was DUE moves a card forward: answering the same word again in a lesson, in Today and in
Practice on one afternoon counts as practice, not as proof that it has stuck (it used to jump to 8 days at once).
A wrong answer always counts.  Late reviews get credit for the extra time the word survived, and intervals of
3+ days get a small random spread so a day's new words do not all come back on the same later day.
"""
import random
from datetime import date, timedelta

QUALITY = {"correct": 4, "almost": 3, "wrong": 1}


def today():
    return date.today().isoformat()


def new_card():
    return {"ef": 2.5, "iv": 0, "reps": 0, "due": today(), "lapses": 0, "seen": 0, "right": 0, "last": None}


def _days(a, b):
    try:
        return (date.fromisoformat(b) - date.fromisoformat(a)).days
    except (TypeError, ValueError):
        return 0


def review(card, verdict, fast=False, rng=random):
    """Update a card in place after an answer.  verdict: correct | almost | wrong."""
    q = QUALITY.get(verdict, 1)
    if verdict == "correct" and fast:
        q = 5
    now = today()
    was_due = is_due(card, now)
    card["seen"] = card.get("seen", 0) + 1
    card["last"] = now
    if q < 3:
        card["reps"] = 0
        card["iv"] = 0
        card["lapses"] = card.get("lapses", 0) + 1
        card["ef"] = max(1.3, card.get("ef", 2.5) - 0.2)
        card["due"] = now                           # mistakes come back sooner: same day, then tomorrow
        return card
    card["right"] = card.get("right", 0) + 1
    if not was_due:                                 # extra practice before it was due: no step forward
        return card
    overdue = max(0, _days(card.get("due") or now, now))
    card["reps"] = card.get("reps", 0) + 1
    if card["reps"] == 1:
        iv = 1
    elif card["reps"] == 2:
        iv = 3
    else:
        iv = max(1, round((card.get("iv", 1) + overdue // 2) * card.get("ef", 2.5)))
    if q == 3:
        iv = max(1, round(iv * 0.6))
    if iv >= 3:
        iv = max(1, round(iv * rng.uniform(0.9, 1.1)))
    if q == 3:
        ef = card.get("ef", 2.5) - 0.14
    elif q == 4:
        ef = card.get("ef", 2.5) + 0.03             # a plain right answer slowly earns back lost ease
    else:
        ef = card.get("ef", 2.5) + 0.1
    card["ef"] = round(max(1.3, min(ef, 2.8)), 3)
    card["iv"] = iv
    card["due"] = (date.today() + timedelta(days=iv)).isoformat()
    return card


def is_due(card, on=None):
    return (card.get("due") or "") <= (on or today())


def is_known(card):
    """Counts as 'known' once it has survived at least two spaced reviews."""
    return card.get("reps", 0) >= 2 and card.get("iv", 0) >= 3


def weakness(card):
    """0 (solid) … 1 (weak).  Used to weight drills toward weak spots."""
    seen = card.get("seen", 0)
    if not seen:
        return 0.5
    acc = card.get("right", 0) / seen
    w = (1 - acc) * 0.7 + min(card.get("lapses", 0), 5) / 5 * 0.3
    return round(min(1.0, w), 3)
