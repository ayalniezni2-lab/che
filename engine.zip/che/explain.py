"""Plain-English wording: tense names, person names and rough English glosses ("I had").

The learner does not know grammar jargon, so every label here is everyday English first.
"""
import re

TENSE = {
    "pres": {"label": "present", "long": "present (now / usually)"},
    "pret": {"label": "past tense (finished actions)", "long": "past tense (finished actions)"},
    "impf": {"label": "“used to / was doing” past", "long": "“used to / was doing” past"},
    "iraf": {"label": "going-to future (voy a…)", "long": "going-to future: ir + a + verb"},
    "fut": {"label": "simple future (will…)", "long": "simple future (will…)"},
    "cond": {"label": "“would” form", "long": "“would” form"},
    "subj": {"label": "“wishes / not sure” form", "long": "“wishes / not sure” form (after quiero que…, ojalá…, cuando…)"},
    "subjp": {"label": "“wishes / not sure” form, past", "long": "“wishes / not sure” form in the past (si tuviera…)"},
    "imp": {"label": "command", "long": "command (telling someone to do it)"},
    "impneg": {"label": "“don't” command", "long": "“don't” command (no + verb)"},
    "ger": {"label": "-ndo form (-ing)", "long": "-ndo form (like English -ing)"},
    "pp": {"label": "the “done” form (hecho, comido…)", "long": "the “done” form (hecho, comido, abierto…)"},
    "perf": {"label": "“have done” form", "long": "“have done” form (he comido) — rare in Argentina"},
    "plup": {"label": "“had done” form", "long": "“had done” form (había comido)"},
    "prog": {"label": "“am doing” form", "long": "“am doing” form (estoy comiendo)"},
}
TEXTBOOK = {"pres": "present indicative", "pret": "preterite", "impf": "imperfect", "fut": "future",
            "cond": "conditional", "subj": "present subjunctive", "subjp": "imperfect subjunctive",
            "imp": "imperative", "impneg": "negative imperative", "ger": "gerund", "pp": "past participle",
            "perf": "present perfect", "plup": "pluperfect", "prog": "present progressive",
            "iraf": "periphrastic future"}

PERSON_ES = {"yo": "yo", "vos": "vos", "el": "él / ella / usted", "nos": "nosotros",
             "uds": "ustedes", "ellos": "ellos / ellas"}
PERSON_EN = {"yo": "I", "vos": "you", "el": "he / she / you (formal)", "nos": "we",
             "uds": "you all", "ellos": "they"}
PERSON_SHORT_EN = {"yo": "I", "vos": "you", "el": "he/she", "nos": "we", "uds": "you all", "ellos": "they"}
IMP_PERSON_ES = {"vos": "vos", "el": "usted (formal)", "uds": "ustedes", "nos": "nosotros"}

# base: (past, participle)
IRREG_EN = {
    "be": ("was", "been"), "have": ("had", "had"), "do": ("did", "done"), "go": ("went", "gone"),
    "say": ("said", "said"), "see": ("saw", "seen"), "know": ("knew", "known"), "give": ("gave", "given"),
    "come": ("came", "come"), "put": ("put", "put"), "leave": ("left", "left"), "think": ("thought", "thought"),
    "take": ("took", "taken"), "eat": ("ate", "eaten"), "buy": ("bought", "bought"), "make": ("made", "made"),
    "understand": ("understood", "understood"), "find": ("found", "found"), "feel": ("felt", "felt"),
    "begin": ("began", "begun"), "pay": ("paid", "paid"), "hear": ("heard", "heard"), "read": ("read", "read"),
    "write": ("wrote", "written"), "sleep": ("slept", "slept"), "tell": ("told", "told"),
    "bring": ("brought", "brought"), "sell": ("sold", "sold"), "sit": ("sat", "sat"), "get": ("got", "got"),
    "drive": ("drove", "driven"), "sing": ("sang", "sung"), "lose": ("lost", "lost"), "win": ("won", "won"),
    "cut": ("cut", "cut"), "choose": ("chose", "chosen"), "show": ("showed", "shown"), "fall": ("fell", "fallen"),
    "break": ("broke", "broken"), "spend": ("spent", "spent"), "lend": ("lent", "lent"), "run": ("ran", "run"),
    "swim": ("swam", "swum"), "send": ("sent", "sent"), "keep": ("kept", "kept"), "meet": ("met", "met"),
    "forget": ("forgot", "forgotten"), "wake": ("woke", "woken"), "wear": ("wore", "worn"),
    "hurt": ("hurt", "hurt"), "grow": ("grew", "grown"), "fly": ("flew", "flown"), "bite": ("bit", "bitten"),
    "bet": ("bet", "bet"), "fight": ("fought", "fought"), "hit": ("hit", "hit"), "steal": ("stole", "stolen"),
    "hold": ("held", "held"), "build": ("built", "built"), "stand": ("stood", "stood"), "hide": ("hid", "hidden"),
    "let": ("let", "let"), "speak": ("spoke", "spoken"), "drink": ("drank", "drunk"),
    "catch": ("caught", "caught"), "throw": ("threw", "thrown"), "hang": ("hung", "hung"),
    "rise": ("rose", "risen"), "shut": ("shut", "shut"), "stick": ("stuck", "stuck"), "lie": ("lied", "lied"),
    "mean": ("meant", "meant"), "light": ("lit", "lit"), "become": ("became", "become"),
    "lead": ("led", "led"), "beat": ("beat", "beaten"), "deal": ("dealt", "dealt"), "teach": ("taught", "taught"),
    "undo": ("undid", "undone"), "foresee": ("foresaw", "foreseen"), "withstand": ("withstood", "withstood"),
    "shake": ("shook", "shaken"), "draw": ("drew", "drawn"), "ring": ("rang", "rung"), "set": ("set", "set"),
    "quit": ("quit", "quit"), "swear": ("swore", "sworn"), "lay": ("laid", "laid"), "shoot": ("shot", "shot"),
}


def en_base(gloss):
    """'to go out, to leave' -> 'go out';  'can, to be able to' -> 'can'."""
    g = re.split(r"[;,(]", gloss or "")[0].strip()
    g = re.sub(r"^to\s+", "", g)
    return g or "do"


def _split_head(base):
    parts = base.split(" ", 1)
    return parts[0], (" " + parts[1] if len(parts) > 1 else "")


def _third(head):
    if head == "be":
        return "is"
    if head == "have":
        return "has"
    if head in ("can", "must"):
        return head
    if re.search(r"(s|sh|ch|x|z|o)$", head):
        return head + "es"
    if re.search(r"[^aeiou]y$", head):
        return head[:-1] + "ies"
    return head + "s"


def _double(head):
    return (re.search(r"^[^aeiou]*[aeiou][bdgmnprt]$", head) or
            head in ("begin", "forget", "admit", "prefer", "regret", "stop", "chat", "swim"))


def _past(head, participle=False):
    if head in IRREG_EN:
        return IRREG_EN[head][1 if participle else 0]
    if head == "can":
        return "could"
    if head.endswith("e"):
        return head + "d"
    if re.search(r"[^aeiou]y$", head):
        return head[:-1] + "ied"
    if _double(head):
        return head + head[-1] + "ed"
    return head + "ed"


def _ing(head):
    if head == "be":
        return "being"
    if head.endswith("ie"):
        return head[:-2] + "ying"
    if head.endswith("e") and not head.endswith(("ee", "ye", "oe")):
        return head[:-1] + "ing"
    if _double(head):
        return head + head[-1] + "ing"
    return head + "ing"


def gloss(en, tense, person=None):
    """Rough English for a form: gloss('to have', 'pret', 'yo') -> 'I had'."""
    base = en_base(en)
    head, rest = _split_head(base)
    subj = PERSON_SHORT_EN.get(person or "", "")
    third = person == "el"
    be = head == "be"
    modal = head in ("can", "must")
    if tense == "ger":
        return _ing(head) + rest
    if tense == "pp":
        return _past(head, True) + rest
    if tense == "imp":
        return base + "!"
    if tense == "impneg":
        return "don't " + base + "!"
    if tense == "pres":
        if be:
            v = {"yo": "am", "el": "is"}.get(person, "are")
        else:
            v = _third(head) if third else head
        return "%s %s%s" % (subj, v, rest)
    if tense == "pret":
        v = ("was" if person in ("yo", "el") else "were") if be else _past(head)
        return "%s %s%s" % (subj, v, rest)
    if modal:
        base = "be able to"
        head, rest = "be", " able to"
    if tense == "impf":
        return "%s used to %s / %s %s" % (subj, base, "was" if person in ("yo", "el") else "were", _ing(head) + rest)
    if tense == "fut":
        return "%s will %s" % (subj, base)
    if tense == "iraf":
        return "%s %s going to %s" % (subj, {"yo": "am", "el": "is"}.get(person, "are"), base)
    if tense == "cond":
        return "%s would %s" % (subj, base)
    if tense == "subj":
        return "…that %s %s" % (subj, base)
    if tense == "subjp":
        return "if %s %s…" % (subj, ("were" + rest) if be else _past(head) + rest)
    if tense == "perf":
        return "%s %s %s%s" % (subj, "has" if third else "have", _past(head, True), rest)
    if tense == "plup":
        return "%s had %s%s" % (subj, _past(head, True), rest)
    if tense == "prog":
        return "%s %s %s%s" % (subj, {"yo": "am", "el": "is"}.get(person, "are"), _ing(head), rest)
    return base


def tense_label(tense, long=False):
    t = TENSE.get(tense, {})
    return t.get("long" if long else "label", tense)


def person_label(person, tense=None):
    if tense in ("imp", "impneg"):
        return IMP_PERSON_ES.get(person, person)
    return PERSON_ES.get(person, person or "")


def describe(tense, person=None):
    """'the past tense (finished actions) for yo'"""
    if tense in ("ger", "pp"):
        return "the " + tense_label(tense)
    return "the %s for %s" % (tense_label(tense), person_label(person, tense))


def en_verb(base, tense, person):
    """English verb phrase WITHOUT its subject: en_verb('buy', 'iraf', 'el') -> 'is going to buy'."""
    base = re.sub(r"^to\s+", "", base.strip())
    head, rest = _split_head(base)
    third = person == "el"
    be_now = {"yo": "am", "el": "is"}.get(person, "are")
    be_past = "was" if person in ("yo", "el") else "were"
    if tense == "pres":
        if head == "be":
            return be_now + rest
        return (_third(head) if third else head) + rest
    if tense == "pret":
        if head == "be":
            return be_past + rest
        return _past(head) + rest
    if tense == "impf":
        return "used to " + base
    if tense == "fut":
        return "will " + base
    if tense == "iraf":
        return "%s going to %s" % (be_now, base)
    if tense == "cond":
        return "would " + base
    if tense == "prog":
        return "%s %s%s" % (be_now, _ing(head), rest)
    if tense == "perf":
        return "%s %s%s" % ("has" if third else "have", _past(head, True), rest)
    if tense == "plup":
        return "had %s%s" % (_past(head, True), rest)
    return base


def topic_label(topic):
    """'conj:pret' -> 'verb forms: past tense (finished actions)';  'ir-future' -> 'ir future'."""
    topic = topic or "general"
    if topic.startswith("conj:"):
        return "verb forms: " + tense_label(topic[5:])
    return topic.replace("-", " ")


def verb_en(v):
    """The English used for hints: an optional plain "gloss" (haber → have) or the dictionary meaning."""
    v = v or {}
    return v.get("gloss") or v.get("en", "")
