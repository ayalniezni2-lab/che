"""JSON API.  Routes are small functions registered with @route."""
import json
from datetime import datetime

from .audio import AudioIndex
from .content import Content, LEVEL_ORDER
from .progress import ProgressStore, DEFAULT_SETTINGS

ROUTES = {}
STATE = {"content": None, "progress": None, "audio": None}


class ApiError(Exception):
    def __init__(self, message, code=400):
        super().__init__(message)
        self.code = code


def route(method, path):
    def deco(fn):
        ROUTES[(method, path)] = fn
        return fn
    return deco


def init():
    STATE["content"] = Content()
    STATE["progress"] = ProgressStore()
    STATE["audio"] = AudioIndex()
    # late imports: these modules register more routes
    from . import api_learn  # noqa: F401
    from . import session  # noqa: F401


def shutdown():
    p = STATE.get("progress")
    if p:
        p.save()
        p.backup()


def C():
    return STATE["content"]


def P():
    return STATE["progress"]


def A():
    return STATE["audio"]


def dispatch(method, path, query, body):
    path = path.strip("/")
    fn = ROUTES.get((method, path))
    arg = None
    if fn is None and "/" in path:            # routes with one trailing argument: unit/<id>
        head, arg = path.rsplit("/", 1)
        fn = ROUTES.get((method, head + "/*"))
    if fn is None:
        raise ApiError("Unknown API route: %s %s" % (method, path), 404)
    result = fn(query, body, arg) if arg is not None else fn(query, body)
    if isinstance(result, tuple) and len(result) == 2 and isinstance(result[0], int):
        return result
    return 200, result


# ---------------------------------------------------------------- core routes
def unit_status(uid):
    return P().data["units"].get(uid, {})


def unit_index():
    out = []
    vulgar_ok = bool(P().data["settings"].get("vulgar"))
    for u in C().unit_order:
        if u.get("reg") == "vulgar" and not vulgar_ok:
            continue                       # opt-in only (Settings -> Vulgar words)
        st = unit_status(u["id"])
        out.append({"id": u["id"], "level": u.get("level"), "order": u.get("order"),
                    "title": u.get("title"), "goal": u.get("goal", ""),
                    "topic": u.get("topic"), "kind": u.get("kind", "lesson"),
                    "exercises": len(u.get("exercises", [])),
                    "started": bool(st.get("started")), "completed": bool(st.get("completed")),
                    "best": st.get("best")})
    return out


def _due_count():
    from .srs import is_due, today
    t = today()
    return sum(1 for c in P().data["srs"].values() if is_due(c, t))


@route("GET", "bootstrap")
def bootstrap(query, body):
    C().reload_if_changed()
    A().refresh()
    p = P()
    return {
        "app": "Che!",
        "levels": C().levels,
        "units": unit_index(),
        "counts": dict(C().counts(), audio=A().count()),
        "settings": p.data["settings"],
        "placement": p.data["placement"],
        "streak": p.streak(),
        "due": _due_count(),
        "mistakes_open": len([m for m in p.data["mistakes"] if not m.get("resolved")]),
        "today": p.data["history"].get(datetime.now().date().isoformat(), {}),
        "content_errors": C().errors[:20],
        "next_unit": _next_unit(),
    }


def _next_unit():
    try:
        from .session import next_unit
        return next_unit()
    except Exception:                      # advice only: never break the home page
        return None


@route("POST", "settings")
def save_settings(query, body):
    p = P()
    with p.lock:
        for k in DEFAULT_SETTINGS:
            if k in body:
                p.data["settings"][k] = body[k]
        p.save()
    return {"settings": p.data["settings"]}


@route("GET", "progress/export")
def export_progress(query, body):
    data = json.dumps(P().export(), ensure_ascii=False, indent=1).encode("utf-8")
    name = "che-progress-%s.json" % datetime.now().strftime("%Y%m%d-%H%M")
    return 200, (data, "application/json; charset=utf-8", name)


@route("POST", "progress/import")
def import_progress(query, body):
    try:
        P().import_data(body.get("data"))
    except ValueError as e:
        raise ApiError(str(e))
    return {"ok": True}


@route("POST", "progress/reset")
def reset_progress(query, body):
    if body.get("confirm") != "RESET":
        raise ApiError("Send {confirm: 'RESET'} to wipe progress (a backup is kept).")
    P().reset()
    return {"ok": True}


@route("POST", "reload")
def reload_content(query, body):
    C().load()
    A().refresh()
    return {"counts": C().counts(), "errors": C().errors[:50]}
