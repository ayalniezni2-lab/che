"""JSON API.  Routes are small functions registered with @route."""
import json
from datetime import datetime

from .audio import AudioIndex
from .content import Content, LEVEL_ORDER
from .progress import ProgressStore, DEFAULT_SETTINGS

ROUTES = {}
STATE = {"content": None, "progress": None, "audio": None}


class ApiError(Exception):
    def __init__(self, message, code=400):
        super().__init__(message)
        self.code = code


def route(method, path):
    def deco(fn):
        ROUTES[(method, path)] = fn
        return fn
    return deco


def init():
    STATE["content"] = Content()
    STATE["progress"] = ProgressStore()
    STATE["audio"] = AudioIndex()
    # late imports: these modules register more routes
    from . import api_learn  # noqa: F401
    from . import session  # noqa: F401
    from . import course  # noqa: F401


def shutdown():
    p = STATE.get("progress")
    if p:
        p.save()
        p.backup()


def C():
    return STATE["content"]


def P():
    return STATE["progress"]


def A():
    return STATE["audio"]


def dispatch(method, path, query, body):
    path = path.strip("/")
    fn = ROUTES.get((method, path))
    arg = None
    if fn is None and "/" in path:            # routes with one trailing argument: unit/<id>
        head, arg = path.rsplit("/", 1)
        fn = ROUTES.get((method, head + "/*"))
    if fn is None:
        raise ApiError("Unknown API route: %s %s" % (method, path), 404)
    result = fn(query, body, arg) if arg is not None else fn(query, body)
    if isinstance(result, tuple) and len(result) == 2 and isinstance(result[0], int):
        return result
    return 200, result


# ---------------------------------------------------------------- core routes
def unit_status(uid):
    return P().data["units"].get(uid, {})


def unit_index():
    """Every chapter (lessons and reading chapters) in course order."""
    from . import course
    out = []
    vulgar_ok = bool(P().data["settings"].get("vulgar"))
    for st in course.course()["stages"]:
        for ch in course.visible(st, vulgar_ok):      # vulgar chapters: opt-in only (Settings -> Vulgar words)
            s = unit_status(ch["id"])
            u = C().units.get(ch["id"]) or {}
            out.append({"id": ch["id"], "type": ch["type"], "kind": ch["kind"], "stage": ch["stage"],
                        "pos": ch["pos"] + 1, "level": ch.get("level"), "title": ch.get("title"),
                        "goal": ch.get("goal", ""), "topic": u.get("topic"),
                        "exercises": len(u.get("exercises", [])),
                        "started": bool(s.get("started")), "completed": bool(s.get("completed") or s.get("skipped")),
                        "skipped": bool(s.get("skipped")) and not s.get("completed"), "best": s.get("best")})
    return out


def _due_count():
    from .srs import is_due, today
    from .session import key_retired
    t = today()
    return sum(1 for k, c in P().data["srs"].items() if is_due(c, t) and not key_retired(k))


@route("GET", "bootstrap")
def bootstrap(query, body):
    C().reload_if_changed()
    A().refresh()
    p = P()
    return {
        "app": "Che!",
        "levels": C().levels,
        "units": unit_index(),
        "counts": dict(C().counts(), audio=A().count()),
        "settings": p.data["settings"],
        "placement": p.data["placement"],
        "streak": p.streak(),
        "due": _due_count(),
        "mistakes_open": _open_mistakes(p),
        "today": p.data["history"].get(datetime.now().date().isoformat(), {}),
        "content_errors": C().errors[:20],
        "next_unit": _next_unit(),
        "course": _course(p),
        "backup_due": _backup_due(p),
    }


def _open_mistakes(p):
    from .session import key_retired
    return len([m for m in p.data["mistakes"] if not m.get("resolved") and not key_retired(m["key"])])


BACKUP_EVERY_DAYS = 14


def _backup_due(p):
    """Remind to Export when there is real progress and no copy from the last two weeks."""
    s, today = p.data["settings"], datetime.now().date()
    if len(p.data.get("srs", {})) < 20:
        return False
    try:
        if s.get("backup_snooze") and datetime.strptime(s["backup_snooze"], "%Y-%m-%d").date() > today:
            return False
        if s.get("last_export"):
            return (today - datetime.strptime(s["last_export"], "%Y-%m-%d").date()).days >= BACKUP_EVERY_DAYS
    except (TypeError, ValueError):
        pass
    return True


def _mark_exported(p):
    with p.lock:
        p.data["settings"]["last_export"] = datetime.now().date().isoformat()
        p.data["settings"]["backup_snooze"] = None
        p.save()


@route("POST", "progress/exported")
def progress_exported(query, body):
    _mark_exported(P())
    return {"ok": True}


def _course(p):
    try:
        from . import course
        return course.summary(p.data)
    except Exception:                      # advice only: never break the home page
        import traceback
        traceback.print_exc()
        return None


def _next_unit():
    try:
        from .session import next_unit
        return next_unit()
    except Exception:                      # advice only: never break the home page
        return None


@route("POST", "settings")
def save_settings(query, body):
    p = P()
    with p.lock:
        for k in DEFAULT_SETTINGS:
            if k in body:
                p.data["settings"][k] = body[k]
        p.save()
    return {"settings": p.data["settings"]}


@route("GET", "progress/export")
def export_progress(query, body):
    data = json.dumps(P().export(), ensure_ascii=False, indent=1).encode("utf-8")
    name = "che-progress-%s.json" % datetime.now().strftime("%Y%m%d-%H%M")
    return 200, (data, "application/json; charset=utf-8", name)


@route("POST", "progress/import")
def import_progress(query, body):
    try:
        P().import_data(body.get("data"))
    except ValueError as e:
        raise ApiError(str(e))
    _mark_exported(P())          # the progress now also exists as that file
    return {"ok": True}


@route("POST", "progress/reset")
def reset_progress(query, body):
    if body.get("confirm") != "RESET":
        raise ApiError("Send {confirm: 'RESET'} to wipe progress (a backup is kept).")
    P().reset()
    return {"ok": True}


@route("POST", "reload")
def reload_content(query, body):
    C().load()
    A().refresh()
    return {"counts": C().counts(), "errors": C().errors[:50]}
