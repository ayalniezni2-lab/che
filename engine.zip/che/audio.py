"""Audio naming: text + voice -> stable file name.  Argentine voices ONLY.

The same functions are used by the app (to find a clip) and by tools/generate_audio.py
(to create it), so they can never disagree.
"""
import hashlib
import json
import os
import re
import threading

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
AUDIO_DIR = os.path.join(ROOT, "audio")
MANIFEST = os.path.join(AUDIO_DIR, "manifest.json")

VOICE_F = "es-AR-ElenaNeural"
VOICE_M = "es-AR-TomasNeural"
VOICES = (VOICE_F, VOICE_M)   # never anything that is not es-AR


def clean_text(text):
    """Canonical spoken text: trimmed, single spaces, no slot markers."""
    text = re.sub(r"\s+", " ", (text or "").strip())
    return text


def pick_voice(text, voice=None):
    """Explicit voice ('f'/'m'/full name) or a stable pseudo-random choice per text."""
    if voice in ("f", "F", VOICE_F):
        return VOICE_F
    if voice in ("m", "M", VOICE_M):
        return VOICE_M
    h = hashlib.sha1(clean_text(text).lower().encode("utf-8")).digest()
    return VOICES[h[0] % 2]


def file_name(text, voice=None):
    v = pick_voice(text, voice)
    key = (v + "|" + clean_text(text)).encode("utf-8")
    return hashlib.sha1(key).hexdigest()[:20] + ".mp3"


class AudioIndex:
    """Knows which clips actually exist on disk (checked lazily, cached)."""

    def __init__(self):
        self._lock = threading.Lock()
        self._known = None

    def _scan(self):
        # the phone / web version ships only the list of clips; the browser fetches the files itself
        listing = os.path.join(AUDIO_DIR, "available.txt")
        if os.path.isfile(listing):
            with open(listing, "r", encoding="utf-8") as f:
                return {line.strip() for line in f if line.strip().endswith(".mp3")}
        try:
            return {n for n in os.listdir(AUDIO_DIR) if n.endswith(".mp3")}
        except OSError:
            return set()

    def refresh(self):
        with self._lock:
            self._known = self._scan()

    def ref(self, text, voice=None):
        """Return '/audio/<file>' if the clip exists, else None."""
        if not text:
            return None
        if self._known is None:
            self.refresh()
        name = file_name(text, voice)
        if name in self._known:
            return "/audio/" + name
        return None

    def count(self):
        if self._known is None:
            self.refresh()
        return len(self._known)


def load_manifest():
    try:
        with open(MANIFEST, "r", encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return {}
